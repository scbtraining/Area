package com.stu.dao.Impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.ATTDAO;
import com.stu.dao.AbstractAttDao;
import com.stu.dao.AbstractStudDao;
import com.stu.dao.STUDAO;
import com.stu.exception.ATTException;
import com.stu.exception.STUDENTException;
import com.stu.exception.STUDENTFEEException;
import com.stu.model.ATT;
import com.stu.model.STUD;
import com.stu.model.STUDFEE;
import com.stu.model.JSON.ATTInfo;
import com.stu.model.JSON.STUDFEEInfo;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.STUReaderTypeCount;



@Repository("/attDAOImpl")
public class ATTDAOImpl extends AbstractAttDao<Integer, ATT> implements
		ATTDAO {
	
	public String saveAddATT(ATT addATT)throws ATTException{
		System.out.println("ATTDAOImpl - saveAddATT method starts");
		saveOrUpdate(addATT);
		System.out.println("ATTDAOImpl - saveAddATT method ends");
		return "success";
	}
	
	@SuppressWarnings("unchecked")
	public List<ATTInfo> fetchAATTData(int ATTid)throws ATTException{
		System.out.println("ATTDAOImpl - fetchAATTData method starts");
		List<ATTInfo> ATTlist = new ArrayList<ATTInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(ATT.class).add( Restrictions.eq("attid", ATTid ) );
			ATTlist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ATTException("Error occured:", e.getMessage());
		}
		System.out.println("ATTDAOImpl - fetchAATTData method ends");
		return ATTlist;
	}
	
	public List<ATTInfo> fetchAllATTData()throws ATTException{
		System.out.println("ATTDAOImpl - fetchAllATTData method starts");
		List<ATTInfo> ATTAlllist = new ArrayList<ATTInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(ATT.class);
			ATTAlllist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ATTException("Error occured:", e.getMessage());
		}
		System.out.println("ATTDAOImpl - fetchAllATTData method ends");
		return ATTAlllist;
	}
	
	/*public List<ATTInfo> fetchPreData()throws ATTException{
		System.out.println("ATTDAOImpl - fetchPreData method starts");
		List<ATTInfo> ATTAlllist = new ArrayList<ATTInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(ATT.class);
			ATTAlllist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ATTException("Error occured:", e.getMessage());
		}
		System.out.println("ATTDAOImpl - fetchAllATTData method ends");
		return ATTAlllist;
	}*/
	
	public List<ATTInfo> fetchPreData()throws ATTException{
	Session session = getSession();;
	Transaction tx = null;
	List<ATTInfo> studAttList = null;
	
	try {
		tx = session.beginTransaction();
		//studentList = session.createCriteria(Student.class).list();
		
		String sql = "select a.class_name,b.section, a.precount, c.abscount from  "+
"(select count(*) precount, CLASS_NAME, CLASS_ID from SCBSOW.STUDENT_ATTANDANCE where STUDENT_ATTENDANCE = 'P'  group by CLASS_NAME, class_id)a, (select count(*) abscount, CLASS_NAME, CLASS_ID from SCBSOW.STUDENT_ATTANDANCE where STUDENT_ATTENDANCE = 'Ab'  group by CLASS_NAME, class_id)c, SCBSOW.STUDENT_CLASS b where a.class_id = b.CLASS_ID AND c.class_id = b.CLASS_ID ";
			
		SQLQuery query = session.createSQLQuery(sql);
		
		List<Object[]> results = query.list();
		studAttList = new ArrayList<ATTInfo>();		
		for (Object[] row : results) {
			ATTInfo preInfo = new ATTInfo();
			
			String className="";
			if (row[0] != null && row[0] != "") {
				className =row[0].toString();		
				preInfo.setClassName(className);	
			}
			String section="";
			if (row[1] != null && row[1] != "") {
				section =row[1].toString();				
				preInfo.setSection(section);	
			}	
			
			int presentCount=0;
			if (row[2] != null && row[2] != "") {
				presentCount =Integer.valueOf(row[2].toString());				
				preInfo.setPresentCount(presentCount);	
			}
			
			int absentCount=0;
			if (row[3] != null && row[3] != "") {
				absentCount =Integer.valueOf(row[3].toString());				
				preInfo.setAbsentCount(absentCount);	
			}
			studAttList.add(preInfo);
		}		
		tx.commit();
	} catch (HibernateException e) {
		if (tx != null)
		tx.rollback();
		e.printStackTrace();
	} 
	return studAttList;

	}
	
	public List<ATTInfo> fetchAbsData()throws ATTException{
		Session session = getSession();;
		Transaction tx = null;
		List<ATTInfo> studAttList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select a.class_name,b.section, a.precount from "+
	"(select count(*) precount, CLASS_NAME, CLASS_ID from SCBSOW.STUDENT_ATTANDANCE where STUDENT_ATTENDANCE = 'Ab'  group by CLASS_NAME, class_id) a, SCBSOW.STUDENT_CLASS b where a.class_id = b.CLASS_ID ";
			
			SQLQuery query = session.createSQLQuery(sql);
			
			List<Object[]> results = query.list();
			studAttList = new ArrayList<ATTInfo>();			
			for (Object[] row : results) {
				ATTInfo msgval = new ATTInfo();
				
				
				String className="";
				if (row[0] != null && row[0] != "") {
					className =row[0].toString();		
					msgval.setClassName(className);	
				}
				String section="";
				if (row[1] != null && row[1] != "") {
					section =row[1].toString();				
					msgval.setSection(section);	
				}				
				int absentCount=0;
				if (row[2] != null && row[2] != "") {
					absentCount =Integer.valueOf(row[2].toString());				
					msgval.setAbsentCount(absentCount);	
				}
				studAttList.add(msgval);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} 
		return studAttList;

		}
	
	public List<STUReaderTypeCount> fetchAreaSTUDetails(int readerID)throws ATTException{
		Session session = getSession();;
		Transaction tx = null;
		List<STUReaderTypeCount> studAreaList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "Select DISTINCT(sc.reader_type_id), st.reader_type_Name,a.stuCount, sc.reader_name "+
					"from (select count(*)stuCount ,readerId from SCBSOW.StudentMasterInfo where Readerid="+readerID+" group by readerId)a, " +
					"SCBSOW.STUDENT_READER_CONFIG sc,SCBSOW.STUDENT_READER_TYPE st "+
					"where sc.READER_TYPE_ID=st.READER_TYPE_ID AND sc.READER_ID = '"+readerID+"' ";
			
			SQLQuery query = session.createSQLQuery(sql);
			
			List<Object[]> results = query.list();
			studAreaList = new ArrayList<STUReaderTypeCount>();			
			for (Object[] row : results) {
				STUReaderTypeCount stuReaderCount = new STUReaderTypeCount();
				
				
				int readerTypeId=0;
				if (row[0] != null && row[0] != "") {
					readerTypeId =Integer.valueOf(row[0].toString());		
					stuReaderCount.setReaderTypeId(readerTypeId);
				}
				String readerTypName="";
				if (row[1] != null && row[1] != "") {
					readerTypName =row[1].toString();				
					stuReaderCount.setReaderTypName(readerTypName);
				}				
				int studentCount=0;
				if (row[2] != null && row[2] != "") {
					studentCount =Integer.valueOf(row[2].toString());				
					stuReaderCount.setStudentCount(studentCount);
				}
				
				String readerName="";
				if (row[3] != null && row[3] != "") {
					readerName =row[3].toString();				
					stuReaderCount.setReaderName(readerName);
				}	
				studAreaList.add(stuReaderCount);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} 
		return studAreaList;

		}
	
	public List<STUDInfo> fetchSTUAreaList(int readerID)throws ATTException{
		Session session = getSession();;
		Transaction tx = null;
		List<STUDInfo> studInfoList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select STUDENT_ID, STUDENT_NAME from SCBSOW.STUDENTDETAILS where STUDENT_ID IN  "+
			"(select STUDENTID from SCBSOW.STUDENT_CARD where CARDID IN " +
			"(select DISTINCT(CARDID) from SCBSOW.READER where READER_ID = '"+readerID+"'))";			
			
			SQLQuery query = session.createSQLQuery(sql);
			
			List<Object[]> results = query.list();
			studInfoList = new ArrayList<STUDInfo>();			
			for (Object[] row : results) {
				
				STUDInfo studentInfo = new STUDInfo();
				
				int studentID=0;
				if (row[0] != null && row[0] != "") {
					studentID =(int)Double.parseDouble(row[0].toString());		
					studentInfo.setSid(studentID);
				}
				String studentName="";
				if (row[1] != null && row[1] != "") {
					studentName =row[1].toString();				
					studentInfo.setSname(studentName);
				}		
				
				studInfoList.add(studentInfo);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} 
		return studInfoList;

		}
	
/*	
	public List<SOWInfo> fetchSOWData()throws SOWException{
		System.out.println("SOWDAOImpl - fetchSOW method starts");
		List<SOWInfo> allSOW = new ArrayList<SOWInfo>();
		if (allSOW == null || allSOW.isEmpty()) {
			allSOW = createListEntityCriteria();
		}
		System.out.println("SOWDAOImpl - fetchSOW method ends");
		return allSOW;
	}

	public BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException{
		System.out.println("SOWDAOImpl - currCalculation method starts");
		BigDecimal resultvalue = null;
		resultvalue = calculatedResult(curtype, curvalue);
		System.out.println("SOWDAOImpl - currCalculation method starts");
		return resultvalue;
	}*/
	
}
