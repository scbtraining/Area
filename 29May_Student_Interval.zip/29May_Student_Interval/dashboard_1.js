﻿angular.module("dashboard_1", [])
.controller("dashboardCtrl_1", ["$rootScope","$scope","$sce","$http","$timeout", "$interval", "config", function ($rootScope, $scope, $sce, $http, $timeout, $interval, config) { 
	
    $scope.frameUrl = $sce.trustAsResourceUrl('https://webchat.botframework.com/embed/mybotchat_CY8wUEEc7qo?s=SCzEInF7O5I.cwA.reQ.bJuv5s2Z0Chr2p_kpm0wtGF5ac4puytoBr7EfXIhERg');
    
	/*Highcharts.chart('container', {
	    chart: {type: 'column'},
	    title: {text: 'Monthly Average Attendance'},
	    xAxis: {	        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ],	        crosshair: true	    },
	    yAxis: { min: 0, title: {text: 'Attendance'	}},	   
	    plotOptions: {column: {pointPadding: 0.2, borderWidth: 0}},
	    series: [{    name: '1 std', data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]	    }, 
	    { name: '2 std', data: [83.6, 78.8, 98.5, 93.4, 106.0, 84.5, 105.0, 104.3, 91.2, 83.5, 106.6, 92.3]},
	    { name: '3 std', data: [48.9, 38.8, 39.3, 41.4, 47.0, 48.3, 59.0, 59.6, 52.4, 65.2, 59.3, 51.2]	    }, 
	    { name: '4 std', data: [42.4, 33.2, 34.5, 39.7, 52.6, 75.5, 57.4, 60.4, 47.6, 39.1, 46.8, 51.1]	    }]
	});	*/
	
	 // Donut Chart
    /*Morris.Donut({
        element: 'attendance-chart',
        colors: ["#ffab17", "#3A89C9", "#d9534f"],
        data: [{label: "Total", value: 21},{label: "Present",value: 11},{label: "Absent",value: 10}],
        resize: true,
        parseTime:false
    });*/
    
    // Auto Complete
    $scope.autoComplete = function(){
    	$http({ 
    		method: 'GET', 
    		/*url : 'http://10.30.55.108:8090/mining_latest/fetchSTUDetails',*/
    		url: config.globalUrl+'fetchSTUDetails', 
    		dataType: "json", 
    		contentType: "application/json; charset=utf-8" 
    	})
    	.success(function (response) {
    		$scope.autoSearchData = response;
    	})
    	.error(function (data, status) {
    		sweetAlert("Oops... before", "Something went error!", "error");
    		});
    	};
    // Auto Complete End
	
    // Search
    $scope.searchResult = function(id) {			
    	$http({ 
			method: 'GET', 
			url: config.globalUrl+'searchSTUD?data='+id, 
			dataType: "json", 
			contentType: "application/json; charset=utf-8" 
		})
		.success(function (response) {
            $scope.result = response;
            $(".sname").text($scope.result.sname);
            $(".rname").text($scope.result.rname);
            if($scope.result.sname != null && $scope.result.rname != null){
            	$(".sAvai").text("in");
            	$(".sAvai").css("display", "inline-block");
            }else{
            	$(".sAvai").text("");
            }                      
            
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
	};
	// Search End 
	
	var id = 1;
	// Absent Present count
	$scope.AbsentCnt = function(){
		console.log("$interval = "+id);
		$http({ 
			method: 'GET', 
			url: config.globalUrl +'fetchPRTStuCount',						
			dataType: "json", 
			contentType: "application/json; charset=utf-8" 
		})
        .success(function (data, status) {
            $scope.absent = data;
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
		id++;
	}
	// Absent Present count end	
	
	// RestrictArea count	
	$scope.RestrictArea = function(){
 		$http({ 
			method: 'GET', 
			url: config.globalUrl+'fetchStuAreaDetails?readerTypeID=1',			
			dataType: "json", 
			contentType: "application/json; charset=utf-8" 
		})
        .success(function (data, status) {
            $scope.rArea = data;        
            
            /*for(var i=0; i<$scope.rArea.length; i++){
            	 var readerNameValue = $scope.rArea[i].readerName.replace(" ","");
            	 var readerID = $scope.rArea[i].readerID;
            	 console.log("readerNameValue  " + readerNameValue);
            	 console.log("readerID  " + readerID);
            	 
            	 var ngSrcVal = "../../../Library/img/"+readerNameValue+".png";
            	 console.log("ngSrcVal  " + ngSrcVal);
            	  
            	 var imgTag = "<img id='imgId-"+readerID+"' src='"+ngSrcVal+"' />";
            	 console.log("imgTag>>>>>"+imgTag);
             	 $("#divImgId"+readerID).html(imgTag);
             }*/
     
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
	};
	// RestrictArea count end
	
	$scope.getImgName = function(obj){
		var imgSrc = "../../../Library/img/"+obj.replace(" ", "")+".png"
	    return imgSrc;
	  };

	// CommonArea count
	$scope.commonArea = function(){
		$http({ 
			method: 'GET', 
			/*url: 'http://inchcmpc10644:8080/mining_latest/fetchStuAreaDetails?readerTypeID=2',*/
			url: config.globalUrl+'fetchStuAreaDetails?readerTypeID=2',			
			dataType: "json", 
			contentType: "application/json; charset=utf-8" 
		})
        .success(function (data, status) {
            $scope.cArea = data;
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
	}
	// CommonArea count end
	
	// Student Name & Id count
	$scope.SNmeID = function(id, index){
		$http({ 
			method: 'GET', 
			url: config.globalUrl+'fetchAreaStudentList?readerID='+id,			
			dataType: "json", 
			contentType: "application/json; charset=utf-8" 
		})
        .success(function (data, status) {      
    		$scope.popoverIsVisible = true; 
           $scope.SNameId = data;
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
	}
	// Student Name & Id count
	
	var init = function(){
    	$scope.AbsentCnt();
    	$scope.commonArea();
    	$scope.RestrictArea();
    	$scope.autoComplete();
    }
    init();
    
    $interval(function () {
    	$scope.AbsentCnt();
    	$scope.commonArea();
    	$scope.RestrictArea();
    }, 50000);
    
}]);