﻿angular.module("AddPermission", ['angular-table', 'ui.bootstrap', 'ngResource'])
.controller("AddPermissionCtrl", ["$scope", "$window", "$http", "config", function ($scope, $window, $http, config) {

    $scope.data = {
        availableOptions: [
          { id: '1', name: 'Option A' },
          { id: '2', name: 'Option B' },
          { id: '3', name: 'Option C' }
        ],
        selectedOption: { id: '3', name: 'Option C' } //This sets the default value of the select in the ui
    };
    $scope.RoleMaster = [{ RoleID: '1', RoleName: 'Role One' },
        { RoleID: '2', RoleName: 'Role Two' },
        { RoleID: '3', RoleName: 'Role Three' },
        { RoleID: '4', RoleName: 'Role Four' },
        { RoleID: '5', RoleName: 'Role Five' }];

    $scope.MenuMaster = [
       { MainMenuID: '1', MenuName: 'Main Menu 1', SubMenuID: '', SubMenuName: '', View: 'true', Create: 'true', Update: 'true', Delete: 'true', isMaster: 'true' },
       { MainMenuID: '1', MenuName: '', SubMenuID: '1', SubMenuName: 'Sub Menu 1 1', View: 'true', Create: 'true', Update: 'true', Delete: 'true', isMaster: 'false' },
       { MainMenuID: '1', MenuName: '', SubMenuID: '2', SubMenuName: 'Sub Menu 1 2', View: 'true', Create: 'true', Update: 'true', Delete: 'true', isMaster: 'false' },
       { MainMenuID: '2', MenuName: 'Main Menu 2', SubMenuID: '1', SubMenuName: '', View: 'true', Create: 'true', Update: 'true', Delete: 'true', isMaster: 'true' },
       { MainMenuID: '3', MenuName: 'Main Menu 3', SubMenuID: '', SubMenuName: '', View: 'true', Create: 'true', Update: 'true', Delete: 'true', isMaster: 'true' },
       { MainMenuID: '3', MenuName: '', SubMenuID: '1', SubMenuName: 'Sub Menu 3 1', View: 'true', Create: 'true', Update: 'true', Delete: 'true', isMaster: 'false' },
       { MainMenuID: '4', MenuName: 'Main Menu 4', SubMenuID: '1', SubMenuName: '', View: 'true', Create: 'true', Update: 'true', Delete: 'true', isMaster: 'true' },
       { MainMenuID: '5', MenuName: 'Main Menu 5', SubMenuID: '1', SubMenuName: '', View: 'true', Create: 'true', Update: 'true', Delete: 'true', isMaster: 'true' }];

    $scope.getType = function (strValue) {
        if (strValue == true)
            return checkbox;
        else
            return label;
    }

    /// To Get Data for Role ID

    //$http({ method: 'GET', url: 'url', dataType: "json", contentType: "application/json; charset=utf-8" })
    //      .success(function (data, status) {
    //          $scope.MenuMaster = data;
    //          $scope.list = $scope.MenuMaster;
    //      })
    //      .error(function (data, status) {
    //          sweetAlert("Oops...", "Something went wrong!", "error");
    //      });


    /// To Submit Roles for Role ID

    //$scope.SaveRoleAccess = function (MenuMaster,RoleID) {
    //    $scope.RoleSubmit = MenuMaster;
    //    $scope.RoleSubmit.RoleID = RoleID;
    //    bounds;
    //    $http({
    //        url: 'url',
    //        dataType: 'json',
    //        method: 'POST',
    //        data: $scope.RoleSubmit,
    //        headers: {
    //            "Content-Type": "application/json"
    //        }
    //    }).success(function (response) {
    //        swal("Successfully updated!!")
    //    }).error(function (error) {
    //        sweetAlert("Oops...", "Something went wrong!", "error");
    //    });
    //}
}]);
