﻿var app = angular.module('Home', ['checklist-model']);

app.filter('unique', function() {
   return function(collection, keyname) {
      var output = [], 
          keys = [];

      angular.forEach(collection, function(item) {
          var key = item[keyname];
          if(keys.indexOf(key) === -1) {
              keys.push(key);
              output.push(item);
          }
      });
      return output;
   };
});

app.controller("homeCtrl", ["$scope","$http","$rootScope", "$interval",'$compile','$window', "config",function ( $scope,$http,$rootScope,$interval,$compile,$window,config) {

	  $scope.allAlert = false;
	  $scope.showLess = true;
	  
	  $scope.showList=function(){
		$scope.allAlert = !$scope.allAlert;
		$scope.showLess = !$scope.showLess;
    	$http({ method: 'GET', url: config.globalUrl+'student/listAlert', dataType: "json", contentType: "application/json; charset=utf-8" })
        .success(function (data, status) {
            $scope.list = data;       
        })
        .error(function (data, status) {
            alert("Error");
        });	
    }
	 
	$scope.showStudId=function(alrId){
		$http({ method: 'GET', url: config.globalUrl+'student/listAlertId/'+alrId, dataType: "json", contentType: "application/json; charset=utf-8" })
		.success(function (data, status) {
			$scope.studId = data;
		})
    	.error(function (data, status) {
    		alert("Error");
    	});
		$('.AlrModel').modal({
        	show: true
        });
	}
 
	var batteryLow=function(){
		console.log("success");
		$http({ method: 'GET', url: config.globalUrl+'student/listAlert', dataType: "json", contentType: "application/json; charset=utf-8" })
		.success(function (data, status) {
			$scope.list = data;
		})
    	.error(function (data, status) {
    		alert("Error");
    	});
	}
    var startCountdown = function(){
		$interval(batteryLow, 60000);
    }
    batteryLow();
    startCountdown();
    $scope.getCount = function (i) {
		    var iCount = iCount || 0;
		    for (var j = 0; j < $scope.list.length; j++) {
		        if ($scope.list[j].alertDesc == i) {
		            iCount++;
		        }
		    }
		    return iCount;
		}
    
    
    
    $scope.selected = {
            alertsid: []
    };
    
    $scope.dismissId = function(){
    	$http({ method: 'PUT', url: config.globalUrl+'student/updStatus/'+$scope.selected.alertsid, dataType: "json", contentType: "application/json; charset=utf-8" })
		.success(function (data, status) {
			$scope.listupd = data;
			batteryLow();
		})
		.error(function (data, status) {
  		alert("Error");
		});
    };
        
    $scope.dismissAll = function() {
             $scope.selected.alertsid = $scope.list.map(function(item) { return item.alertId; });
             $http({ method: 'PUT', url: config.globalUrl+'student/updStatus/'+$scope.selected.alertsid, dataType: "json", contentType: "application/json; charset=utf-8" })
       		.success(function (data, status) {
       			$scope.listupd = data;
       			batteryLow();
       		})
           	.error(function (data, status) {
           		alert("Error");
           	});
     };
     
    $scope.uncheckAll = function() {
              $scope.selected.alertsid = [];
          };
          
    $scope.updStatus=function(alrId){
      		$http({ method: 'PUT', url: config.globalUrl+'student/updStatus/'+alrId, dataType: "json", contentType: "application/json; charset=utf-8" })
      		.success(function (data, status) {
      			$scope.listupd = data;
      			batteryLow();
      		})
          	.error(function (data, status) {
          		alert("Error");
          	});
      	}     
          
        $scope.LogoutController = function ($location) {
        	window.location.href = "../../..";
        };
        
}]);



