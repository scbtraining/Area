﻿angular.module("tracking", [])
.controller("trackingCtrl", ["$scope","$http","config", function ($scope,$http,config) {   	
	
	$scope.getData = function(){   	
		$http({ 
			method: 'GET', 
			url: config.globalUrl+"getStudentTraceDetails", 
			dataType: "json", 
			contentType: "application/json; charset=utf-8" })
        .success(function (data, status) {
            $scope.SchoolList = data;
            $scope.list = $scope.SchoolList;
            $scope.totalItems = $scope.list.length;
            $scope.currentPage = 1;
            $scope.numPerPage = 5;
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
	};
	
	$scope.showTrack = function(sid,cid){		
		console.log("SID--> " + sid + " CID--> " + cid);
		$http({ 
			method: 'GET',
			url: config.globalUrl+'trackStudent?studentID='+sid+'&classID='+cid, 
			dataType: "json", 
			contentType: "application/json; charset=utf-8"  
		})
        .success(function (data, status) {
        	console.log(data);
            $scope.TrackStuList = data;
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
	};
	
	 // Pagination
    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }

    $scope.paginate = function (value) {
        var begin, end, index;
        begin = ($scope.currentPage - 1) * $scope.numPerPage;
        end = begin + $scope.numPerPage;
        index = $scope.list.indexOf(value);
        return (begin <= index && index < end);
    };
    // Pagination End    
    	
	 var init = function(){
	    	$scope.getData();
	  }
	  init();
}]);