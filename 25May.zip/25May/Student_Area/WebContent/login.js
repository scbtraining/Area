angular.module('mainApp', [])
.controller('loginCtrl', ['$scope', '$rootScope', '$http', function ($scope, $rootScope, $http) {
	
  $scope.login = function(username, password){
	
	  console.log("username" + username);
	  console.log("password" + password)
	  
	  if (username != null && password != null) {
	  $http({		  
          url: 'http://10.30.55.109:8080/mining_latest/Login?username='+username+'&password='+password,
		  /*url: 'http://10.30.55.108:8090/mining_latest/Login?username='+username+'&password='+password,*/
          dataType: 'json',
          method: 'POST',             
          headers: {
              "Content-Type": "application/json"
          }
      }).success(function (response) {
    	  if(response.users_user_name != null && response.users_password != null){

    		  window.location.href = "modules/home/views/home.html";       	
    	  }else{
    		  sweetAlert("Oops...", "Something went wrong!", "error"); 
    	  }     	 
          //swal("Successfully Login!!")
      }).error(function (error) {
          sweetAlert("Oops...", "Something went wrong!", "error");
      });
	  }else{
		  sweetAlert("Oops...", "Something went wrong!", "error");
	  }	  
  }
  
}])
