angular.module("readerMaster", ['angular-table', 'ui.bootstrap', 'ngResource'])

.controller("readerMasterCtrl", ["$rootScope", "$scope", "$http", "$window", "config", function ($rootScope, $scope, $http, $window, config) {
	/*var readerUrl = 'http://10.30.55.104:8090/mining_latest/';*/
	
	// Get Data
	$scope.getMasterData = function(){
		$http({ 
			method: 'GET', 
			url: config.globalUrl+'getAllReaderDetails', 
			dataType: "json", 
			contentType: "application/json; charset=utf-8"  
		})
        .success(function (data, status) {
            $scope.SchoolList = data;
            $scope.SchoolList = $scope.SchoolList;
            $scope.totalItems = $scope.SchoolList.length;
            $scope.currentPage = 1;
            $scope.numPerPage = 5;
        })
        .error(function (data, status) {
            sweetAlert("Oops...", "Something went error!", "error");
        });
	};    
	// Get Data End
	
	 // Save
    $scope.register = function(studentRdr){
    	console.log("Request-->" + studentRdr);
    	 $http({
             url: config.globalUrl+'updateReaderDetail',
             dataType: 'json',
             method: 'POST',
             data: studentRdr,
             headers: {
                 "Content-Type": "application/json"
             }
         }).success(function (response) {
        	 console.log("response -->" + response)
             swal("Successfully updated!!")
             $("#ReaderAdd").modal("hide");
             
             $scope.getMasterData();
         }).error(function (error) {
             sweetAlert("Oops...", "Something went wrong!", "error");
         });
    }
    // Save end
	
    // delete 
    $scope.deleteUser = function (id, index) {    	
    	console.log("Deleter User-->" + id);
    	$http({
            url: config.globalUrl+'deleteReaderDetail?readerConfID='+id,
            dataType: 'json',
            method: 'GET',            
            headers: {
                "Content-Type": "application/json"
            }
        }).success(function (response) {            
        	swal("Successfully Deleted!!")
        	$scope.getMasterData();            
        }).error(function (error) {
            sweetAlert("Oops...", "Something went wrong!", "error");
        });
    	         	
    };
    // delete end
    
    // Edit
    $scope.UpdateStu = function (sRdr) {    	
    	console.log("update User--> " + sRdr);
    	 $http({
             url: config.globalUrl+'updateReaderDetail',
             dataType: 'json',
             method: 'POST',
             data: sRdr,
             headers: {
                 "Content-Type": "application/json"
             }
         }).success(function (response) {
             swal("Successfully updated!!");
             $("#schooledit").modal("hide"); 
             $scope.getMasterData();
         }).error(function (error) {
             sweetAlert("Oops...", "Something went wrong!", "error");
         });
    	         	
    };
    // Edit end

    // Dropdown value for Reader Types
    $scope.SelectReader = function () {    	
    	 $http.get(config.globalUrl+"getAllReaderType")
    	    .then(function(response) {
    	    	$scope.readerTypes = response.data;
    	    	 //$scope.selectedOption = $scope.readerTypes[0];
    	    });
    };   
    // Dropdown value for Reader Types End
    
    $scope.EditUser = function (user) {
        $scope.sReader = user;

    };
    
    
    // Pagination
    $scope.sort = function (keyname) {
        $scope.sortKey = keyname;   //set the sortKey to the param passed
        $scope.reverse = !$scope.reverse; //if true make it false and vice versa
    }

    $scope.paginate = function (value) {
        var begin, end, index;
        begin = ($scope.currentPage - 1) * $scope.numPerPage;
        end = begin + $scope.numPerPage;
        index = $scope.SchoolList.indexOf(value);
        return (begin <= index && index < end);
    };
    // Pagination End
    
    var init = function(){
    	$scope.getMasterData();
    	$scope.SelectReader();    	    	
    }
    init();
}]);

