﻿var app = angular.module('alert', []);

app.filter('unique', function() {
	   return function(collection, keyname) {
	      var output = [], 
	          keys = [];

	      angular.forEach(collection, function(item) {
	          var key = item[keyname];
	          if(keys.indexOf(key) === -1) {
	              keys.push(key);
	              output.push(item);
	          }
	      });
	      return output;
	   };
	  
	});

app.controller("alertCtrl", ["$scope","$http","$interval","config", function ($scope,$http,$interval,config) {
	
	var alerDts=function(){
	    $http({ method: 'GET', url: config.globalUrl+'student/fetchAlert', dataType: "json", contentType: "application/json; charset=utf-8" })
	    .success(function (data, status) {
	        $scope.alrList = data;
	        $scope.totalItems = $scope.alrList.length;
            $scope.currentPage = 1;
            $scope.numPerPage = 5;
	    })
	    .error(function (data, status) {
	        alert("Error");
	    });

	}
	$scope.sendSms=function(alrStuId){
    	$http({ method: 'GET', url: config.globalUrl+'student/sms/'+alrStuId, dataType: "json", contentType: "application/json; charset=utf-8" })
        .success(function (data, status) {    
        	alert("SMS sent successfully")
        })
        .error(function (data, status) {
            alert("Error");
        });
    	
    }
	$scope.paginate = function (value) {
	        var begin, end, index;
	        begin = ($scope.currentPage - 1) * $scope.numPerPage;
	        end = begin + $scope.numPerPage;
	        index = $scope.alrList.indexOf(value);
	        return (begin <= index && index < end);
	    };
    var startCountdown = function(){
		$interval(alerDts, 60000);
    }
    alerDts();
    startCountdown();
	
	
}]);