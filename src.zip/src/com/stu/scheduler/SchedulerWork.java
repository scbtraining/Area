package com.stu.scheduler;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.sql.DataSource;

import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.jdbc.core.JdbcTemplate;

@Configurable
public class SchedulerWork  {
	
	
	 private DataSource dataSource;
	 
	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}


	private JdbcTemplate jdbcTemplate;
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	
	@SuppressWarnings("unused")
	public void xmlCronTask() throws SchedulerException, ParseException, SQLException{
		System.out.println(new Date() + " sampleApp");
		Connection con=null;
		try {
			
			con=dataSource.getConnection();
			 int readerId=getRandomInt(1,20); //1-20
			 int clientid=978065412; //static
			 int card_id=(int)((Math.random()*99)+10);//dynamic
			 int body_t=getRandomInt(97,102);//97-102
			 String body_Temp=Integer.toString(body_t);
			 int step_count=(int)((Math.random()*9)+0);//dynamic
			 int battary_volt=(int)((Math.random()*9)+20);//dynamic
			int signal_Strength=(int)((Math.random()*99)+10);//dynamic
			 float	calories=(float) (Math.round(((Math.random()*9)+20)*100.0)/100.0);//dynamic
			 String val=""+readerId+"|"+clientid+"|"+card_id+"|"+body_Temp+"|"+step_count+"|"+calories+"|"+battary_volt+"|"+signal_Strength;
			 System.out.println(readerId+"\t"+val);
			create(readerId,val);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	@Deprecated
	public void insertReader(){
		System.out.println(new Date() + " insert Reader");
		Connection con=null;
		try{
			con=dataSource.getConnection();
			String sql="select * from watchnow";
		List<Map<String,Object>> val=getJdbcTemplate().queryForList(sql);
		for (Map map:val){
			Object  id=map.get("id");
			String rawdata=map.get("rawdata").toString();
			System.out.println("id value \t"+id.toString()+ "raw data\t"+rawdata);
			StringTokenizer strToken=new StringTokenizer(rawdata,"|");
			while (strToken.hasMoreElements()) {
				int reader_id=Integer.parseInt(strToken.nextElement() .toString());
				int client_id=Integer.parseInt(strToken.nextElement().toString());
				int card_id=Integer.parseInt(strToken.nextElement().toString());
				String body_temp=strToken.nextElement().toString();
				int step_count=Integer.parseInt(strToken.nextElement().toString());
				Float calories=Float.parseFloat(strToken.nextElement().toString());
				int battary_volt=Integer.parseInt(strToken.nextElement().toString());
				int signal_Strength=Integer.parseInt(strToken.nextElement().toString());
				 Timestamp timestamp = new Timestamp(System.currentTimeMillis());
				insert(reader_id,client_id,card_id,body_temp,step_count,calories,battary_volt,signal_Strength,timestamp);
			}
		}
		
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void insertReaderObj(){
		System.out.println(new Date() + " insert Reader");
		Connection con=null;
		try{
			con=dataSource.getConnection();
			String sql = "SELECT id,SUBSTRING_INDEX(rawdata, '|', 1) AS col1,"
					+ "SUBSTRING_INDEX(SUBSTRING_INDEX(rawdata, '|', 2),'|', -1) AS col2, "
					+ "SUBSTRING_INDEX(SUBSTRING_INDEX(rawdata, '|', 3),'|', -1) AS col3, "
					+ "SUBSTRING_INDEX(SUBSTRING_INDEX(rawdata, '|', 4),'|', -1) AS col4,	"
					+ "SUBSTRING_INDEX(SUBSTRING_INDEX(rawdata, '|', 5),'|', -1) AS col5,"
					+ "SUBSTRING_INDEX(SUBSTRING_INDEX(rawdata, '|', 6),'|', -1) AS col6,"
					+ "SUBSTRING_INDEX(SUBSTRING_INDEX(rawdata, '|', 7),'|', -1) AS col7,"
					+ "SUBSTRING_INDEX(SUBSTRING_INDEX(rawdata, '|', 8),'|', -1) AS col8,"
					+ "SUBSTRING_INDEX(SUBSTRING_INDEX(rawdata, '|', 9),'|', -1) AS col9 FROM watchnow";
		List<Map<String,Object>> val=getJdbcTemplate().queryForList(sql);
		for (Map map:val){
			
			Object  id=map.get("id");
			
			int reader_id=Integer.parseInt(map.get("col1").toString());
			int client_id=Integer.parseInt(map.get("col2").toString());
			int card_id=Integer.parseInt(map.get("col3").toString());
			String body_temp=map.get("col4").toString();
			int step_count=Integer.parseInt(map.get("col5").toString());
			Float calories=Float.parseFloat(map.get("col6").toString());
			int battary_volt=Integer.parseInt(map.get("col7").toString());
			int signal_Strength=Integer.parseInt(map.get("col8").toString());
			
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			insert(reader_id,client_id,card_id,body_temp,step_count,calories,battary_volt,signal_Strength,timestamp);
			 
		}
		
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	
	private void insert(int reader_id, int client_id, int card_id,
			String body_temp, int step_count, Float calories, int battary_volt,
			int signal_Strength, Timestamp timestamp) {
		// TODO Auto-generated method stub
		
		String sql="insert into reader (READER_ID,CLIENTID,CARDID,BODY_TEMP,STEP_COUNT,CALORIES,BATTARY_VOLT,SIGNAL_STRENGHT,ENTRY_TIME) values"
				+ " (?,?,?,?,?,?,?,?,?)";
		
		jdbcTemplate.update(sql, reader_id,client_id,card_id,body_temp,step_count,calories,battary_volt,signal_Strength,timestamp);
		
	}
	private void create(int id, String rawdata) {
		// TODO Auto-generated method stub
		String SQL = "insert into watchnow (id, rawdata) values (?, ?)";
		jdbcTemplate.update( SQL, id,rawdata);
	      
		
	}
	private static int getRandomInt(int min, int max) {
//		 Random r = new Random();
//			return r.nextInt((max - min) + 1) + min;
		    return (int) (Math.floor(Math.random() * (max - min + 1)) + min);
		}
	
}
