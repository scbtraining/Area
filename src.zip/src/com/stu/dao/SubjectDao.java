package com.stu.dao;

import java.util.List;

import com.stu.exception.SubjectException;
import com.stu.model.Subject;
import com.stu.model.SubjectClass;
import com.stu.model.JSON.SubjectInfo;


public interface SubjectDao {
	
	String saveSubject(SubjectInfo addSubjectInfo) throws SubjectException;
	
	List<SubjectInfo> fetchSubjectData(int subjectId) throws SubjectException;
	
	List<SubjectInfo> fetchSubjectData() throws SubjectException;
	
	String deleteSubject(int subjectId) throws SubjectException;
	
}
