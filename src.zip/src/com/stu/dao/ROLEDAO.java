package com.stu.dao;

import java.util.List;

import com.stu.exception.ROLEException;
import com.stu.model.ROLE;
import com.stu.model.JSON.ROLEInfo;


public interface ROLEDAO {
	
	String saveAddROLE(ROLE addROLE)throws ROLEException;
	
	List<ROLEInfo> fetchAROLEData(int ROLEid)throws ROLEException;
	
	List<ROLEInfo> fetchAllROLEData()throws ROLEException;
	
}
