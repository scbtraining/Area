package com.stu.dao;

import com.stu.exception.LOGINException;
import com.stu.model.JSON.UsersInfo;


public interface LOGINDAO {
	
	UsersInfo checkData(String username, String password)throws LOGINException;	
	
}
