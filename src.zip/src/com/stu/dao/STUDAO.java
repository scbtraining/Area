package com.stu.dao;

import java.math.BigDecimal;
import java.util.List;

import com.stu.exception.STUDENTException;
import com.stu.model.STUD;
import com.stu.model.JSON.STUDInfo;


public interface STUDAO {
	
	String saveAddSTUD(STUD addSTUD)throws STUDENTException;
	
	List<STUDInfo> fetchASTUDData(int STUDid)throws STUDENTException;
	
	List<STUDInfo> fetchAllSTUDData()throws STUDENTException;
	
	/*BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException;*/
	
}
