package com.stu.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.stu.exception.SCHOOLException;


public abstract class AbstractSchoolDao<PK extends Serializable, T> {

	private final Class<T> persistentClass;

	@SuppressWarnings("unchecked")
	public AbstractSchoolDao() {
		this.persistentClass = (Class<T>) ((ParameterizedType) this.getClass()
				.getGenericSuperclass()).getActualTypeArguments()[1];
	}

	@Autowired
	private SessionFactory sessionFactory1;

	protected Session getSession() throws SCHOOLException {
		Session session = sessionFactory1.getCurrentSession();
		if (null == session) {
			session = sessionFactory1.openSession();
		}
		return session;
	}

	@SuppressWarnings("unchecked")
	public T getByKey(PK key) throws SCHOOLException {
		return (T) getSession().get(persistentClass, key);
	}

	public void persist(T entity) throws SCHOOLException {
		Session session = null;
		Transaction trans = null;
		try {
			session = getSession();
			trans = session.beginTransaction();
			session.persist(entity);
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			throw new SCHOOLException("Exception occured:", e.getMessage());
		}
	}

	public void saveOrUpdate(T entity) throws SCHOOLException {
		Session session = null;
		Transaction trans = null;
		try {
			session = getSession();
			trans = session.beginTransaction();
			session.saveOrUpdate(entity);
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			System.out.println("Exception in abstract schol dao:: "+e);
			throw new SCHOOLException("Error occured:", e.getMessage());
		}
	}
	
	protected Criteria createEntityCriteria() throws SCHOOLException {
		return getSession().createCriteria(persistentClass);
	}

}