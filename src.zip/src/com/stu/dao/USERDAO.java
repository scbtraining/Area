package com.stu.dao;

import java.math.BigDecimal;
import java.util.List;

import com.stu.exception.STUDENTException;
import com.stu.exception.USERException;
import com.stu.model.STUD;
import com.stu.model.USER;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.USERInfo;


public interface USERDAO {
	
	String saveAddUSER(USER addUSER)throws USERException;
	
	List<USERInfo> fetchAUserData(Integer userId)throws USERException;
	
	List<USERInfo> fetchAllUserData()throws USERException;
	
	
	
}
