package com.stu.dao;

import java.math.BigDecimal;
import java.util.List;

import com.stu.exception.FEEException;
import com.stu.exception.STUDENTException;
import com.stu.model.FEE;
import com.stu.model.STUD;
import com.stu.model.JSON.FEEInfo;
import com.stu.model.JSON.STUDInfo;


public interface FEEDAO {
	
	String saveAddFEE(FEE addFEE)throws FEEException;
	
	List<FEEInfo> fetchAFEEData(int FEEid)throws FEEException;
	
	List<FEEInfo> fetchFEEData()throws FEEException;
	
	//BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException;*/
	
}
