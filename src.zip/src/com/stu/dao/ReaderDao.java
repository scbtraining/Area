package com.stu.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.stu.exception.FEEException;
import com.stu.exception.STUDENTException;
import com.stu.model.AreaRange;
import com.stu.model.AreaRangePoint;
import com.stu.model.Building;
import com.stu.model.ReaderConfig;
import com.stu.model.ReaderType;
import com.stu.model.Student;
import com.stu.model.StudentInformation;
import com.stu.model.JSON.AccessDetailsDto;
import com.stu.model.JSON.AreaRangeInfo;
import com.stu.model.JSON.AreaRangePointInfo;
import com.stu.model.JSON.BuildingInfo;
import com.stu.model.JSON.ReaderConfigInfo;
import com.stu.model.JSON.ReaderTypeInfo;
import com.stu.model.App_Config_Master;
import com.stu.model.JSON.App_Config_Master_Info;
import com.stu.model.JSON.Student_Count_Info;



@Component
public class ReaderDao {
	
	//private static SessionFactory factory=new AnnotationConfiguration().configure().buildSessionFactory();;
	
	@Autowired
	private SessionFactory sessionFactory1;

	protected Session getSession() throws Exception {
		Session session = sessionFactory1.getCurrentSession();
		if (null == session) {
			session = sessionFactory1.openSession();
		}
		return session;
	}
	
	@SuppressWarnings("deprecation")
	
	
	public List<Student> fetchStudentDetails(Student stu) throws Exception {
		Session session = null;
		Transaction tx = null;
		List<Student> studentList = null;
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

	int	studentID = stu.getClientID();
		try {
			session = getSession();
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select a.CLIENTID, a.READERID, a.CARDID, a.BATTERYVOLT, a.STEPTRAVELLED, a.CALORIES, a.SIGNALSTRENGTH, a.SDAY, a.SMONTH, a.SYEAR, a.SHOUR, a.SMINS, a.SSECS, a.SLONGTITUDE, a.SLATITUDE, a.SALTITUDE, a.SOTHERS, c.ROLLNO, c.STUDENTINFOID, c.STUDENTNAME, c.STUDENTCLASS, c.STUDENTSECTION, c.ADMISSIONNO, c.DOA, c.DOB from STUDENTREADER a,STUDENTMASTERINFO b, STUDENTINFO c where a.READERID=b.READERID and a.CLIENTID= b.STUDENTID and b.STUDENTID= c.STUDENTID and b.STUDENTID ='"
					+ studentID + "'";
			System.out.println("QUERY IS : " + sql);
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			studentList = new ArrayList<Student>();
			for (Object[] row : results) {
				Student studList = new Student();
				
				int clientID = 0;
				if (row[0] != null && row[0] != "") {
					clientID =Integer.parseInt(row[0].toString());
					studList.setClientID(clientID);
				}
				int readerID = 0;
				if (row[1] != null && row[1] != "") {
					readerID =Integer.parseInt(row[1].toString());
					studList.setReaderID(readerID);
				}
				int cardId = 0;
				if (row[2] != null && row[2] != "") {
					cardId =Integer.parseInt(row[2].toString());					
					studList.setCardId(cardId);
				}
				int batVolt =0;
				if (row[3] != null && row[3] != "") {
					batVolt =Integer.parseInt(row[3].toString());					
					studList.setBatVolt(batVolt);
				}
				int stepTrav=0;
				if (row[4] != null && row[4] != "") {
					stepTrav =Integer.parseInt(row[4].toString());				
					studList.setStepTrav(stepTrav);
				}
				int calories=0;
				if (row[5] != null && row[5] != "") {
					calories =Integer.parseInt(row[5].toString());				
					studList.setCalories(calories);
				}
				int signalsrgth=0;
				if (row[6] != null && row[6] != "") {
					signalsrgth =Integer.parseInt(row[6].toString());					
					studList.setSignalsrgth(signalsrgth);
				}
				int sDay=0;
				if (row[7] != null && row[7] != "") {
					sDay =Integer.parseInt(row[7].toString());					
					studList.setsDay(sDay);
				}
				int sMon=0;
				if (row[8] != null && row[8] != "") {
					sMon =Integer.parseInt(row[8].toString());				
					studList.setsMon(sMon);
				}
				int sYr =0;
				if (row[9] != null && row[9] != "") {
					sYr =Integer.parseInt(row[9].toString());			
					studList.setsYr(sYr);
				}
				int sHR=0;
				if (row[10] != null && row[10] != "") {
					sHR =Integer.parseInt(row[10].toString());				
					studList.setsHR(sHR);
					
				}
				int smins=0;
				if (row[11] != null && row[11] != "") {
					smins =Integer.parseInt(row[11].toString());
					studList.setSmins(smins);
					
				}
				int sSecs=0;
				if (row[12] != null && row[12] != "") {
					sSecs =Integer.parseInt(row[12].toString());
				
					studList.setSmins(sSecs);;
				}
				
				float sLng=0;
				if (row[13] != null && row[13] != "") {
					sLng =Integer.parseInt(row[13].toString());					
					studList.setsLng(sLng);
				}
				float sLat =0;
				if (row[14] != null && row[14] != "") {
					sLat =Float.parseFloat(row[14].toString());					
					studList.setsLat(sLat);
				}
				float sAlt=0;
				if (row[15] != null && row[15] != "") {
					sAlt = Float.parseFloat(row[15].toString());					
					studList.setsAlt(sAlt);
					
				}
				String sOthers="";
				if (row[16] != null && row[16] != "") {
					sOthers =row[16].toString();				
					studList.setsOthers(sOthers);
					
				}
				String rollNo="";
				if (row[17] != null && row[17] != "") {
					rollNo =row[17].toString();				
					studList.setRollNo(rollNo);
					
				}
				int studentinfoID=0;
				if (row[18] != null && row[18] != "") {
					studentinfoID =Integer.parseInt(row[18].toString());
					studList.setStudentInfoID(studentinfoID);
					
				}
				String studentName="";
				if (row[19] != null && row[19] != "") {
					studentName =row[19].toString();				
					studList.setStudentName(studentName);
					
				}
				String studentClass="";
				if (row[20] != null && row[20] != "") {
					studentClass =row[20].toString();				
					studList.setStudentClass(studentClass);
					
				}
				String studentSection="";
				if (row[21] != null && row[21] != "") {
					studentSection =row[21].toString();				
					studList.setStudentSection(studentSection);
					
				}
				String admissionNo="";
				if (row[22] != null && row[22] != "") {
					admissionNo =row[22].toString();				
					studList.setAdmissionNo(admissionNo);
					
				}
				String doa = "";
				if (row[23] != null && row[23] != "") {
					doa = row[23].toString();
					Date doaDate = null;
					try {
						doaDate = df.parse(doa);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					studList.setDoa(doaDate);
				}
				String dob = "";
				if (row[24] != null && row[24] != "") {
					dob = row[24].toString();
					Date dobDate = null;
					try {
						dobDate = df.parse(dob);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					studList.setDob(dobDate);
				}
				studentList.add(studList);
			}
				
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//if(session!=null)
			//session.close();
		}
		return studentList;
	}
	
	public List<Student> getStudentDetails() throws Exception {
		Session session = null;
		Transaction tx = null;
		List<Student> studentList = null;
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");

		try {
			session = getSession();
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select a.CLIENTID, a.READERID, a.CARDID, a.BATTERYVOLT, a.STEPTRAVELLED, a.CALORIES, a.SIGNALSTRENGTH, a.SDAY, a.SMONTH, a.SYEAR, a.SHOUR, a.SMINS, a.SSECS, a.SLONGTITUDE, a.SLATITUDE, a.SALTITUDE, a.SOTHERS, c.ROLLNO, c.STUDENTINFOID, c.STUDENTNAME, c.STUDENTCLASS, c.STUDENTSECTION, c.ADMISSIONNO, c.DOA, c.DOB from STUDENTREADER a,STUDENTMASTERINFO b, STUDENTINFO c where a.READERID=b.READERID and a.CLIENTID= b.STUDENTID and b.STUDENTID= c.STUDENTID";
			System.out.println("QUERY IS : " + sql);
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			studentList = new ArrayList<Student>();
			for (Object[] row : results) {
				Student studList = new Student();
				
				int clientID = 0;
				if (row[0] != null && row[0] != "") {
					clientID =Integer.parseInt(row[0].toString());
					studList.setClientID(clientID);
				}
				int readerID = 0;
				if (row[1] != null && row[1] != "") {
					readerID =Integer.parseInt(row[1].toString());
					studList.setReaderID(readerID);
				}
				int cardId = 0;
				if (row[2] != null && row[2] != "") {
					cardId =Integer.parseInt(row[2].toString());					
					studList.setCardId(cardId);
				}
				int batVolt =0;
				if (row[3] != null && row[3] != "") {
					batVolt =Integer.parseInt(row[3].toString());					
					studList.setBatVolt(batVolt);
				}
				int stepTrav=0;
				if (row[4] != null && row[4] != "") {
					stepTrav =Integer.parseInt(row[4].toString());				
					studList.setStepTrav(stepTrav);
				}
				int calories=0;
				if (row[5] != null && row[5] != "") {
					calories =Integer.parseInt(row[5].toString());				
					studList.setCalories(calories);
				}
				int signalsrgth=0;
				if (row[6] != null && row[6] != "") {
					signalsrgth =Integer.parseInt(row[6].toString());					
					studList.setSignalsrgth(signalsrgth);
				}
				int sDay=0;
				if (row[7] != null && row[7] != "") {
					sDay =Integer.parseInt(row[7].toString());					
					studList.setsDay(sDay);
				}
				int sMon=0;
				if (row[8] != null && row[8] != "") {
					sMon =Integer.parseInt(row[8].toString());				
					studList.setsMon(sMon);
				}
				int sYr =0;
				if (row[9] != null && row[9] != "") {
					sYr =Integer.parseInt(row[9].toString());			
					studList.setsYr(sYr);
				}
				int sHR=0;
				if (row[10] != null && row[10] != "") {
					sHR =Integer.parseInt(row[10].toString());				
					studList.setsHR(sHR);
					
				}
				int smins=0;
				if (row[11] != null && row[11] != "") {
					smins =Integer.parseInt(row[11].toString());
					studList.setSmins(smins);
					
				}
				int sSecs=0;
				if (row[12] != null && row[12] != "") {
					sSecs =Integer.parseInt(row[12].toString());
				
					studList.setSmins(sSecs);
				}
				
				float sLng=0;
				if (row[13] != null && row[13] != "") {
					sLng =Integer.parseInt(row[13].toString());					
					studList.setsLng(sLng);
				}
				float sLat =0;
				if (row[14] != null && row[14] != "") {
					sLat =Float.parseFloat(row[14].toString());					
					studList.setsLat(sLat);
				}
				float sAlt=0;
				if (row[15] != null && row[15] != "") {
					sAlt = Float.parseFloat(row[15].toString());					
					studList.setsAlt(sAlt);
					
				}
				String sOthers="";
				if (row[16] != null && row[16] != "") {
					sOthers =row[16].toString();				
					studList.setsOthers(sOthers);
					
				}
				String rollNo="";
				if (row[17] != null && row[17] != "") {
					rollNo =row[17].toString();				
					studList.setRollNo(rollNo);
					
				}
				int studentinfoID=0;
				if (row[18] != null && row[18] != "") {
					studentinfoID =Integer.parseInt(row[18].toString());
					studList.setStudentInfoID(studentinfoID);
					
				}
				String studentName="";
				if (row[19] != null && row[19] != "") {
					studentName =row[19].toString();				
					studList.setStudentName(studentName);
					
				}
				String studentClass="";
				if (row[20] != null && row[20] != "") {
					studentClass =row[20].toString();				
					studList.setStudentClass(studentClass);
					
				}
				String studentSection="";
				if (row[21] != null && row[21] != "") {
					studentSection =row[21].toString();				
					studList.setStudentSection(studentSection);
					
				}
				String admissionNo="";
				if (row[22] != null && row[22] != "") {
					admissionNo =row[22].toString();				
					studList.setAdmissionNo(admissionNo);
					
				}
				String doa = "";
				if (row[23] != null && row[23] != "") {
					doa = row[23].toString();
					Date doaDate = null;
					try {
						doaDate = df.parse(doa);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					studList.setDoa(doaDate);
				}
				String dob = "";
				if (row[24] != null && row[24] != "") {
					dob = row[24].toString();
					Date dobDate = null;
					try {
						dobDate = df.parse(dob);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					studList.setDob(dobDate);
				}
				
				
				studentList.add(studList);
			}
				
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//if(session!=null)
			//session.close();
		}
		return studentList;
	}


	public List<AreaRangePoint> getStudentRange(AreaRangePoint building) throws Exception {
		return null;
	}

	public List<Building> getStudentRange(Building building) throws Exception {
		Session session = null;
		Transaction tx = null;
		List<Building> buildingList = null;
		int studentID = building.getStudentID();
		try {
			session = getSession();
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "SELECT a.BUILDINGID,a.BUILDINGNAME,a.POINTID,a.LATITUDE,LONGTITUDE,b.CLIENTID FROM STUDENTBUILDINGMASTER a,STUDENTREADER b where a.LATITUDE = b.SLATITUDE and a.LONGTITUDE = b.SLONGTITUDE and b.CLIENTID ='"+ studentID + "'";
			System.out.println("QUERY IS : " + sql);
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			buildingList = new ArrayList<Building>();
			for (Object[] row : results) {
				Building buildList = new Building();
				
				buildList.setBuildingID(studentID);
				
				String buildingName = "";
				if (row[1] != null && row[1] != "") {
					buildingName =row[1].toString();
					buildList.setBuildingName(buildingName);
				}
				int pointID = 0;
				if (row[2] != null && row[2] != "") {
					pointID =Integer.parseInt(row[2].toString());					
					buildList.setPointID(pointID);
				}
				float lat =0;
				if (row[3] != null && row[3] != "") {
					lat =Float.parseFloat(row[3].toString());					
					buildList.setLat(lat);
				}
				float lng=0;
				if (row[4] != null && row[4] != "") {
					lng =Float.parseFloat(row[4].toString());				
					buildList.setLng(lng);
				}
				buildingList.add(buildList);
			}
				
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//if(session!=null)
			//session.close();
		}
		return buildingList;
	}
	
	public void saveProduct(AreaRange areaRange) {

		/* Add few employee records in database */
		try {
			addProduct(areaRange);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	private void addProduct(AreaRange areaRange) throws Exception {
		Session session = getSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(areaRange);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}
		
	}
	
	public void deleteAreaRange(Integer buildingId) throws Exception {
		Session session = getSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			String hql1 = "delete from STUDENT_AREA_RANGE_POINT_DTL where BUILDINGID= :id";
	        Query query1 = session.createSQLQuery(hql1);
	        query1.setInteger("id", buildingId);
	        query1.executeUpdate();
			String hql = "delete from STUDENT_AREA_RANGE where BUILDINGID= :id";
	        Query query = session.createSQLQuery(hql);
	        query.setInteger("id", buildingId);
	        query.executeUpdate();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}
		
	}
	public String saveAreaRangeDetails(AreaRangeInfo areaRangeInfo) throws Exception
	{
		Session session = getSession();
		Transaction tx = null;
		String returnMsg="";
		try {
			
			
			if(null!=areaRangeInfo){
				AreaRange areaRange=new AreaRange();
				areaRange.setBuildingName(areaRangeInfo.getBuildingName());
				List<AreaRangePoint> areaRangePointList=new ArrayList<AreaRangePoint>();
				if(areaRangeInfo.getBuildingpoints().size()>0)
				{
					tx = session.beginTransaction();
					for(BuildingInfo info:areaRangeInfo.getBuildingpoints()){
						AreaRangePoint areaPoint=new AreaRangePoint();
						areaPoint.setLat(info.getLat());
						areaPoint.setLng(info.getLng());
						areaRangePointList.add(areaPoint);
					}
				}
				areaRange.setBulindingList(areaRangePointList);
				session.saveOrUpdate(areaRange);
				tx.commit();
				returnMsg="success";
			}
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
		}
		return returnMsg;
	}
	
	@SuppressWarnings("unchecked")
	public List<AreaRange> fetchAreaRange() throws Exception {
		List<AreaRange> areaRangeList = new ArrayList<AreaRange>();
		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			Query query = session.createQuery("from AreaRange");
			List<AreaRange> Querylist = query.list();
			if(null != Querylist) {
				for(AreaRange areaRangeobj : Querylist) {
					AreaRange areaRangeInfo = new AreaRange();
					areaRangeInfo.setBuildingId(areaRangeobj.getBuildingId());
					areaRangeInfo.setBuildingName(areaRangeobj.getBuildingName());
					areaRangeList.add(areaRangeInfo);
				}
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return areaRangeList;
	}
	
	@SuppressWarnings("unchecked")
	public List<AreaRangePointInfo> fetchAreaRangeDetails() throws Exception {
		List<AreaRangePointInfo> areaRangeInfoList = new ArrayList<AreaRangePointInfo>();
		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			Query query = session.createQuery("from AreaRange");
			List<AreaRange> rangelist = query.list();
			if(null != rangelist) {
				for(AreaRange areaRangeobj : rangelist) {
					AreaRangePointInfo info=new AreaRangePointInfo();
					info.setBuildingId(areaRangeobj.getBuildingId());
					info.setBuildingName(areaRangeobj.getBuildingName());
					List<Map<String,String>> pointlist=new ArrayList<Map<String,String>>();
					if(areaRangeobj.getBulindingList().size()>0)
					{
						for(AreaRangePoint point: areaRangeobj.getBulindingList())
						{
							Map<String,String> pointsMap=new HashMap<String, String>();
							pointsMap.put("pointId",point.getPointId()+"");
							pointsMap.put("pointLat",point.getLat()+"");
							pointsMap.put("pointLng",point.getLng()+"");
							pointlist.add(pointsMap);
							System.out.println("pointsMap---"+pointsMap);
						}
					}
					System.out.println("pointlist---"+pointlist);
					info.setListPoints(pointlist);
					areaRangeInfoList.add(info);
				}
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return areaRangeInfoList;
	}
	
	
	public void saveReader(ReaderConfig reader) {

		/* Add few employee records in database */
		try {
			saveAllReader(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	private void saveAllReader(ReaderConfig reader) {
		//Session session = factory.openSession();
		Session session = null;
		Transaction tx = null;
		try {
			session = getSession();
			tx = session.beginTransaction();
			session.save(reader);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//session.close();
		}
		
	}
	public String saveReaderType(ReaderTypeInfo readerType) {

		String status = null;
		/* Add few employee records in database */
		try {
			status = saveAllReaderType(readerType);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}
	private String saveAllReaderType(ReaderTypeInfo readerType) {
		Session session = null;
		Transaction tx = null;
		ReaderType readerTypeModel = new ReaderType();
		String status = null;
		try {
			session = getSession();
			tx = session.beginTransaction();
			readerTypeModel.setReaderTypeId(readerType.getReaderTypeId());
			readerTypeModel.setReaderTypeDesc(readerType.getReaderTypeDesc());
			readerTypeModel.setReaderTypeName(readerType.getReaderTypeName());
			session.saveOrUpdate(readerTypeModel);
			tx.commit();
			status = "ReaderTypeName:" + readerType.getReaderTypeName() + " - record saved successfully.";
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
			status = "ReaderTypeName:" + readerType.getReaderTypeName() + " - record not saved properly.";
		} catch (Exception e) {
			e.printStackTrace();
			status = "ReaderTypeName:" + readerType.getReaderTypeName() + " - record not saved properly.";
		} finally {
			//session.close();
		}
		return status;
	}
	
	public List<ReaderConfigInfo> getAllReaderList() {
		Session session = null;
		Transaction tx = null;
		List<ReaderConfigInfo> listReader = null; 
		try {
			session = getSession();
			tx = session.beginTransaction();
			listReader = new ArrayList<ReaderConfigInfo>();
			String hql = "from ReaderConfig";
			Query query = session.createQuery(hql);
			listReader = query.list();
			System.out.println("listReader:::"+listReader.size());
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//session.close();
		}
	
		return listReader;
	}
	
	public List<ReaderTypeInfo> getAllReaderType() {
		Session session = null;
		Transaction tx = null;
		List<ReaderTypeInfo> readerTypeInfoList = new ArrayList<ReaderTypeInfo>(); 
		try {
			session = getSession();
			tx = session.beginTransaction();
			List<ReaderType> listReader = new ArrayList<ReaderType>();
			String hql = "from ReaderType";
			Query query = session.createQuery(hql);
			listReader = query.list();

	        if(null != listReader) {
				for(ReaderType readerType : listReader) {
					ReaderTypeInfo readerTypeInfo = new ReaderTypeInfo();
					readerTypeInfo.setReaderTypeId(readerType.getReaderTypeId());
					readerTypeInfo.setReaderTypeName(readerType.getReaderTypeName());
					readerTypeInfo.setReaderTypeDesc(readerType.getReaderTypeDesc());
					readerTypeInfoList.add(readerTypeInfo);
				} 
			}	
			
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			//session.close();
		}
	
		return readerTypeInfoList;
	}

	@SuppressWarnings("unchecked")
	public ReaderTypeInfo fetchReaderTypeByTypeID(Integer readerTypeID) throws Exception {
		System.out.println("ReaderDAO - fetchReaderTypeByTypeID method starts");
		Session session = null;
		Transaction trans = null;
		List<ReaderTypeInfo> readerTypeInfoList = new ArrayList<ReaderTypeInfo>();
		try
		{
			session = getSession();
			trans = session.beginTransaction();
	        Query query = session.createQuery("from ReaderType where readerTypeId = :id");
	        query.setInteger("id", readerTypeID);
	        List<ReaderType> queryList = query.list();
	        
	        if(null != queryList) {
				for(ReaderType readerType : queryList) {
					ReaderTypeInfo readerTypeInfo = new ReaderTypeInfo();
					readerTypeInfo.setReaderTypeId(readerType.getReaderTypeId());
					readerTypeInfo.setReaderTypeName(readerType.getReaderTypeName());
					readerTypeInfo.setReaderTypeDesc(readerType.getReaderTypeDesc());
					readerTypeInfoList.add(readerTypeInfo);
				}
			}	
	        
			trans.commit();
		}catch (Exception e) {
			trans.rollback();
			throw new Exception(e.getMessage());
		}
		System.out.println("ReaderDAO - fetchReaderTypeByTypeID method end");
		return readerTypeInfoList.isEmpty() ? null : readerTypeInfoList.get(0);
	}

	@SuppressWarnings("unchecked")
	public String deleteReaderTypeDetail(Integer readerTypeID) throws Exception {
		System.out.println("ReaderDAO - deleteReaderTypeDetail method starts");
		Session session = null;
		Transaction trans = null;
		String status = null;
//		ReaderType readerType = new ReaderType();
		try
		{
			session = getSession();
			trans = session.beginTransaction();
//			readerType.setReaderTypeID(readerTypeID);
//			session.delete(readerType);
	        Query query = session.createSQLQuery("delete from STUDENT_READER_TYPE where READER_TYPE_ID= :id");
	        query.setInteger("id", readerTypeID);
	        int result = query.executeUpdate();
			trans.commit();
			System.out.println("Result = " + result);
			if(result == 1){
				status = "ReaderTypeId:" + readerTypeID + " - record deleted successfully.";
			}else if(result <= 0){
				status = "ReaderTypeId:" + readerTypeID + " - record not present."; 
			}
			
		}catch (Exception e) {
			trans.rollback();
			status = "ReaderTypeId:" + readerTypeID + " - record can not delete properly."; 
			throw new Exception(e.getMessage());
		}
		System.out.println("ReaderDAO - deleteReaderTypeDetail method end");
		return status;
	}

	//prasanth d added
	
	public String saveAppConfig(App_Config_Master_Info app_Config_Master_Info) throws Exception
	{
		Session session = getSession();
		Transaction tx = null;
		String returnMsg="";
		try {
			
			
			if(null!=app_Config_Master_Info){
				tx = session.beginTransaction();
				App_Config_Master app_Config_Master=new App_Config_Master();
				app_Config_Master.setApp_id(app_Config_Master_Info.getApp_id());
				app_Config_Master.setApp_name(app_Config_Master_Info.getApp_name());
				app_Config_Master.setApp_host(app_Config_Master_Info.getApp_host());
				app_Config_Master.setApp_port(app_Config_Master_Info.getApp_port());
				session.saveOrUpdate(app_Config_Master);
				tx.commit();
				returnMsg="success";
			}
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
		}
		return returnMsg;
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<Student_Count_Info> fetchStudentCountDetails() throws Exception {
		List<Student_Count_Info> studCountInfoList = new ArrayList<Student_Count_Info>();
		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			Query query = session.createQuery("from ReaderType");
			List<ReaderType> readerTypeList = query.list();
			if(null != readerTypeList) {
				for(ReaderType readerTypeobj : readerTypeList) {
					List<Map<String,String>> pointlist=new ArrayList<Map<String,String>>();
					Student_Count_Info info=new Student_Count_Info();
					info.setReader_type_name(readerTypeobj.getReaderTypeName());
					info.setReader_type_id(readerTypeobj.getReaderTypeId());
					
					String hql1 =  " select count(1)stud_count,rc.READER_NAME  from STUDENTMASTERINFO sm,STUDENTDETAILS sd,STUDENT_READER_TYPE sr,STUDENT_READER_CONFIG rc "+
					" where sd.STUDENT_ID=sm.STUDENTID and  sr.READER_TYPE_ID=sm.READERID  and rc.READER_TYPE_ID=sr.READER_TYPE_ID and rc.READER_TYPE_ID_SL=sm.READER_ID_SL "+
					" and sr.READER_TYPE_ID=:readerTypeId  group by rc.READER_NAME,sr.READER_TYPE_NAME  order by sr.READER_TYPE_NAME ";
					
				    Query query1 = session.createSQLQuery(hql1);
			        query1.setString("readerTypeId", readerTypeobj.getReaderTypeId()+"");
					Iterator iterator= query1.list().iterator();
					
					while(iterator.hasNext()){
						Object[] obj=(Object[]) iterator.next();
						Map<String,String> pointsMap=new HashMap<String, String>();
						pointsMap.put("stud_count",obj[0]+"");
						pointsMap.put("reader_name",obj[1]+"");
						pointlist.add(pointsMap);
						System.out.println("pointsMap---"+pointsMap);
					}
					System.out.println("pointlist---"+pointlist);
					info.setListPoints(pointlist);
					studCountInfoList.add(info);
				}
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return studCountInfoList;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Map<String,String>> fetchAttendaceDetails(String calenderDate) throws Exception {
		Session session = getSession();
		List<Map<String,String>> pointlist=new ArrayList<Map<String,String>>();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			String hql1 = "select tot_stud,Present_stud,(tot_stud-Present_stud) absent_stud from  (select count(1) as tot_stud from STUDENTDETAILS) t , "+
			 " (select count(1) as Present_stud from STUDENT_ATTANDANCE t where to_date(t.date_of_attendance)=to_date(:calenderDate,'dd-mon-yyyy')) bb ";
	        Query query1 = session.createSQLQuery(hql1);
	        query1.setString("calenderDate", calenderDate);
			Iterator iterator= query1.list().iterator();
		    while(iterator.hasNext()){
				Object[] obj=(Object[]) iterator.next();
				Map<String,String> pointsMap=new HashMap<String, String>();
				pointsMap.put("total_stud",obj[0]+"");
				pointsMap.put("present_stud",obj[1]+"");
				pointsMap.put("absent_stud",obj[2]+"");
				pointlist.add(pointsMap);
				System.out.println("pointsMap---"+pointsMap);
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return pointlist;
	}
	
	@SuppressWarnings("unchecked")
	public List<Map<String,String>> fetchStudReport() throws Exception {
		Session session = getSession();
		List<Map<String,String>> pointlist=new ArrayList<Map<String,String>>();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			String hql1 = "select s.READER_TYPE_NAME location_name, s.READER_TYPE_NAME area_name, COUNT(t.STUDENTID) stud_count from STUDENT_READER_TYPE s, STUDENTMASTERINFO t where s.READER_TYPE_ID=t.READERID "+
			 " GROUP by s.READER_TYPE_NAME, t.READERID ";
	        Query query1 = session.createSQLQuery(hql1);
			Iterator iterator= query1.list().iterator();
		    while(iterator.hasNext()){
				Object[] obj=(Object[]) iterator.next();
				Map<String,String> pointsMap=new HashMap<String, String>();
				pointsMap.put("location_name",obj[0]+"");
				pointsMap.put("area_name",obj[1]+"");
				pointsMap.put("stud_count",obj[2]+"");
				pointlist.add(pointsMap);
				System.out.println("pointsMap---"+pointsMap);
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return pointlist;
	}
	
	@SuppressWarnings("unchecked")
	public List<Map<String,String>> fetchStudDtlReport(String locationId) throws Exception {
		Session session = getSession();
		List<Map<String,String>> pointlist=new ArrayList<Map<String,String>>();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			String hql1 = "select sd.STUDENT_ID,sd.STUDENT_NAME from STUDENTMASTERINFO sm,STUDENTDETAILS sd,STUDENT_READER_TYPE sr where sd.STUDENT_ID=sm.STUDENTID and  "+
			 " sr.READER_TYPE_ID=sm.READERID and sr.READER_TYPE_NAME=:locationId ";
	        Query query1 = session.createSQLQuery(hql1);
	        query1.setString("locationId", locationId);
			Iterator iterator= query1.list().iterator();
		    while(iterator.hasNext()){
				Object[] obj=(Object[]) iterator.next();
				Map<String,String> pointsMap=new HashMap<String, String>();
				pointsMap.put("stud_id",obj[0]+"");
				pointsMap.put("stud_name",obj[1]+"");
				pointlist.add(pointsMap);
				System.out.println("pointsMap---"+pointsMap);
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return pointlist;
	}
	
	@SuppressWarnings("unchecked")
	public List<Map<String,String>> fetchStudLatitudeReport(String studentId) throws Exception {
		Session session = getSession();
		List<Map<String,String>> pointlist=new ArrayList<Map<String,String>>();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			String hql1 = "select ar.buildingname, sp.* from STUDENT_AREA_RANGE ar,STUDENT_AREA_RANGE_POINT_DTL sp where ar.BUILDINGID=sp.BUILDINGID  "+
			" and ar.BUILDINGNAME=(select sr.READER_TYPE_NAME  from STUDENTMASTERINFO sm,STUDENTDETAILS sd,STUDENT_READER_TYPE sr where sd.STUDENT_ID=sm.STUDENTID and  "+
			 " sr.READER_TYPE_ID=sm.READERID and sd.STUDENT_ID=:studentId) ";
	        Query query1 = session.createSQLQuery(hql1);
	        query1.setString("studentId", studentId);
			Iterator iterator= query1.list().iterator();
		    while(iterator.hasNext()){
				Object[] obj=(Object[]) iterator.next();
				Map<String,String> pointsMap=new HashMap<String, String>();
				pointsMap.put("build_name",obj[0]+"");
				pointsMap.put("point_id",obj[1]+"");
				pointsMap.put("latitude",obj[2]+"");
				pointsMap.put("longtitude",obj[3]+"");
				pointsMap.put("build_id",obj[4]+"");
				pointlist.add(pointsMap);
				System.out.println("pointsMap---"+pointsMap);
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return pointlist;
	}
	
	@SuppressWarnings("unchecked")
	public List<Map<String,String>> fetchAreaStudentDetails(String readerId,String readerName) throws Exception {
		Session session = getSession();
		List<Map<String,String>> pointlist=new ArrayList<Map<String,String>>();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			String hql1 = " select sd.STUDENT_ID,sd.STUDENT_NAME from STUDENTMASTERINFO sm,STUDENTDETAILS sd,STUDENT_READER_TYPE sr,STUDENT_READER_CONFIG rc  "+
			" where sd.STUDENT_ID=sm.STUDENTID and  sr.READER_TYPE_ID=sm.READERID  and rc.READER_TYPE_ID=sr.READER_TYPE_ID and rc.READER_TYPE_ID_SL=sm.READER_ID_SL  "+
			" and sr.READER_TYPE_ID=:readerId and READER_NAME=:readerName order by sr.READER_TYPE_NAME ";
				        Query query1 = session.createSQLQuery(hql1);
	        query1.setString("readerId", readerId);
	        query1.setString("readerName", readerName);
			Iterator iterator= query1.list().iterator();
		    while(iterator.hasNext()){
				Object[] obj=(Object[]) iterator.next();
				Map<String,String> pointsMap=new HashMap<String, String>();
				pointsMap.put("stud_id",obj[0]+"");
				pointsMap.put("stud_name",obj[1]+"");
				pointlist.add(pointsMap);
				System.out.println("pointsMap---"+pointsMap);
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return pointlist;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<App_Config_Master> fetchAppConfig() throws Exception {
		List<App_Config_Master> appConfigList = new ArrayList<App_Config_Master>();
		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			Query query = session.createQuery("from App_Config_Master");
			List<App_Config_Master> Querylist = query.list();
			if(null != Querylist) {
				for(App_Config_Master appConfigobj : Querylist) {
					App_Config_Master appConfigInfo = new App_Config_Master();
					appConfigInfo.setApp_id(appConfigobj.getApp_id());
					appConfigInfo.setApp_name(appConfigobj.getApp_name());
					appConfigInfo.setApp_host(appConfigobj.getApp_host());
					appConfigInfo.setApp_port(appConfigobj.getApp_port());
					appConfigList.add(appConfigInfo);
				}
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return appConfigList;
	}
	
	@SuppressWarnings("unchecked")
	public List<App_Config_Master> fetchAppConfigDtl(String appId) throws Exception {
		List<App_Config_Master> appConfigList = new ArrayList<App_Config_Master>();
		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			Query query = session.createQuery("from App_Config_Master where app_id=:appId ");
			query.setString("appId", appId);
			List<App_Config_Master> Querylist = query.list();
			if(null != Querylist) {
				for(App_Config_Master appConfigobj : Querylist) {
					App_Config_Master appConfigInfo = new App_Config_Master();
					appConfigInfo.setApp_id(appConfigobj.getApp_id());
					appConfigInfo.setApp_name(appConfigobj.getApp_name());
					appConfigInfo.setApp_host(appConfigobj.getApp_host());
					appConfigInfo.setApp_port(appConfigobj.getApp_port());
					appConfigList.add(appConfigInfo);
				}
			}			
			session.getTransaction().commit();
		} catch (Exception e) {
			System.out.println(e);
		}
		return appConfigList;
	}
	
	
		
	@SuppressWarnings({ "rawtypes" })
	public List<AccessDetailsDto> fetchAccessDetails() {
		
		
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		System.out.println(dateFormat.format(date));
		
		
		    Date date1 = new Date();
	        String todate = dateFormat.format(date1);

	        Calendar cal = Calendar.getInstance();
	        cal.add(Calendar.DATE, -4);
	        Date todate1 = cal.getTime();    
	        String fromdate = dateFormat.format(todate1);
	        
	        System.out.println("this is 4days back date ::"+fromdate);
		
		/*DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date myDate = new Date(System.currentTimeMillis());
        System.out.println("result is "+ dateFormat.format(myDate));
		 Calendar cal = Calendar.getInstance();
         cal.setTime(myDate);
         cal.add(Calendar.DATE, -10);
         System.out.println(dateFormat.format(cal.getd));*/
		
		List<AccessDetailsDto> accesslist=new ArrayList<AccessDetailsDto>();
		Session session = null;
	     try {
			session = getSession();
			session.getTransaction().begin();
		
         Query query = session.createSQLQuery("SELECT SD.STUDENT_ID,SD.STUDENT_NAME,SC.CLASS_NAME,T.CARD_ID,SRC.ACCESS_DATE,SRC.READER_START_TIME,SRC.READER_END_TIME FROM STUDENTDETAILS SD JOIN TRANSACTION T"+
        		  " ON SD.STUDENT_ID = T.STUDENT_ID JOIN STUDENT_READER_CONFIG SRC ON T.READER_ID=SRC.READER_ID  "+
                   " JOIN STUDENT_CLASS SC ON SD.CLASS_ID=SC.CLASS_ID where TRUNC(ACCESS_DATE)=TO_DATE('"+dateFormat.format(date)+"','dd-mm-yy')");
			List results = query.list();
			Iterator iterator = results.iterator();
			
			while (iterator.hasNext()) {
			    Object[] row = (Object[])iterator.next();
			  AccessDetailsDto dto=new AccessDetailsDto();
			   for (int col = 0; col < row.length; col++) {
			       if(col == 0){
			    	   dto.setStudent_id((BigDecimal) row[col]);
			    	  	}
			    	if(col == 1){
			    		dto.setStudent_name((String) row[col]);
			    		}
			    	if(col==2){
			    		dto.setClass_name((String) row[col]);
			    		}
			    	if(col==3){
			    		dto.setCard_id((BigDecimal) row[col]);;
			    		}
			    	if(col==4){
			    		dto.setAccess_date(new SimpleDateFormat("dd-MM-yyyy").format((Date) row[col]));;
			    		}
			    	if(col==5){
			    		dto.setReadr_start_time((String) row[col]);
			    		}
			    	if(col==6){
			    		dto.setReader_end_time((String) row[col]);
			    		}
			
			    	}
			  
			   accesslist.add(dto);
			}
			
  session.getTransaction().commit();	
	        } catch (Exception e) {
		      System.out.println(e);
	        }
		return accesslist;
		
		
	}
	
	@SuppressWarnings({ "rawtypes" })
	public List<StudentInformation> getStudentTraceDetails() {
	
		List<StudentInformation> studentInfolist=new ArrayList<StudentInformation>();
		Session session = null;
	     try {
			session = getSession();
			session.getTransaction().begin();
		
         Query query = session.createSQLQuery("SELECT sd.STUDENT_ID, sd.STUDENT_NAME, sc.CLASS_ID, sc.CLASS_NAME,scs.Section, r.STEP_COUNT, r.CALORIES, r.BATTARY_VOLT, r.BODY_TEMP FROM reader r join student_card scd on r.CARDID=scd.CARDID "+

        " join studentdetails sd on sd.STUDENT_ID=scd.STUDENTID "+

           " join student_class sc on sd.CLASS_ID=sc.CLASS_ID "+

            " join student_class scs on sd.CLASS_ID=scs.CLASS_ID ");
         
			List results = query.list();
			Iterator iterator = results.iterator();
			
			while (iterator.hasNext()) {
			    Object[] row = (Object[])iterator.next();
			    StudentInformation dto=new StudentInformation();
			   for (int col = 0; col < row.length; col++) {
				   if(col == 0){
			    	   dto.setStudentId(row[col].toString());
			    	  	}
				   if(col == 1){
			    	   dto.setStudentName((String) row[col]);
			    	  	}
				   if(col == 2){
			    		dto.setClassId(row[col].toString());
			    		}
				   if(col == 3){
			    		dto.setClassname((String) row[col]);
			    		}
			    	if(col == 4){
			    		dto.setSection((String) row[col]);
			    		}
			    	if(col == 5){
			    		
			    		dto.setStep_count(((BigInteger) row[col]));
			    		}
			    	if(col == 6){
			    		dto.setCalories(((BigInteger) row[col]));
			    		}
			    	if(col == 7){
			    		dto.setBattary_volt(((BigInteger) row[col]));
			    		}
			    	if(col == 8){
			    		dto.setBody_temp((String) row[col]);
			    		}
			    	
			
			    	}
			  
			   studentInfolist.add(dto);
			}
			
         session.getTransaction().commit();	
	        } catch (Exception e) {
		      System.out.println("Exception in getStudentTraceDetails method"+e);
		      e.printStackTrace();
	        }
	     return studentInfolist;
		
		
	}
	
	@SuppressWarnings("unchecked")
	public void deleteReaderDetail(Integer readerConfID) throws Exception {
		System.out.println("ReaderDAO - deleteReaderDetail method starts");
		Session session = null;
		Transaction trans = null;
//		ReaderConfig readerConf = new ReaderConfig();
		try
		{
			session = getSession();
			trans = session.beginTransaction();
//			readerConf.setReaderConfigID(readerConfID);
//			session.delete(readerConf);
	        Query query = session.createSQLQuery("delete from STUDENT_READER_CONFIG where READER_CONFIG_ID= :id");
	        query.setInteger("id", readerConfID);
	        query.executeUpdate();
			trans.commit();
			
		}catch (Exception e) {
			trans.rollback();
			throw new Exception(e.getMessage());
		}
		System.out.println("ReaderDAO - deleteReaderDetail method end");
	}
		

	@SuppressWarnings("unchecked")
	public void updateReaderDetail(ReaderConfigInfo readerConfigInfo) throws Exception {
		System.out.println("ReaderDAO - updateReaderDetail method starts");
		Session session = null;
		Transaction trans = null;
		ReaderConfig readerConfig = new ReaderConfig();
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			readerConfig.setGpsEnabled(readerConfigInfo.getGpsEnabled());
			readerConfig.setReaderConfigID(readerConfigInfo.getReaderConfigID());
			readerConfig.setReaderEndTime(readerConfigInfo.getReaderEndTime());
			readerConfig.setReaderID(readerConfigInfo.getReaderID());
			readerConfig.setReaderName(readerConfigInfo.getReaderName());
			readerConfig.setReaderStartTime(readerConfigInfo.getReaderStartTime());
			readerConfig.setReaderSubName(readerConfigInfo.getReaderSubName());
			readerConfig.setReaderTypeID(readerConfigInfo.getReaderTypeID());
//	        Query query = session.createSQLQuery("update STUDENT_READER_CONFIG set -- where READER_CONFIG_ID= :id");
//	        query.setInteger("id", readerConfID);
//	        int result = query.executeUpdate();
			session.saveOrUpdate(readerConfig);
			trans.commit();
			
		}catch (Exception e) {
			trans.rollback();
			throw new Exception(e.getMessage());
		}
		System.out.println("ReaderDAO - updateReaderDetail method end");
	}
		
	
	@SuppressWarnings("unchecked")
	public ReaderConfigInfo fetchReaderDetailByConfigID(Integer readerConfID) throws Exception {
		System.out.println("ReaderDAO - fetchReaderDetailByConfigID method starts");
		Session session = null;
		Transaction trans = null;
		List<ReaderConfigInfo> readerConfigInfoList = new ArrayList<ReaderConfigInfo>();
		try
		{
			session = getSession();
			trans = session.beginTransaction();
	        Query query = session.createQuery("from ReaderConfig where readerConfigID = :id");
	        query.setInteger("id", readerConfID);
	        List<ReaderConfig> queryList = query.list();
	        
	        if(null != queryList) {
				for(ReaderConfig readerConfig : queryList) {
					ReaderConfigInfo readerConfigInfo = new ReaderConfigInfo();
					readerConfigInfo.setGpsEnabled(readerConfig.getGpsEnabled());
					readerConfigInfo.setReaderConfigID(readerConfig.getReaderConfigID());
					readerConfigInfo.setReaderEndTime(readerConfig.getReaderEndTime());
					readerConfigInfo.setReaderID(readerConfig.getReaderID());
					readerConfigInfo.setReaderName(readerConfig.getReaderName());
					readerConfigInfo.setReaderStartTime(readerConfig.getReaderStartTime());
					readerConfigInfo.setReaderSubName(readerConfig.getReaderSubName());
					readerConfigInfo.setReaderTypeID(readerConfig.getReaderTypeID());
					readerConfigInfoList.add(readerConfigInfo);
				}
			}	
	        
			trans.commit();
		}catch (Exception e) {
			trans.rollback();
			throw new Exception(e.getMessage());
		}
		System.out.println("ReaderDAO - fetchReaderDetailByConfigID method end");
		return readerConfigInfoList.isEmpty() ? null : readerConfigInfoList.get(0);
	}
}
