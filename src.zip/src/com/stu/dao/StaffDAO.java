package com.stu.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.stu.exception.StaffException;
import com.stu.model.StaffDetail;
import com.stu.model.JSON.StaffInfo;


public interface StaffDAO {
	public String saveAddStaff(StaffDetail staffDetail)throws StaffException;
	
	public List<StaffInfo> fetchAllStaffData()throws StaffException;
	
	public List<StaffInfo> fetchAllStaffData(int id) throws StaffException;
	
	public String deteleStaffData(StaffDetail detail)throws StaffException;
}
