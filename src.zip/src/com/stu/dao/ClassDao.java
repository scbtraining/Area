package com.stu.dao;

import java.util.List;

import com.stu.exception.ClassException;
import com.stu.model.STUDENTCLASS;
import com.stu.model.JSON.StudentClass;

public interface ClassDao {

	public String addClass(STUDENTCLASS studentClass) throws ClassException;

	public List<StudentClass> showAllClass() throws ClassException;

	public List<StudentClass> showClass(int classID) throws ClassException;

	public String deleteClass(int classID) throws ClassException;

}
