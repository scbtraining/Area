package com.stu.dao;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.stu.exception.ATTException;
import com.stu.exception.STUDENTException;
import com.stu.model.ATT;
import com.stu.model.LateComingList;
import com.stu.model.STUD;
import com.stu.model.JSON.ATTInfo;
import com.stu.model.JSON.STUDInfo;


public interface ATTDAO {
	
	String saveAddATT(ATT addATT)throws ATTException;
	
	List<ATTInfo> fetchAllATTData()throws ATTException;
	
	List<ATTInfo> fetchAATTData(int ATTid)throws ATTException;
	
	List<LateComingList> fetchLateComingList(int month, int year);

	List<LateComingList> fetchYearlyLateComingList(int year);

	List<LateComingList> fetchMonthlyLateComingList(int month, int year);
	
	List<LateComingList> fetchWeeklyLateComingQueryList(int count);

	List<LateComingList> fetchDailyLateComingList(String date);
	
	List<LateComingList> fetchLateComingQueryList(String day, int month, int year);
	
	/*
	
	BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException;*/
	
}
