package com.stu.dao;

import java.util.List;

import com.stu.exception.ROLEException;
import com.stu.model.RoleAccessPermission;
import com.stu.model.JSON.RoleAccessPermissionInfo;

public interface RoleAccessPermissionDao {

    String addRolePermission(RoleAccessPermission roleAccessPer)throws ROLEException;
	
	List<RoleAccessPermissionInfo> fetchRolePermission(Integer roleAccessId)throws ROLEException;
	
	List<RoleAccessPermissionInfo> fetchAllRolePermission()throws ROLEException;
}
