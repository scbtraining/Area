package com.stu.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.stu.exception.UserRegException;
import com.stu.model.StudentMarks;
import com.stu.model.StudentRegistration;
import com.stu.model.UserReg;


@Component
public class UserRegDao {
	
	final static Logger logger = LoggerFactory.getLogger(UserRegDao.class);
	
	@Autowired
	private SessionFactory sessionFactory1;

	protected Session getSession() throws UserRegException {
		Session session = sessionFactory1.getCurrentSession();
		if (null == session) {
			session = sessionFactory1.openSession();
		}
		return session;
	}
	
	
	public void saveUserReg(UserReg userreg) throws UserRegException {

		/* Add few employee records in database */
		try {
			addUserReg(userreg);
		} catch (Exception e) {
			logger.info("Exception in saveUserReg",e);
		}
		
	}

	private void addUserReg(UserReg userreg) throws UserRegException {
		Session session = getSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(userreg);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			logger.info("Exception in addUserReg method",e);
		} finally {
			session.close();
		}
		
	}
	
	public void saveUserReg(StudentRegistration studentreg) throws UserRegException {

		/* Add few employee records in database */
		try {
			addStudentReg(studentreg);
		} catch (Exception e) {
			logger.info("Exception in saveUserReg method",e);
		}
		
	}

	private void addStudentReg(StudentRegistration studentreg) throws UserRegException {
		Session session = getSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(studentreg);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			logger.info("Exception in addStudentReg method",e);
		} finally {
			session.close();
		}
		
	}
	
	
	public void saveStudentMarks(StudentMarks studentmarks) throws UserRegException {

		/* Add few employee records in database */
		try {
			StudentMarksReg(studentmarks);
		} catch (Exception e) {
			logger.info("Exception in saveStudentMarks method",e);
		}
		
	}

	private void StudentMarksReg(StudentMarks studentmarks) throws UserRegException {
		Session session = getSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(studentmarks);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			logger.info("Exception in StudentMarksReg method",e);
		} finally {
			session.close();
		}
		
	}

	
	
	
	public List<StudentRegistration> getUserRegList() throws UserRegException {
		Session session = getSession();
		Transaction tx = null;
		List<StudentRegistration> studentregList = null;
		try {
			tx = session.beginTransaction();
			studentregList = session.createCriteria(StudentRegistration.class).list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			logger.info("Exception in getUserRegList method",e);
		} finally {
			session.close();
		}
		return studentregList;
	}

}
