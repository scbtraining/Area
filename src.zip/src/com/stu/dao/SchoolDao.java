package com.stu.dao;

import java.util.List;

import com.stu.exception.SCHOOLException;
import com.stu.model.School;
import com.stu.model.JSON.SchoolInfo;


public interface SchoolDao {
	
	List<SchoolInfo> showSchool(int schoolId) throws SCHOOLException;
	
	String addSchool(School school) throws SCHOOLException;
	
	void deleteSchool(int data) throws SCHOOLException;
	
	List<SchoolInfo> fetchSchoolData() throws SCHOOLException;
	
	/*BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException;*/
	
}
