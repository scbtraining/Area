package com.stu.dao;

import java.math.BigDecimal;
import java.util.List;

import com.stu.exception.STUDENTException;
import com.stu.exception.STUDENTFEEException;
import com.stu.model.STUD;
import com.stu.model.STUDFEE;
import com.stu.model.JSON.STUDFEEInfo;
import com.stu.model.JSON.STUDInfo;


public interface STUFEEDAO {
	
	String saveAddSTUDFEE(STUDFEE addSTUDFEE)throws STUDENTFEEException;
	
	List<STUDFEEInfo> fetchASTUDFEEData(int STUDFEEid)throws STUDENTFEEException;
	
	List<STUDFEEInfo> fetchSTUFEEData()throws STUDENTFEEException;
	
	/*BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException;*/
	
}
