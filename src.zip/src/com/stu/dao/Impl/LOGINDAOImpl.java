package com.stu.dao.Impl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractLoginDao;
import com.stu.dao.LOGINDAO;
import com.stu.exception.LOGINException;
import com.stu.model.LOGIN;
import com.stu.model.JSON.UsersInfo;



@Repository("/loginDAOImpl")
public class LOGINDAOImpl extends AbstractLoginDao<Integer, LOGIN> implements
		LOGINDAO {
	
	/*public Boolean checkData(String username, String password)throws LOGINException{
		System.out.println("LOGINDAOImpl - checkData method starts");
		Session session = null;
		Transaction trans = null;
		boolean checkflag = false;
		String sql="";
		String suname="";
		String spwd="";
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			sql = "select * from Login where username='"+username+"'and password='"+password+"'";
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			System.out.println("query.list().size():::"+query.list().size());
			if(query.list().size()>0 || !query.list().equals("")){
				for (Object[] row : results) {
					suname = row[0].toString();
					spwd = row[1].toString();
					System.out.println("suname::"+suname+"&spwd::"+spwd);
					if(suname.equalsIgnoreCase(username) && spwd.equalsIgnoreCase(password))
					{
						checkflag=true;
					}
				}
			}else{
				checkflag=false;
			}
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new LOGINException("Error occured:", e.getMessage());
		}
		System.out.println("LOGINDAOImpl - checkData method ends");
		return checkflag;
	}*/
	
	
	public UsersInfo checkData(String username, String password)throws LOGINException{
		System.out.println("LOGINDAOImpl - checkData method starts");
		Session session = null;
		Transaction trans = null;
		String sql="";
	
		UsersInfo info=new UsersInfo();
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			sql = "select * from users where users_user_name='"+username+"'and users_password='"+password+"'";
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			if(query.list().size()>0 || !query.list().equals("")){
				String userId=null;
				for (Object[] row : results) {
					userId=row[0].toString();
					info.setUsers_userid(row[0].toString());
					info.setUsers_emailid(row[1].toString());
					info.setUsers_password(row[2].toString());
					info.setUsers_user_name(row[3].toString());
					info.setUsers_phone_no(row[4].toString());
					info.setUsers_address(row[5].toString());
			}
				
		Query queryRole = session.createSQLQuery("select r.ROLE_NAME,ur.ROLE_ID from user_role ur join role r on ur.ROLE_ID=r.ROLE_ID WHERE ur.USER_ID="+userId);
 		List<Object[]> rows = queryRole.list();
			for(Object[] row : rows){
			    info.setUser_role(row[0].toString());	
			    info.setUser_role_id(row[1].toString());
			 }
		}
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new LOGINException("Error occured:", e.getMessage());
		}
		System.out.println("LOGINDAOImpl - checkData method ends");
		return info;
	}
	/*
	@Override
	public List<USERInfo> fetchAUserData(Integer userId) throws USERException {
		System.out.println("USERDAOImpl - fetchAUserData method starts");
		List<USERInfo> Userlist = new ArrayList<USERInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(USER.class).add( Restrictions.eq("userId", userId ) );
			Userlist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new USERException("Error occured:", e.getMessage());
		}
		System.out.println("USERDAOImpl - fetchAUserData method ends");
		return Userlist;
	}*/
}
