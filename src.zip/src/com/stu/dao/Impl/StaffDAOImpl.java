package com.stu.dao.Impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractStaffDao;
import com.stu.dao.StaffDAO;
import com.stu.exception.StaffException;
import com.stu.model.StaffDetail;
import com.stu.model.JSON.StaffInfo;

@Repository(value="staffDaoImpl")
public class StaffDAOImpl extends AbstractStaffDao<Integer, StaffDetail> implements StaffDAO{

	
	public String saveAddStaff(StaffDetail staffDetail)throws StaffException{
		System.out.println("StaffDAOImpl - saveAdd method starts");
		saveOrUpdate(staffDetail);
		System.out.println("StaffDAOImpl - saveAdd method ends");
		return "success";
	}
	public List<StaffInfo> fetchAllStaffData()throws StaffException{
		System.out.println("StaffDAOImpl - fetchAll Staff method starts");
		List<StaffInfo> staffInfo = new ArrayList<StaffInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{	
			
			session = getSession();		
			trans = session.beginTransaction();			
			cr = session.createCriteria(StaffDetail.class);
			staffInfo = cr.list();
			System.out.println("cr.list()  "+cr.list());
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new StaffException("Error occured:", e.getMessage());
		}
		System.out.println("StaffDAOImpl - fetchAll staff method ends");
		return staffInfo;
	}
	
	
	public List<StaffInfo> fetchAllStaffData(int id)throws StaffException{
		System.out.println("StaffDAOImpl - fetchAll Staff method starts");
		List<StaffInfo> staffInfo = new ArrayList<StaffInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(StaffDetail.class).add( Restrictions.eq("id", id ) );
			staffInfo = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new StaffException("Error occured:", e.getMessage());
		}
		System.out.println("StaffDAOImpl - fetchAll Staff method ends");
		return staffInfo;
	}
	
	public String deteleStaffData(StaffDetail detail)throws StaffException{
		System.out.println("ATTDAOImpl - Detele staff method starts");		
			System.out.println("detail "+detail);
				delete(detail);
		
			System.out.println("StaffDAOImpl - Detele staff  method ends");
		return "success";
	}
	
}
