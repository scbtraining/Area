package com.stu.dao.Impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractRoleDao;
import com.stu.dao.AbstractStudDao;
import com.stu.dao.ROLEDAO;
import com.stu.exception.ROLEException;
import com.stu.model.ROLE;
import com.stu.model.JSON.ROLEInfo;



@Repository("/roleDAOImpl")
public class ROLEDAOImpl extends AbstractRoleDao<Integer, ROLE> implements
		ROLEDAO {
	
	public String saveAddROLE(ROLE addROLE)throws ROLEException{
		System.out.println("ROLEDAOImpl - saveAddROLE method starts");
		saveOrUpdate(addROLE);
		System.out.println("ROLEDAOImpl - saveAddROLE method ends");
		return "success";
	}
	
	@SuppressWarnings("unchecked")
	public List<ROLEInfo> fetchAROLEData(int ROLEid)throws ROLEException{
		System.out.println("ROLEDAOImpl - fetchAROLEData method starts");
		List<ROLEInfo> ROLElist = new ArrayList<ROLEInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(ROLE.class).add( Restrictions.eq("roleid", ROLEid ) );
			ROLElist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ROLEException("Error occured:", e.getMessage());
		}
		System.out.println("ROLEDAOImpl - fetchAROLEData method ends");
		return ROLElist;
	}
	
	@SuppressWarnings("unchecked")
	public List<ROLEInfo> fetchAllROLEData()throws ROLEException{
		System.out.println("ROLEDAOImpl - fetchAllROLEData method starts");
		List<ROLEInfo> AllROLElist = new ArrayList<ROLEInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(ROLE.class);
			AllROLElist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ROLEException("Error occured:", e.getMessage());
		}
		System.out.println("ROLEDAOImpl - fetchAllROLEData method ends");
		return AllROLElist;
	}
	
}
