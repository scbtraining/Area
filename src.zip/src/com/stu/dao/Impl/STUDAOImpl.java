package com.stu.dao.Impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractStudDao;
import com.stu.dao.STUDAO;
import com.stu.exception.STUDENTException;
import com.stu.model.STUD;
import com.stu.model.StudentSearch;
import com.stu.model.JSON.STUDInfo;



@Repository("/stuDAOImpl")
public class STUDAOImpl extends AbstractStudDao<Integer, STUD> implements
		STUDAO {
	
	public String saveAddSTUD(STUD addSTUD)throws STUDENTException{
		System.out.println("STUDAOImpl - saveAddSTUD method starts");
		saveOrUpdate(addSTUD);
		System.out.println("STUDAOImpl - saveAddSTUD method ends");
		return "success";
	}
	
	@SuppressWarnings("unchecked")
	public List<STUDInfo> fetchASTUDData(int STUDid)throws STUDENTException{
		System.out.println("STUDAOImpl - fetchASTUDData method starts");
		List<STUDInfo> STUDlist = new ArrayList<STUDInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(STUD.class).add( Restrictions.eq("sid", STUDid ) );
			STUDlist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new STUDENTException("Error occured:", e.getMessage());
		}
		System.out.println("STUDAOImpl - fetchASTUDData method ends");
		return STUDlist;
	}
	
	@SuppressWarnings("unchecked")
	public List<STUDInfo> fetchAllSTUDData()throws STUDENTException{
		System.out.println("STUDAOImpl - fetchAllSTUDData method starts");
		List<STUDInfo> allSTUDlist = new ArrayList<STUDInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(STUD.class);
			allSTUDlist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new STUDENTException("Error occured:", e.getMessage());
		}
		System.out.println("STUDAOImpl - fetchAllSTUDData method ends");
		return allSTUDlist;
	}
	
	
	
	
	
	
	
	@SuppressWarnings("unchecked")
	public List<STUDInfo> fetchSTUDidBySTUDname(String STUDname)throws STUDENTException{
		System.out.println("STUDAOImpl - fetchSTUDidBySTUDname method starts");
		List<STUDInfo> STUDlist = new ArrayList<STUDInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		Query query = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
//			cr = session.createCriteria(STUD.class).add( Restrictions.like("sname", "%"+STUDname+"%") );
//			STUDlist = cr.list();
			query = session.createQuery("select stu.sid, stu.sname from STUD as stu where stu.sname like :sname");
			query.setParameter("sname", "%" + STUDname + "%");
			List studList = query.list();
			
			Iterator itr = studList.iterator();
			while(itr.hasNext()){
				Object student[] = (Object[]) itr.next();
				STUDInfo studInfo = new STUDInfo();
				studInfo.setSid((Integer) student[0]);
				studInfo.setSname((String) student[1]);
				STUDlist.add(studInfo);
			}
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new STUDENTException("Error occured:", e.getMessage());
		}
		System.out.println("STUDAOImpl - fetchSTUDidBySTUDname method ends");
		return STUDlist;
	}
		
	
/*	
	public List<SOWInfo> fetchSOWData()throws SOWException{
		System.out.println("SOWDAOImpl - fetchSOW method starts");
		List<SOWInfo> allSOW = new ArrayList<SOWInfo>();
		if (allSOW == null || allSOW.isEmpty()) {
			allSOW = createListEntityCriteria();
		}
		System.out.println("SOWDAOImpl - fetchSOW method ends");
		return allSOW;
	}

	public BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException{
		System.out.println("SOWDAOImpl - currCalculation method starts");
		BigDecimal resultvalue = null;
		resultvalue = calculatedResult(curtype, curvalue);
		System.out.println("SOWDAOImpl - currCalculation method starts");
		return resultvalue;
	}*/
	
	/*
	 * To search student details based on student id
	 * accepts student id and returns student details object
	 * */
	@SuppressWarnings("unchecked")
	public StudentSearch searchStudentData(String sid)throws STUDENTException{
		
		System.out.println("STUDAOImpl - fetchASTUDData method starts");
		StudentSearch studentDetails = new StudentSearch();
		List<Object[]> data =  null;
		Session session = null;
		String query = null;
		SQLQuery cr = null;
		try
		{
			session = getSession();
			session.getTransaction().begin();
			if(isNumeric(sid)){
				query = "SELECT DISTINCT sd.STUDENT_ID, sd.STUDENT_NAME, src.READER_NAME, r.ENTRY_TIME FROM STUDENTDETAILS sd, STUDENT_CARD sc, READER r, STUDENT_READER_CONFIG src WHERE sd.STUDENT_ID= sc.STUDENTID AND sc.CARDID = r.CARDID AND r.READER_ID = src.READER_ID AND sd.STUDENT_ID  = ?";
				cr = session.createSQLQuery(query);
				data = cr.setInteger(0, Integer.parseInt(sid)).list();
			}else{
				query = "SELECT DISTINCT sd.STUDENT_ID, sd.STUDENT_NAME, src.READER_NAME, r.ENTRY_TIME FROM STUDENTDETAILS sd, STUDENT_CARD sc, READER r, STUDENT_READER_CONFIG src WHERE sd.STUDENT_ID= sc.STUDENTID AND sc.CARDID = r.CARDID AND r.READER_ID = src.READER_ID AND sd.STUDENT_NAME  = ?";
				cr = session.createSQLQuery(query);
				data = cr.setString(0, sid).list();
			}
			for(Object[] row : data){
				studentDetails.setSid(Integer.parseInt(row[0].toString()));
				studentDetails.setSname(row[1].toString());
				studentDetails.setRname(row[2].toString());
			}
			session.getTransaction().commit();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw new STUDENTException("Error occured:", e.getMessage());
		}
		System.out.println("STUDAOImpl - searchASTUDData method ends");
		return studentDetails;
	}
	
	@SuppressWarnings("unchecked")
	public List<STUDInfo> fetchSTUDetails()throws STUDENTException{
		System.out.println("STUDAOImpl - fetchSTUDidBySTUDname method starts");
		List<STUDInfo> STUDlist = new ArrayList<STUDInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		Query query = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
//			cr = session.createCriteria(STUD.class).add( Restrictions.like("sname", "%"+STUDname+"%") );
//			STUDlist = cr.list();
			query = session.createQuery("select stu.sid, stu.sname from STUD stu");
			List studList = query.list();
			System.out.println("Total list"+  studList);
			Iterator itr = studList.iterator();
			while(itr.hasNext()){
				Object student[] = (Object[]) itr.next();
				
				System.out.println("inside loop"+  (Integer) student[0]);
				
				System.out.println("inside loop"+  (String) student[1]);
				STUDInfo studInfo = new STUDInfo();
				studInfo.setSid((Integer) student[0]);
				studInfo.setSname((String) student[1]);
				STUDlist.add(studInfo);
			}
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new STUDENTException("Error occured:", e.getMessage());
		}
		System.out.println("STUDAOImpl - fetchSTUDidBySTUDname method ends");
		return STUDlist;
	}
	
	private boolean isNumeric(String s) {  
	    return s != null && s.matches("[-+]?\\d*\\.?\\d+");  
	}	
	
}

