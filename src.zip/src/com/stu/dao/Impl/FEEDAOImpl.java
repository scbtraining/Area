package com.stu.dao.Impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractFeeDao;
import com.stu.dao.AbstractStudDao;
import com.stu.dao.FEEDAO;
import com.stu.dao.STUDAO;
import com.stu.exception.FEEException;
import com.stu.exception.STUDENTException;
import com.stu.model.FEE;
import com.stu.model.STUD;
import com.stu.model.JSON.FEEInfo;
import com.stu.model.JSON.STUDInfo;



@Repository("/feeDAOImpl")
public class FEEDAOImpl extends AbstractFeeDao<Integer, FEE> implements
		FEEDAO {
	
	public String saveAddFEE(FEE addFEE)throws FEEException{
		System.out.println("FEEDAOImpl - saveAddFEE method starts");
		saveOrUpdate(addFEE);
		System.out.println("FEEDAOImpl - saveAddFEE method ends");
		return "success";
	}
	
	@SuppressWarnings("unchecked")
	public List<FEEInfo> fetchAFEEData(int FEEid)throws FEEException{
		System.out.println("FEEDAOImpl - fetchAFEEData method starts");
		List<FEEInfo> FEElist = new ArrayList<FEEInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(FEE.class).add( Restrictions.eq("feeid", FEEid ) );
			FEElist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new FEEException("Error occured:", e.getMessage());
		}
		System.out.println("FEEDAOImpl - fetchAFEEData method ends");
		return FEElist;
	}
	
	@SuppressWarnings("unchecked")
	public List<FEEInfo> fetchFEEData()throws FEEException{
		System.out.println("FEEDAOImpl - fetchFEEData method starts");
		List<FEEInfo> AllFEElist = new ArrayList<FEEInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(FEE.class);
			AllFEElist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new FEEException("Error occured:", e.getMessage());
		}
		System.out.println("FEEDAOImpl - fetchFEEData method ends");
		return AllFEElist;
	}
	
/*	
	public List<SOWInfo> fetchSOWData()throws SOWException{
		System.out.println("SOWDAOImpl - fetchSOW method starts");
		List<SOWInfo> allSOW = new ArrayList<SOWInfo>();
		if (allSOW == null || allSOW.isEmpty()) {
			allSOW = createListEntityCriteria();
		}
		System.out.println("SOWDAOImpl - fetchSOW method ends");
		return allSOW;
	}

	public BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException{
		System.out.println("SOWDAOImpl - currCalculation method starts");
		BigDecimal resultvalue = null;
		resultvalue = calculatedResult(curtype, curvalue);
		System.out.println("SOWDAOImpl - currCalculation method starts");
		return resultvalue;
	}*/
	
}
