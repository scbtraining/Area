package com.stu.dao.Impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractRoleAccPerDao;
import com.stu.dao.RoleAccessPermissionDao;
import com.stu.exception.ROLEException;
import com.stu.model.RoleAccessPermission;
import com.stu.model.USER;
import com.stu.model.JSON.RoleAccessPermissionInfo;


@Repository("/roleAccPerDAOImpl")
public class RoleAccessPermissionDaoImpl extends  AbstractRoleAccPerDao<Integer, RoleAccessPermission> implements RoleAccessPermissionDao {

	@Override
	public String addRolePermission(RoleAccessPermission roleAccessPer)
			throws ROLEException {
		System.out.println("RoleAccessPermissionDaoImpl - addRolePermission method starts");
		saveOrUpdate(roleAccessPer);
		System.out.println("RoleAccessPermissionDaoImpl - addRolePermission method ends");
		return "success";
	}
	
	@Override
	public List<RoleAccessPermissionInfo> fetchRolePermission(Integer roleAccessId)
			throws ROLEException {
		System.out.println("RoleAccessPermissionDaoImpl - fetchRolePermission method starts");
		List<RoleAccessPermissionInfo> roleAccPerList = new ArrayList<RoleAccessPermissionInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(RoleAccessPermission.class).add( Restrictions.eq("roleAccessId", roleAccessId ) );
			roleAccPerList = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ROLEException("Error occured:", e.getMessage());
		}
		System.out.println("RoleAccessPermissionDaoImpl - fetchRolePermission method ends");
		return roleAccPerList;
	}

	@Override
	public List<RoleAccessPermissionInfo> fetchAllRolePermission()
			throws ROLEException {
		
		System.out.println("RoleAccessPermissionDaoImpl - fetchAllRolePermission method starts");
		List<RoleAccessPermissionInfo> allRoleAccPerlist = new ArrayList<RoleAccessPermissionInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(RoleAccessPermission.class);
			allRoleAccPerlist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ROLEException("Error occured:", e.getMessage());
		}
		System.out.println("RoleAccessPermissionDaoImpl - fetchAllRolePermission method ends");
		return allRoleAccPerlist;
	}

	

}
