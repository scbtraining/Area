package com.stu.dao.Impl;

import java.util.ArrayList;
import java.util.List;





import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;






import com.stu.dao.AbstractSubjectDao;
import com.stu.dao.SubjectDao;
import com.stu.exception.SubjectException;
import com.stu.model.Subject;
import com.stu.model.SubjectClass;
import com.stu.model.JSON.SubjectInfo;


@Repository("/subjectDaoImpl")
public class SubjectDaoImpl extends AbstractSubjectDao<Integer, Subject> implements
		SubjectDao {
	
	final static Logger logger = LoggerFactory.getLogger(SubjectDaoImpl.class);
	
	public String saveSubject(SubjectInfo addSubjectInfo)throws SubjectException{
		logger.info("SubjectDaoImpl - saveSubject method starts");
		Session session = null;
		Transaction trans = null;
		
		try {
			session = getSession();
			trans = session.beginTransaction();
			
			Subject addSubject=new Subject();
			SubjectClass addSubjectClass=new SubjectClass();	
			if (null != addSubjectInfo) {
				addSubject.setSubjectId(addSubjectInfo.getSubjectId());
				addSubject.setSubjectName(addSubjectInfo.getSubjectName());
				session.saveOrUpdate(addSubject);
				addSubjectClass.setSubjectId(addSubjectInfo.getSubjectId());
				addSubjectClass.setClassId(addSubjectInfo.getClassId());
				addSubjectClass.setSchoolId(addSubjectInfo.getSchoolId());
				addSubject.getSubClass().add(addSubjectClass);
				session.save(addSubjectClass);
			}
			
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			System.out.println("Exception in AbstractSubjectDao saveOrUpdate:: "+e);
			throw new SubjectException("Error occured:", e.getMessage());
		}
		
		logger.info("SubjectDaoImpl - saveSubject method ends");
		return "success";
	}
	
	@SuppressWarnings("unchecked")
	public List<SubjectInfo> fetchSubjectData(int subjectId)throws SubjectException{
		logger.info("SubjectDaoImpl - fetchSubjectData method starts");
		List<SubjectInfo> Subjectlist = new ArrayList<SubjectInfo>();
		Session session = null;
		Transaction trans = null;
		
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			SQLQuery query = session.createSQLQuery("Select Sub.SUBJECT_ID, Sub.SUBJECT_NAME, Sub_Class.CLASS_ID, Sub_Class.SCHOOL_ID from Subject Sub, Subject_Class Sub_Class where Sub.SUBJECT_ID="+subjectId+ " and Sub.SUBJECT_ID= Sub_Class.SUBJECT_ID");
			List<Object[]> rows = query.list();
			
			if(null!=rows)
			{
				for(Object[] row : rows){
					System.out.println("SubjectId row[0]::"+row[0].toString());
					System.out.println("SubjectName row[1]::"+row[1].toString());
					System.out.println("ClassId row[2]::"+row[2].toString());
					System.out.println("SchoolId row[3]::"+row[3].toString());
					SubjectInfo tempinfo=new SubjectInfo();
					tempinfo.setSubjectId(Integer.parseInt(row[0].toString()));
					tempinfo.setSubjectName(row[1].toString());
					tempinfo.setClassId(Integer.parseInt(row[2].toString()));
					tempinfo.setSchoolId(Integer.parseInt(row[3].toString()));
					Subjectlist.add(tempinfo);
				}
			}
			
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new SubjectException("Error occured SubjectDaoImpl fetchSubjectData method:", e.getMessage());
		}
		logger.info("SubjectDaoImpl - fetchSubjectData method ends");
		return Subjectlist;
	}
	

	public List<SubjectInfo> fetchSubjectData()throws SubjectException{
		logger.info("SubjectDaoImpl - fetchSubjectData method starts");
		List<SubjectInfo> Subjectlist = new ArrayList<SubjectInfo>();
		Session session = null;
		Transaction trans = null;
		List<SubjectInfo> subInfo = new ArrayList<SubjectInfo>();
		
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			SQLQuery query = session.createSQLQuery("Select Sub.SUBJECT_ID, Sub.SUBJECT_NAME, Sub_Class.CLASS_ID, Sub_Class.SCHOOL_ID from Subject Sub, Subject_Class Sub_Class where Sub.SUBJECT_ID= Sub_Class.SUBJECT_ID");
			List<Object[]> rows = query.list();
			
			if(null!=rows)
			{
				for(Object[] row : rows){
					System.out.println("SubjectId row[0]::"+row[0].toString());
					System.out.println("SubjectName row[1]::"+row[1].toString());
					System.out.println("ClassId row[2]::"+row[2].toString());
					System.out.println("SchoolId row[3]::"+row[3].toString());
					SubjectInfo tempinfo=new SubjectInfo();
					tempinfo.setSubjectId(Integer.parseInt(row[0].toString()));
					tempinfo.setSubjectName(row[1].toString());
					tempinfo.setClassId(Integer.parseInt(row[2].toString()));
					tempinfo.setSchoolId(Integer.parseInt(row[3].toString()));
					subInfo.add(tempinfo);
				}
				
			}
			
			trans.commit();
		}
		catch (Exception e) {
			System.out.println("Error" + e);
			trans.rollback();
			throw new SubjectException("Error occured in SubjectDaoImpl fetchSubjectData method:", e.getMessage());
		}
		logger.info("SubjectDaoImpl - fetchSubjectData method ends");
		return subInfo;
	}
	
	public String deleteSubject(int subjectId)throws SubjectException{
		logger.info("SubjectDaoImpl - deleteSubject method starts");
		Session session = null;
		Transaction trans = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			Object obj = session.load(Subject.class,new Integer(subjectId));
			Object obj1 = session.load(SubjectClass.class,new Integer(subjectId));
			Subject sub = (Subject) obj;
			SubjectClass subc = (SubjectClass) obj1;
			
			session.delete(subc);
			session.delete(sub);
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			System.out.println("Exception in deleteSubject method---->"+e);
			throw new SubjectException("Error occured SubjectDaoImpl deleteSubject method:", e.getMessage());
		}
		logger.info("SubjectDaoImpl - deleteSubject method ends");
		return "success";
	}
	
}
