package com.stu.dao.Impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractStudDao;
import com.stu.dao.AbstractStudFeeDao;
import com.stu.dao.STUDAO;
import com.stu.dao.STUFEEDAO;
import com.stu.exception.STUDENTException;
import com.stu.exception.STUDENTFEEException;
import com.stu.model.STUD;
import com.stu.model.STUDFEE;
import com.stu.model.JSON.STUDFEEInfo;
import com.stu.model.JSON.STUDInfo;



@Repository("/stufeeDAOImpl")
public class STUFEEDAOImpl extends AbstractStudFeeDao<Integer, STUDFEE> implements
		STUFEEDAO {
	
	public String saveAddSTUDFEE(STUDFEE addSTUDFEE)throws STUDENTFEEException{
		System.out.println("STUFEEDAOImpl - saveAddSTUD method starts");
		saveOrUpdate(addSTUDFEE);
		System.out.println("STUFEEDAOImpl - saveAddSTUD method ends");
		return "success";
	}
	
	@SuppressWarnings("unchecked")
	public List<STUDFEEInfo> fetchASTUDFEEData(int STUDFEEid)throws STUDENTFEEException{
		System.out.println("STUFEEDAOImpl - fetchASTUDFEEData method starts");
		List<STUDFEEInfo> STUDFEElist = new ArrayList<STUDFEEInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(STUDFEE.class).add( Restrictions.eq("sid", STUDFEEid ) );
			STUDFEElist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new STUDENTFEEException("Error occured:", e.getMessage());
		}
		System.out.println("STUFEEDAOImpl - fetchASTUDFEEData method ends");
		return STUDFEElist;
	}
	

	public List<STUDFEEInfo> fetchSTUFEEData()throws STUDENTFEEException{
		System.out.println("STUFEEDAOImpl - fetchSTUDFEEData method starts");
		List<STUDFEEInfo> STUDFEElist = new ArrayList<STUDFEEInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(STUDFEE.class);
			STUDFEElist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new STUDENTFEEException("Error occured:", e.getMessage());
		}
		System.out.println("STUFEEDAOImpl - fetchSTUDFEEData method ends");
		return STUDFEElist;
	}
	
	/*	
	public BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException{
		System.out.println("SOWDAOImpl - currCalculation method starts");
		BigDecimal resultvalue = null;
		resultvalue = calculatedResult(curtype, curvalue);
		System.out.println("SOWDAOImpl - currCalculation method starts");
		return resultvalue;
	}*/
	
}
