package com.stu.dao.Impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractSchoolDao;
import com.stu.dao.SchoolDao;
import com.stu.exception.SCHOOLException;
import com.stu.model.School;
import com.stu.model.JSON.SchoolInfo;

@Repository("/schoolDAOImpl")
public class SchoolDaoImpl extends AbstractSchoolDao<Integer, School> implements SchoolDao{

	public List<SchoolInfo> fetchSchoolData() throws SCHOOLException {
		System.out.println("SchoolDaoImpl - fetchAllSchoolData method starts");
		List<SchoolInfo> schoolList = new ArrayList<SchoolInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(School.class);
			schoolList = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new SCHOOLException("Error occured:", e.getMessage());
		}
		System.out.println("SchoolDaoImpl - fetchAllSchoolData method ends");
		return schoolList;
	}

	public List<SchoolInfo> showSchool(int schoolId) throws SCHOOLException {
		System.out.println("SchoolDaoImpl - fetchSchoolData method starts");
		List<SchoolInfo> schoolList = new ArrayList<SchoolInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(School.class).add( Restrictions.eq("schoolId", schoolId ) );
			schoolList = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new SCHOOLException("Error occured:", e.getMessage());
		}
		System.out.println("SchoolDaoImpl - fetchSchoolData method ends");
		return schoolList;
	}

	public String addSchool(School school) throws SCHOOLException {
		System.out.println("SchoolDaoImpl - addSchool method starts");
		saveOrUpdate(school);
		System.out.println("SchoolDaoImpl - addSchool method ends");
		return "success";
		
	}

	public void deleteSchool(int data) throws SCHOOLException {
		System.out.println("SchoolDaoImpl - fetchSchoolData method starts");
  		School schoolDetails = new School();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(School.class).add( Restrictions.eq("schoolId", data ) );
			schoolDetails = (School) cr.list().get(0);
			session.delete(schoolDetails);;
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new SCHOOLException("Error occured:", e.getMessage());
		}
		System.out.println("SchoolDaoImpl - fetchSchoolData method ends");
	}
}
