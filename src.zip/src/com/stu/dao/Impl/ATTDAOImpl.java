package com.stu.dao.Impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.ATTDAO;
import com.stu.dao.AbstractAttDao;
import com.stu.exception.ATTException;
import com.stu.model.ATT;
import com.stu.model.LateComingList;
import com.stu.model.JSON.ATTInfo;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.STUReaderTypeCount;
import com.stu.model.JSON.StudentClass;
import com.stu.model.JSON.StudentInfoTrack;
import com.stu.model.JSON.TrackStudentInfo;



@Repository("/attDAOImpl")
public class ATTDAOImpl extends AbstractAttDao<Integer, ATT> implements
		ATTDAO {
	
	public String saveAddATT(ATT addATT)throws ATTException{
		System.out.println("ATTDAOImpl - saveAddATT method starts");
		saveOrUpdate(addATT);
		System.out.println("ATTDAOImpl - saveAddATT method ends");
		return "success";
	}
	
	@SuppressWarnings("unchecked")
	public List<ATTInfo> fetchAATTData(int ATTid)throws ATTException{
		System.out.println("ATTDAOImpl - fetchAATTData method starts");
		List<ATTInfo> ATTlist = new ArrayList<ATTInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(ATT.class).add( Restrictions.eq("attid", ATTid ) );
			ATTlist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ATTException("Error occured:", e.getMessage());
		}
		System.out.println("ATTDAOImpl - fetchAATTData method ends");
		return ATTlist;
	}
	
	public List<ATTInfo> fetchAllATTData()throws ATTException{
		System.out.println("ATTDAOImpl - fetchAllATTData method starts");
		List<ATTInfo> ATTAlllist = new ArrayList<ATTInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(ATT.class);
			ATTAlllist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ATTException("Error occured:", e.getMessage());
		}
		System.out.println("ATTDAOImpl - fetchAllATTData method ends");
		return ATTAlllist;
	}
	
	/*public List<ATTInfo> fetchPreData()throws ATTException{
		System.out.println("ATTDAOImpl - fetchPreData method starts");
		List<ATTInfo> ATTAlllist = new ArrayList<ATTInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(ATT.class);
			ATTAlllist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new ATTException("Error occured:", e.getMessage());
		}
		System.out.println("ATTDAOImpl - fetchAllATTData method ends");
		return ATTAlllist;
	}*/
	
	public List<ATTInfo> fetchPreData()throws ATTException{
	Session session = getSession();
	Transaction tx = null;
	List<ATTInfo> studAttList = null;
	
	try {
		tx = session.beginTransaction();
		//studentList = session.createCriteria(Student.class).list();
		
		String sql = "select a.class_name,b.section, a.precount, c.abscount from  "+
				"(select count(*) precount, CLASS_NAME, CLASS_ID from STUDENT_ATTANDANCE where STUDENT_ATTENDANCE = 'P'  group by CLASS_NAME, class_id)a, (select count(*) abscount, CLASS_NAME, CLASS_ID from STUDENT_ATTANDANCE where STUDENT_ATTENDANCE = 'Ab'  group by CLASS_NAME, class_id)c, STUDENT_CLASS b where a.class_id = b.CLASS_ID AND c.class_id = b.CLASS_ID"
				+ " ORDER BY a.class_name ASC ,b.section ASC ";
			
		SQLQuery query = session.createSQLQuery(sql);
		
		List<Object[]> results = query.list();
		studAttList = new ArrayList<ATTInfo>();		
		for (Object[] row : results) {
			ATTInfo preInfo = new ATTInfo();
			StudentClass studClass = new StudentClass();
			
			String className="";
			if (row[0] != null && row[0] != "") {
				className =row[0].toString();		
				preInfo.setClassName(className);	
			}
			String section="";
			if (row[1] != null && row[1] != "") {
				section =row[1].toString();				
				studClass.setSection(section);	
			}	
			
			int presentCount=0;
			if (row[2] != null && row[2] != "") {
				presentCount =Integer.valueOf(row[2].toString());				
				studClass.setPresentCount(presentCount);	
			}
			
			int absentCount=0;
			if (row[3] != null && row[3] != "") {
				absentCount =Integer.valueOf(row[3].toString());				
				studClass.setAbsentCount(absentCount);	
			}			
			preInfo.setStudentClass(studClass);
			
			studAttList.add(preInfo);
		}		
		tx.commit();
	} catch (HibernateException e) {
		if (tx != null)
		tx.rollback();
		e.printStackTrace();
	} 
	return studAttList;

	}
	
	public List<ATTInfo> fetchAbsData()throws ATTException{
		Session session = getSession();
		Transaction tx = null;
		List<ATTInfo> studAttList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select a.class_name,b.section, a.precount from "+
	"(select count(*) precount, CLASS_NAME, CLASS_ID from STUDENT_ATTANDANCE where STUDENT_ATTENDANCE = 'Ab'  group by CLASS_NAME, class_id) a, STUDENT_CLASS b where a.class_id = b.CLASS_ID ";
			
			SQLQuery query = session.createSQLQuery(sql);
			
			List<Object[]> results = query.list();
			studAttList = new ArrayList<ATTInfo>();			
			for (Object[] row : results) {
				ATTInfo msgval = new ATTInfo();
				StudentClass studClass = new StudentClass();
				
				String className="";
				if (row[0] != null && row[0] != "") {
					className =row[0].toString();		
					msgval.setClassName(className);	
				}
				String section="";
				if (row[1] != null && row[1] != "") {
					section =row[1].toString();				
					studClass.setSection(section);	
				}				
				int absentCount=0;
				if (row[2] != null && row[2] != "") {
					absentCount =Integer.valueOf(row[2].toString());				
					studClass.setAbsentCount(absentCount);	
				}
				msgval.setStudentClass(studClass);
				studAttList.add(msgval);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} 
		return studAttList;

		}
	
	public List<STUReaderTypeCount> fetchAreaSTUDetails(int readerID)throws ATTException{
		Session session = getSession();
		Transaction tx = null;
		List<STUReaderTypeCount> studAreaList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			/*String sql = "Select DISTINCT(sc.reader_type_id), st.reader_type_Name,a.stuCount, sc.reader_name "+
					"from (select count(*)stuCount ,readerId from StudentMasterInfo where Readerid="+readerID+" group by readerId)a, " +
					"STUDENT_READER_CONFIG sc,STUDENT_READER_TYPE st "+
					"where sc.READER_TYPE_ID=st.READER_TYPE_ID AND sc.READER_ID = '"+readerID+"' ";*/
			
			String sql = "select st.READER_TYPE_ID,st.reader_type_Name, a.reader_Id, sc.reader_name, a.stuCount  "+
					"from (select count(*)stuCount ,reader_Id, entry_time from reader where entry_time BETWEEN NOW() - INTERVAL 2 MINUTE AND NOW() AND Reader_id IN (select READER_ID from STUDENT_READER_CONFIG where READER_TYPE_ID='"+readerID+"') group by reader_Id)a,"+
					"STUDENT_READER_CONFIG sc, STUDENT_READER_TYPE st where a.reader_Id = sc.READER_ID AND st.READER_TYPE_ID = sc.READER_TYPE_ID UNION  "+
					"select 0,'',0,'',0 from ( "+
					"select count(*) as cc from  "+
					"( "+
					"select count(*)stuCount ,reader_Id, entry_time  "+
					"from reader where   "+
					"entry_time BETWEEN NOW() - INTERVAL 2 MINUTE AND NOW()  AND Reader_id IN  "+
					"(select READER_ID from STUDENT_READER_CONFIG where READER_TYPE_ID=1)  group by reader_Id "+
					")k "+
					")l "+
					"where l.cc=0 " ;
			
			SQLQuery query = session.createSQLQuery(sql);
			
			
			
			List<Object[]> results = query.list();
			studAreaList = new ArrayList<STUReaderTypeCount>();			
			for (Object[] row : results) {
				STUReaderTypeCount stuReaderCount = new STUReaderTypeCount();
				
				int readerTypeId=readerID;
				if (row[0] != null && row[0] != "") {					
					readerTypeId =Integer.valueOf(row[0].toString());		
					stuReaderCount.setReaderTypeId(readerTypeId);
				}
				String readerTypName="";
				if (row[1] != null && row[1] != "") {
					readerTypName =row[1].toString();				
					stuReaderCount.setReaderTypName(readerTypName);
				}	
				int readerId=0;
				if (row[2] != null && row[2] != "") {
					readerId =Integer.valueOf(row[2].toString());				
					stuReaderCount.setReaderID(readerId);
				}
				String readerName="";
				if (row[3] != null && row[3] != "") {
					readerName =row[3].toString();				
					stuReaderCount.setReaderName(readerName);
				}	
				int studentCount=0;
				if (row[4] != null && row[4] != "") {
					studentCount =Integer.valueOf(row[4].toString());				
					stuReaderCount.setStudentCount(studentCount);
				}					
				studAreaList.add(stuReaderCount);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} 
		return studAreaList;

		}
	
	public List<STUDInfo> fetchSTUAreaList(int readerID)throws ATTException{
		Session session = getSession();
		Transaction tx = null;
		List<STUDInfo> studInfoList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select STUDENT_ID, STUDENT_NAME from STUDENTDETAILS where STUDENT_ID IN  "+
			"(select STUDENTID from STUDENT_CARD where CARDID IN " +
			"(select DISTINCT(CARDID) from READER where READER_ID = '"+readerID+"'))";			
			
			SQLQuery query = session.createSQLQuery(sql);
			
			List<Object[]> results = query.list();
			studInfoList = new ArrayList<STUDInfo>();			
			for (Object[] row : results) {
				
				STUDInfo studentInfo = new STUDInfo();
				
				int studentID=0;
				if (row[0] != null && row[0] != "") {
					studentID =(int)Double.parseDouble(row[0].toString());		
					studentInfo.setSid(studentID);
				}
				String studentName="";
				if (row[1] != null && row[1] != "") {
					studentName =row[1].toString();				
					studentInfo.setSname(studentName);
				}		
				
				studInfoList.add(studentInfo);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} 
		return studInfoList;

		}
	//
	
	public StudentInfoTrack trackStudentInfo(int studentId, int classId)throws ATTException{
		Session session = getSession();
		Transaction tx = null;
		List<TrackStudentInfo> studInfoList = null;
		StudentInfoTrack studentInfo1 = new StudentInfoTrack();
		
		String studentName="";
		String className="";
		String section="";		
		String schoolStartTime="";
		String schoolEndTime="";
		Timestamp  stuEntryTime = null;
		Timestamp  stuExitTime = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			/*String sql =  "select a.student_name, b.class_name, b.section, c.period, c.start_time, d.SCHOOL_END_TIME, e.entryTime from "+
			"(select student_name, STUDENT_ID from STUDENTDETAILS where STUDENT_ID='"+studentId+"')a, " +
			"(select CLASS_NAME, SECTION, CLASS_ID FROM STUDENT_CLASS where CLASS_ID='"+classId+"')b, (select PERIOD,START_TIME,CLASS_ID from PERIOD_DETAILS where CLASS_ID='"+classId+"')c, "+
			"(select SCHOOL_END_TIME from SCHOOL_TIME)d, (select max(ENTRY_TIME) AS entryTime from READER where CARDID='"+studentId+"')e ";*/
			
			String sql =  "select a.student_name, b.CLASS_NAME, b.SECTION, e.period, e.reader_name, e.entry_time, d.SCHOOL_START_TIME, d.SCHOOL_END_TIME, e.CLASS_ID,f.studententrytime,f.studentexittime  "+
			"from"+
			"(select student_name, STUDENT_ID from STUDENTDETAILS where STUDENT_ID='"+studentId+"')a "+
			"join"+
			 " (select s.reader_name, s.CLASS_ID, r.CARDID, r.entry_time, period_details.period from (select DISTINCT(READER_ID) as reader, CARDID, entry_time from READER where CARDID='"+studentId+"')r "+
			  "join"+
			 " STUDENT_READER_CONFIG s"+
			 " on r.reader = s.reader_id"+
			 " left outer join period_details"+
			 " on s.CLASS_ID= period_details.CLASS_ID and"+
			                             " ("+
			                              "  (FORMAT(r.entry_time,'%H:%i:%s')=FORMAT(period_details.start_time, '%H:%i:%s'))"+
			                              "  or "+
			                              "  (FORMAT(r.entry_time,'%H:%i:%s') > FORMAT(period_details.start_time, '%H:%i:%s')"+
			                               "   AND FORMAT(r.entry_time,'%H:%i:%s') < FORMAT(period_details.end_time, '%H:%i:%s'))"+
			                             " )"+
			 " ) e "+
			"on a.STUDENT_ID=e.CARDID ,"+
			"(select CLASS_NAME, SECTION, CLASS_ID FROM STUDENT_CLASS where CLASS_ID='"+classId+"')b, (select SCHOOL_START_TIME,SCHOOL_END_TIME from SCHOOL_TIME)d,(select min(entry_time) as studententrytime, max(entry_time) as studentexittime "+
                       " from reader where CARDID=1)f "+
			"where 1=1" ;
			
			SQLQuery query = session.createSQLQuery(sql);
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH.mm.ss");
			
			List<Object[]> results = query.list();
			studInfoList = new ArrayList<TrackStudentInfo>();	
						
			studentInfo1.setStudentId(studentId);
			studentInfo1.setClassId(classId);			
		
			for (Object[] row : results) {
				
				TrackStudentInfo studentInfo = new TrackStudentInfo();
				
				//studentInfo.setStudentId(studentId);
				//studentInfo.setClassId(classId);
				
				
				if (row[0] != null && row[0] != "") {
					studentName =row[0].toString();				
					//studentInfo.setStudentName(studentName);
				}
								
				if (row[1] != null && row[1] != "") {
					className =row[1].toString();				
					//studentInfo.setClassName(className);
				}
				
				
				if (row[2] != null && row[2] != "") {
					section =row[2].toString();				
					//studentInfo.setSection(section);
				}
				String period="";
				if (row[3] != null && row[3] != "") {
					period =row[3].toString();				
					studentInfo.setPeriod(period);
				}
				
				String readerName="";
				if (row[4] != null && row[4] != "") {
					readerName =row[4].toString();				
					studentInfo.setReaderName(readerName);
				}
				
				Timestamp  readerEntryTime;
				if (row[5] != null) {
					readerEntryTime =Timestamp.valueOf(row[5].toString());				
					studentInfo.setReaderEntryTime(sdf.format(readerEntryTime));
				}
				
				if (row[6] != null && row[6] != "") {
					schoolStartTime =row[6].toString();				
					//studentInfo.setSchoolStartTime(schoolStartTime);
				}
				
				if (row[7] != null && row[7] != "") {
					schoolEndTime =row[7].toString();				
					//studentInfo.setSchoolEndTime(schoolEndTime);
				}
								
				if (row[9] != null) {
					stuEntryTime =Timestamp.valueOf(row[9].toString());	
					
				}
								
				if (row[10] != null) {
					stuExitTime =Timestamp.valueOf(row[10].toString());				
					
				}
				
				studInfoList.add(studentInfo);				
			}	
			studentInfo1.setStudentName(studentName);
			studentInfo1.setClassName(className);
			studentInfo1.setSection(section);
			studentInfo1.setSchoolStartTime(schoolStartTime);
			studentInfo1.setSchoolEndTime(schoolEndTime);
			if(stuEntryTime!=null)
			studentInfo1.setStudentEntryTime(sdf.format(stuEntryTime));
			if(stuExitTime!=null)
			studentInfo1.setStudentExitTime(sdf.format(stuExitTime));
			studentInfo1.setTrackStudentInfo(studInfoList);
			
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} 
		return studentInfo1;

		}
	
	public List<LateComingList> fetchLateComingQueryList(String day, int month, int year) {
		List<LateComingList> lateCmgList = new ArrayList<LateComingList>();
		List<Object[]> lateComingList = new ArrayList<Object[]>();
		List<Integer> cardList = new ArrayList<Integer>();
		Session session = null;
		String sql = null;
		Query query = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			
			if(!"null".equals(day) && !"".equals(day) && !"0".equals(day)){
				 sql = "select count(1) lateCount,  STUDENT_ID, STUDENT_NAME from "
				 		+ "(select min(R.ENTRY_TIME) Entry_time, R.Cardid from Reader R  "
				 		+ "where EXTRACT(HOUR FROM R.ENTRY_TIME) > 7 and "
				 		+ "EXTRACT(MINUTE FROM R.ENTRY_TIME) >  10 "
				 		+ "group by DATE(entry_time), cardid ) a, STUDENTDETAILS SD, STUDENT_CARD SC "
				 		+ "where DATE(Entry_time) =:date and a.Cardid=SC.CARDID AND SD.STUDENT_ID=SC.STUDENTID "
				 		+ "GROUP BY STUDENT_ID,STUDENT_NAME ,a.CARDID";
				 query = session.createSQLQuery(sql).setParameter("date", day);
			}else 
			
			if(month != 0 && year != 0){
				sql = "select count(1) lateCount,  STUDENT_ID, STUDENT_NAME from "
				 		+ "(select min(R.ENTRY_TIME) Entry_time, R.Cardid from Reader R  "
				 		+ "where EXTRACT(HOUR FROM R.ENTRY_TIME) > 7 and "
				 		+ "EXTRACT(MINUTE FROM R.ENTRY_TIME) >  10 "
				 		+ "group by DATE(entry_time), cardid ) a, STUDENTDETAILS SD, STUDENT_CARD SC "
				 		+ "where EXTRACT(MONTH FROM a.Entry_time) = :month and EXTRACT(YEAR FROM a.Entry_time) = :year  "
				 		+ "and  a.Cardid=SC.CARDID AND SD.STUDENT_ID=SC.STUDENTID "
				 		+ "GROUP BY STUDENT_ID,STUDENT_NAME ,a.CARDID";
				query = session.createSQLQuery(sql).setParameter("month", month).setParameter("year", year);
			}else if(year != 0){
				sql = "select count(1) lateCount,  STUDENT_ID, STUDENT_NAME from "
				 		+ "(select min(R.ENTRY_TIME) Entry_time, R.Cardid from Reader R  "
				 		+ "where EXTRACT(HOUR FROM R.ENTRY_TIME) > 7 and "
				 		+ "EXTRACT(MINUTE FROM R.ENTRY_TIME) >  10 "
				 		+ "group by DATE(entry_time), cardid ) a, STUDENTDETAILS SD, STUDENT_CARD SC "
				 		+ "where EXTRACT(YEAR FROM a.Entry_time) = :year  "
				 		+ "and  a.Cardid=SC.CARDID AND SD.STUDENT_ID=SC.STUDENTID "
				 		+ "GROUP BY STUDENT_ID,STUDENT_NAME ,a.CARDID";
				query = session.createSQLQuery(sql).setParameter("year", year);
			}
			
			
			lateComingList = query.list();
			
			/*int lateComingCount = cardList.size();
			
			if(lateComingCount != 0){
				sql = "select student_id, student_name from studentdetails where student_id IN "
						+ "(select studentid from student_card where student_card.cardid IN (:cardList))";
				query = session.createSQLQuery(sql).setParameterList("cardList", cardList);
			}
			lateComingList = query.list();*/
			
			LateComingList ls = null;
			if(!lateComingList.isEmpty()){
				for(Object[] ob : lateComingList){
					ls = new LateComingList();
					ls.setLateComingCount(Integer.parseInt(ob[0].toString()));
					ls.setStudentId(Integer.parseInt(ob[1].toString()));
					ls.setStudentName(ob[2].toString());
					lateCmgList.add(ls);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally{
			session.close();
		}
		return lateCmgList;
	}
	
	public List<LateComingList> fetchYearlyLateComingList(int year) {
		List<Object[]> result = new ArrayList<Object[]>();
		List<LateComingList> lateCmgList = new ArrayList<LateComingList>();
		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			Query query = session.createSQLQuery("CALL STUDENT_COUNT_YEAR(:year)").setParameter("year", year);
			int rs =query.executeUpdate();
			
			if(rs == 0){
				query = session.createSQLQuery("select * from TEMP_STUDENT");
				result =query.list();
				LateComingList ls = null;
				if(!result.isEmpty()){
					for(Object[] ob : result){
						ls = new LateComingList();
						ls.setLateComingCount(Integer.parseInt(ob[0].toString()));
						ls.setStudentId(Integer.parseInt(ob[1].toString()));
						ls.setStudentName(ob[2].toString());
						lateCmgList.add(ls);
					}
				}
				
			}
			
			//woList = query.list();
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally{
			session.close();
		}
		return lateCmgList;
	}
	
	public List<LateComingList> fetchMonthlyLateComingList(int month, int year) {
		List<Object[]> result = new ArrayList<Object[]>();
		List<LateComingList> lateCmgList = new ArrayList<LateComingList>();
		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			Query query = session.createSQLQuery("CALL STUDENT_COUNT_MONTH(:month, :year)").setParameter("month", month).setParameter("year", year);
			int rs =query.executeUpdate();
			
			if(rs == 0){
				query = session.createSQLQuery("select * from TEMP_STUDENT");
				result =query.list();
				LateComingList ls = null;
				if(!result.isEmpty()){
					for(Object[] ob : result){
						ls = new LateComingList();
						ls.setLateComingCount(Integer.parseInt(ob[0].toString()));
						ls.setStudentId(Integer.parseInt(ob[1].toString()));
						ls.setStudentName(ob[2].toString());
						lateCmgList.add(ls);
					}
				}
				
			}
			
			//woList = query.list();
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally{
			session.close();
		}
		return lateCmgList;
	}
	
	public List<LateComingList> fetchDailyLateComingList(String date) {
		List<Object[]> result = new ArrayList<Object[]>();
		List<LateComingList> lateCmgList = new ArrayList<LateComingList>();
		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			Query query = session.createSQLQuery("CALL STUDENT_COUNT_DAILY(:date)").setParameter("date", date);
			int rs =query.executeUpdate();
			
			if(rs == 0){
				query = session.createSQLQuery("select * from TEMP_STUDENT");
				result =query.list();
				LateComingList ls = null;
				if(!result.isEmpty()){
					for(Object[] ob : result){
						ls = new LateComingList();
						ls.setLateComingCount(Integer.parseInt(ob[0].toString()));
						ls.setStudentId(Integer.parseInt(ob[1].toString()));
						ls.setStudentName(ob[2].toString());
						lateCmgList.add(ls);
					}
				}
				
			}
			
			//woList = query.list();
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally{
			session.close();
		}
		return lateCmgList;
	}
	
	public List<LateComingList> fetchWeeklyLateComingQueryList(int count) {
		List<LateComingList> lateCmgList = new ArrayList<LateComingList>();
		List<Object[]> lateComingList = new ArrayList<Object[]>();
		List<Integer> cardList = new ArrayList<Integer>();
		Session session = null;
		String sql = null;
		Query query = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			
			
				 sql = "select count(1) lateCount,  STUDENT_ID, STUDENT_NAME from "
				 		+ "(select min(R.ENTRY_TIME) Entry_time, R.Cardid from Reader R  "
				 		+ "where EXTRACT(HOUR FROM R.ENTRY_TIME) > 7 and "
				 		+ "EXTRACT(MINUTE FROM R.ENTRY_TIME) >  10 "
				 		+ "group by DATE(entry_time), cardid ) a, STUDENTDETAILS SD, STUDENT_CARD SC "
				 		+ "where  WEEK(a.ENTRY_TIME) = WEEK(CURDATE())-:count "
				 		+ "and a.Cardid=SC.CARDID AND SD.STUDENT_ID=SC.STUDENTID "
				 		+ "GROUP BY STUDENT_ID,STUDENT_NAME ,a.CARDID";
				 query = session.createSQLQuery(sql).setParameter("count", count);
			
			
			lateComingList = query.list();
			
			LateComingList ls = null;
			if(!lateComingList.isEmpty()){
				for(Object[] ob : lateComingList){
					ls = new LateComingList();
					ls.setLateComingCount(Integer.parseInt(ob[0].toString()));
					ls.setStudentId(Integer.parseInt(ob[1].toString()));
					ls.setStudentName(ob[2].toString());
					lateCmgList.add(ls);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally{
			session.close();
		}
		return lateCmgList;
	}
	
	public List<LateComingList> fetchLateComingList(int month, int year) {
		List<Object[]> result = new ArrayList<Object[]>();
		List<LateComingList> lateCmgList = new ArrayList<LateComingList>();
		Session session = null;
		try {
			session = getSession();
			session.getTransaction().begin();
			Query query = session.createSQLQuery("CALL STUDENT_COUNT_MONTH(:month, :year)").setParameter("month", month).setParameter("year", year);
			int rs =query.executeUpdate();
			
			if(rs == 0){
				query = session.createSQLQuery("select * from TEMP_STUDENT");
				result =query.list();
				LateComingList ls = null;
				if(!result.isEmpty()){
					for(Object[] ob : result){
						ls = new LateComingList();
						ls.setLateComingCount(Integer.parseInt(ob[0].toString()));
						ls.setStudentId(Integer.parseInt(ob[1].toString()));
						ls.setStudentName(ob[2].toString());
						lateCmgList.add(ls);
					}
				}
				
			}
			
			//woList = query.list();
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			session.getTransaction().rollback();
		} finally{
			session.close();
		}
		return lateCmgList;
	}

	
/*	
	public List<SOWInfo> fetchSOWData()throws SOWException{
		System.out.println("SOWDAOImpl - fetchSOW method starts");
		List<SOWInfo> allSOW = new ArrayList<SOWInfo>();
		if (allSOW == null || allSOW.isEmpty()) {
			allSOW = createListEntityCriteria();
		}
		System.out.println("SOWDAOImpl - fetchSOW method ends");
		return allSOW;
	}

	public BigDecimal currCalculation(String curtype, BigDecimal curvalue)throws SOWException{
		System.out.println("SOWDAOImpl - currCalculation method starts");
		BigDecimal resultvalue = null;
		resultvalue = calculatedResult(curtype, curvalue);
		System.out.println("SOWDAOImpl - currCalculation method starts");
		return resultvalue;
	}*/
	
}
