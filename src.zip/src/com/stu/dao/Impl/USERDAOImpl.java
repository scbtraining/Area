package com.stu.dao.Impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractStudDao;
import com.stu.dao.AbstractUserDao;
import com.stu.dao.STUDAO;
import com.stu.dao.USERDAO;
import com.stu.exception.STUDENTException;
import com.stu.exception.USERException;
import com.stu.model.STUD;
import com.stu.model.USER;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.USERInfo;



@Repository("/userDAOImpl")
public class USERDAOImpl extends AbstractUserDao<Integer, USER> implements
		USERDAO {
	
	public String saveAddUSER(USER addUSER)throws USERException{
		System.out.println("USERDAOImpl - saveAddUSER method starts");
		saveOrUpdate(addUSER);
		System.out.println("USERDAOImpl - saveAddUSER method ends");
		return "success";
	}
	
	@Override
	public List<USERInfo> fetchAUserData(Integer userId) throws USERException {
		System.out.println("USERDAOImpl - fetchAUserData method starts");
		List<USERInfo> Userlist = new ArrayList<USERInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(USER.class).add( Restrictions.eq("userId", userId ) );
			Userlist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new USERException("Error occured:", e.getMessage());
		}
		System.out.println("USERDAOImpl - fetchAUserData method ends");
		return Userlist;
	}
	
	@Override
	public List<USERInfo> fetchAllUserData() throws USERException {
		System.out.println("USERDAOImpl - fetchAllUserData method starts");
		List<USERInfo> AllUserlist = new ArrayList<USERInfo>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try
		{
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(USER.class);
			AllUserlist = cr.list();
			trans.commit();
		}
		catch (Exception e) {
			trans.rollback();
			throw new USERException("Error occured:", e.getMessage());
		}
		System.out.println("USERDAOImpl - fetchAllUserData method ends");
		return AllUserlist;
	}
}
