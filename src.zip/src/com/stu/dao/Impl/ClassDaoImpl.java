package com.stu.dao.Impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.stu.dao.AbstractClassDao;
import com.stu.dao.ClassDao;
import com.stu.exception.ClassException;
import com.stu.model.STUDENTCLASS;
import com.stu.model.JSON.StudentClass;

@Repository("/classDAOImpl")
public class ClassDaoImpl extends AbstractClassDao<Integer, STUDENTCLASS> implements ClassDao {

	public String addClass(STUDENTCLASS addStudentClass) throws ClassException {
		System.out.println("ClassDaoImpl - addClass method starts");
		saveOrUpdate(addStudentClass);
		System.out.println("ClassDaoImpl - addClass method ends");
		return "success";
	}

	@SuppressWarnings("unchecked")
	public List<StudentClass> showClass(int classID) throws ClassException {
		System.out.println("ClassDaoImpl - showClass method starts");
		List<StudentClass> classList = new ArrayList<StudentClass>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try {
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(STUDENTCLASS.class).add(Restrictions.eq("classID", classID));
			classList = cr.list();
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			throw new ClassException("Error occured:", e.getMessage());
		}
		System.out.println("ClassDaoImpl - showClass method ends");
		return classList;
	}

	@SuppressWarnings("unchecked")
	public List<StudentClass> showAllClass() throws ClassException {
		System.out.println("ClassDaoImpl - showAllClass method starts");
		List<StudentClass> AllClasslist = new ArrayList<StudentClass>();
		Session session = null;
		Transaction trans = null;
		Criteria cr = null;
		try {
			session = getSession();
			trans = session.beginTransaction();
			cr = session.createCriteria(STUDENTCLASS.class);
			AllClasslist = cr.list();
			trans.commit();
		} catch (Exception e) {
			trans.rollback();
			throw new ClassException("Error occured:", e.getMessage());
		}
		System.out.println("ClassDaoImpl - showAllClass method ends");
		return AllClasslist;
	}

	@SuppressWarnings("unchecked")
	public String deleteClass(int classID) throws ClassException {
		Session session = null;
		Transaction trans = null;
		String status = "failure";
		try {
			session = getSession();
			trans = session.beginTransaction();
			STUDENTCLASS p = (STUDENTCLASS) session.load(STUDENTCLASS.class, new Integer(classID));
			if (null != p) {
				session.delete(p);
				status = "success";
			}  
			trans.commit();

		} catch (Exception e) {
			trans.rollback();

			throw new ClassException("Error occured:", e.getMessage());

		} finally {
			System.out.println("ClassDaoImpl - deleteClass method ends");
			return status;
		}

	}
}
