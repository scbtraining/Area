package com.stu.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "fee")
public class FEE implements Serializable {

	private static final long serialVersionUID = 8704535406621494434L;

	@Id
	@Column(name = "fee_id")
	private Integer feeid;

	@Column(name = "fee_amount")
	private Integer feeamount;

	@Column(name = "class_id")
	private Integer classid;

	@Column(name = "school_id")
	private Integer schoolid;

	public Integer getFeeid() {
		return feeid;
	}

	public void setFeeid(Integer feeid) {
		this.feeid = feeid;
	}

	public Integer getFeeamount() {
		return feeamount;
	}

	public void setFeeamount(Integer feeamount) {
		this.feeamount = feeamount;
	}

	public Integer getSchoolid() {
		return schoolid;
	}

	public void setSchoolid(Integer schoolid) {
		this.schoolid = schoolid;
	}

	public Integer getClassid() {
		return classid;
	}

	public void setClassid(Integer classid) {
		this.classid = classid;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
