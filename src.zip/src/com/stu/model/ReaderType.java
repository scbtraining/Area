package com.stu.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_reader_type")
public class ReaderType  {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "reader_type_id")
	private String readerTypeId;

	@Column(name = "reader_type_name")
	private String readerTypeName;

	@Column(name = "reader_type_desc")
	private String readerTypeDesc;

	public String getReaderTypeId() {
		return readerTypeId;
	}

	public void setReaderTypeId(String readerTypeId) {
		this.readerTypeId = readerTypeId;
	}

	public String getReaderTypeName() {
		return readerTypeName;
	}

	public void setReaderTypeName(String readerTypeName) {
		this.readerTypeName = readerTypeName;
	}

	public String getReaderTypeDesc() {
		return readerTypeDesc;
	}

	public void setReaderTypeDesc(String readerTypeDesc) {
		this.readerTypeDesc = readerTypeDesc;
	}

	

}
