package com.stu.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "student_area_range_point_dtl")
public class AreaRangePoint {
	@Id
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "area_range_dtl_seq")
//	@SequenceGenerator(name = "area_range_dtl_seq", sequenceName = "AREA_RANGE_DTL_POINTID_SEQ", allocationSize = 1)
	@Column(name = "pointid")
	private int pointId;
	@Column(name = "latitude")
	private float lat;
	@Column(name = "longtitude")
	private float lng;
	@ManyToOne
	@JoinColumn(name = "buildingid")
	private AreaRange areaRange;
	
	public AreaRange getAreaRange() {
		return areaRange;
	}
	public void setAreaRange(AreaRange areaRange) {
		this.areaRange = areaRange;
	}
	public int getPointId() {
		return pointId;
	}
	public void setPointId(int pointId) {
		this.pointId = pointId;
	}
	public float getLat() {
		return lat;
	}
	public void setLat(float lat) {
		this.lat = lat;
	}
	public float getLng() {
		return lng;
	}
	public void setLng(float lng) {
		this.lng = lng;
	}
	
	
}
