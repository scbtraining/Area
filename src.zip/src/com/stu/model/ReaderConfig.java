package com.stu.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_reader_config")
public class ReaderConfig  {


	@Id
	
	@Column(name = "reader_config_id")
	private int readerConfigID;

	@Column(name = "reader_name")
	private String readerName;

	@Column(name = "reader_subname")
	private String readerSubName;
	
	@Column(name = "reader_id")
	private String readerID;
	    
	@Column(name = "reader_type_id") 
	private String readerTypeID;
	
	@Column(name = "gps_enabled") 
	private String gpsEnabled;
	
	@Column(name = "reader_start_time") 
	private String readerStartTime;
	
	@Column(name = "reader_end_time") 
	private String readerEndTime;

	public int getReaderConfigID() {
		return readerConfigID;
	}

	public void setReaderConfigID(int readerConfigID) {
		this.readerConfigID = readerConfigID;
	}

	public String getReaderName() {
		return readerName;
	}

	public void setReaderName(String readerName) {
		this.readerName = readerName;
	}

	public String getReaderSubName() {
		return readerSubName;
	}

	public void setReaderSubName(String readerSubName) {
		this.readerSubName = readerSubName;
	}

	public String getReaderID() {
		return readerID;
	}

	public void setReaderID(String readerID) {
		this.readerID = readerID;
	}

	public String getReaderTypeID() {
		return readerTypeID;
	}

	public void setReaderTypeID(String readerTypeID) {
		this.readerTypeID = readerTypeID;
	}

	public String getGpsEnabled() {
		return gpsEnabled;
	}

	public void setGpsEnabled(String gpsEnabled) {
		this.gpsEnabled = gpsEnabled;
	}

	public String getReaderStartTime() {
		return readerStartTime;
	}

	public void setReaderStartTime(String readerStartTime) {
		this.readerStartTime = readerStartTime;
	}

	public String getReaderEndTime() {
		return readerEndTime;
	}

	public void setReaderEndTime(String readerEndTime) {
		this.readerEndTime = readerEndTime;
	}

}
