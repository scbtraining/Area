package com.stu.model;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="app_config_master")
public class App_Config_Master implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7007859113291815200L;

	@Id
	/*@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "app_config_master_seq")
	@SequenceGenerator(name = "app_config_master_seq", sequenceName = "app_config_master_appid_seq", allocationSize = 1)*/
	@Column(name = "app_id")
	private Integer app_id;
	
	@NotEmpty
	@Column(name = "app_name")
	private String app_name;
	
	@NotEmpty
	@Column(name = "app_host")
	private String app_host;
	
	@NotEmpty
	@Column(name = "app_port")
	private String app_port;

	public Integer getApp_id() {
		return app_id;
	}

	public void setApp_id(Integer app_id) {
		this.app_id = app_id;
	}

	public String getApp_name() {
		return app_name;
	}

	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}

	public String getApp_host() {
		return app_host;
	}

	public void setApp_host(String app_host) {
		this.app_host = app_host;
	}

	public String getApp_port() {
		return app_port;
	}

	public void setApp_port(String app_port) {
		this.app_port = app_port;
	}

	
	
	

}

