package com.stu.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity

@Table(name = "student_fee_details")
public class STUDFEE implements Serializable {

	private static final long serialVersionUID = 8704535406621494434L;

	@Id
	@Column(name = "student_id")
	private Integer sid;

	@Column(name = "fee_id")
	private Integer feeid;

	@Column(name = "paid_amount")
	private Integer paidamount;

	@Column(name = "balance_amount")
	private Integer balanceamount;

	@Column(name = "date_of_paid")
	@Type(type="date")
	private Date dateofpaid;

	public Integer getSid() {
		return sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public Integer getFeeid() {
		return feeid;
	}

	public void setFeeid(Integer feeid) {
		this.feeid = feeid;
	}

	public Integer getPaidamount() {
		return paidamount;
	}

	public void setPaidamount(Integer paidamount) {
		this.paidamount = paidamount;
	}

	public Integer getBalanceamount() {
		return balanceamount;
	}

	public void setBalanceamount(Integer balanceamount) {
		this.balanceamount = balanceamount;
	}

	public Date getDateofpaid() {
		return dateofpaid;
	}

	public void setDateofpaid(Date dateofpaid) {
		this.dateofpaid = dateofpaid;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
