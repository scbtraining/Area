package com.stu.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity

@Table(name = "student_attandance")
public class ATT implements Serializable {

	private static final long serialVersionUID = 8704535406621494434L;

	@Id
	@Column(name = "att_id")
	private Integer attid;

	@Column(name = "course_id")
	private Integer courseid;

	@Column(name = "student_id")
	private Integer studentid;

	@Column(name = "student_attendance")
	private String studentattendance;

	@Column(name = "comments")
	private String comments;

	@Column(name = "date_of_attendance")
	@Type(type="date")
	private Date dateofattendance;

	public Integer getAttid() {
		return attid;
	}

	public void setAttid(Integer attid) {
		this.attid = attid;
	}

	public Integer getCourseid() {
		return courseid;
	}

	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}

	public Integer getStudentid() {
		return studentid;
	}

	public void setStudentid(Integer studentid) {
		this.studentid = studentid;
	}

	public String getStudentattendance() {
		return studentattendance;
	}

	public void setStudentattendance(String studentattendance) {
		this.studentattendance = studentattendance;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getDateofattendance() {
		return dateofattendance;
	}

	public void setDateofattendance(Date dateofattendance) {
		this.dateofattendance = dateofattendance;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
