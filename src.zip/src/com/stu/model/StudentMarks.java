package com.stu.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_marks")
public class StudentMarks {
	@Id
	@GeneratedValue
	@Column(name = "student_id")
	private Integer studentid;
	public Integer getStudentid() {
		return studentid;
	}
	public void setStudentid(Integer studentid) {
		this.studentid = studentid;
	}
	@Column(name = "marks_id")
    private String marksid;
	
	@Column(name = "class_id")
    private String classid;
	
	@Column(name = "subject_id")

	private String subjectid;
	@Column(name = "marks")

	private String marks;
	
	@Column(name = "date_of_exam")

	private Date dateofexam;
	
	@Column(name = "result")

	private String result;
	
		public String getMarksid() {
		return marksid;
	}
	public void setMarksid(String marksid) {
		this.marksid = marksid;
	}
	public String getClassid() {
		return classid;
	}
	public void setClassid(String classid) {
		this.classid = classid;
	}
	public String getSubjectid() {
		return subjectid;
	}
	public void setSubjectid(String subjectid) {
		this.subjectid = subjectid;
	}
	public String getMarks() {
		return marks;
	}
	public void setMarks(String marks) {
		this.marks = marks;
	}
	public Date getDateofexam() {
		return dateofexam;
	}
	public void setDateofexam(Date dateofexam) {
		this.dateofexam = dateofexam;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}


}
