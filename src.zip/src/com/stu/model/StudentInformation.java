package com.stu.model;

import java.math.BigDecimal;
import java.math.BigInteger;

public class StudentInformation {
	
	private String studentId;
	private String studentName;
	private String classId;
	private String classname;
	private String section;
	private BigInteger step_count;
	private BigInteger  calories;
	private BigInteger battary_volt;
	private String body_temp;
	
	
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}

	
	public BigInteger getStep_count() {
		return step_count;
	}
	public void setStep_count(BigInteger step_count) {
		this.step_count = step_count;
	}
	public BigInteger getCalories() {
		return calories;
	}
	public void setCalories(BigInteger calories) {
		this.calories = calories;
	}
	public BigInteger getBattary_volt() {
		return battary_volt;
	}
	public void setBattary_volt(BigInteger battary_volt) {
		this.battary_volt = battary_volt;
	}
	public String getBody_temp() {
		return body_temp;
	}
	public void setBody_temp(String body_temp) {
		this.body_temp = body_temp;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getClassId() {
		return classId;
	}
	public void setClassId(String classId) {
		this.classId = classId;
	}
	
	
	

}
