package com.stu.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "role_access_permission")
public class RoleAccessPermission implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 9152418692301659565L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "role_access_id")
	private Integer roleAccessId;
	@Column(name = "menu_id")
	private Integer menuId;
	@Column(name = "sub_menu_id")
	private Integer subMenuId;
	@Column(name = "role_id")
	private Integer roleId;
	@Column(name = "is_create_enabled")
	private Integer create;
	@Column(name = "is_view_enabled")
	private Integer view;
	@Column(name = "is_delete_enabled")
	private Integer delete;
	@Column(name = "is_edit_enabled")
	private Integer edit;

	public Integer getRoleAccessId() {
		return roleAccessId;
	}

	public void setRoleAccessId(Integer roleAccessId) {
		this.roleAccessId = roleAccessId;
	}

	public Integer getMenuId() {
		return menuId;
	}

	public void setMenuId(Integer menuId) {
		this.menuId = menuId;
	}

	public Integer getSubMenuId() {
		return subMenuId;
	}

	public void setSubMenuId(Integer subMenuId) {
		this.subMenuId = subMenuId;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public Integer getCreate() {
		return create;
	}

	public void setCreate(Integer create) {
		this.create = create;
	}

	public Integer getView() {
		return view;
	}

	public void setView(Integer view) {
		this.view = view;
	}

	public Integer getDelete() {
		return delete;
	}

	public void setDelete(Integer delete) {
		this.delete = delete;
	}

	public Integer getEdit() {
		return edit;
	}

	public void setEdit(Integer edit) {
		this.edit = edit;
	}

}
