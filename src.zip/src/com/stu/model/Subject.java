package com.stu.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
//import com.mining.model.Organisation;


@Entity

@Table(name = "subject")
public class Subject implements Serializable {

	private static final long serialVersionUID = 8704535406621494434L;

	@Id
	@Column(name = "subject_id")
	private Integer subjectId;

	@Column(name = "subject_name")
	private String subjectName;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "subjectId")
	//@JoinColumn(name="SUBJECT_ID")
	private List<SubjectClass> subClass = new ArrayList<SubjectClass>();
	
	/*@OneToOne
	@JoinColumn(name="SUBJECT_ID")
	private SubjectClass subjectClass;*/

	
	public Integer getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public List<SubjectClass> getSubClass() {
		return subClass;
	}

	
	public void setSubClass(List<SubjectClass> subClass) {
		this.subClass = subClass;
	}
	
	/*public SubjectClass getSubjectClass() {
		return subjectClass;
	}

	
	public void setSubjectClass(SubjectClass subjectClass) {
		this.subjectClass = subjectClass;
	}*/
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
