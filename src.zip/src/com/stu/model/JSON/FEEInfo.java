package com.stu.model.JSON;

import java.io.Serializable;
import java.util.Date;

public class FEEInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7639326673869275255L;
	
	private Integer feeid;
	private Integer feeamount;
	private Integer classid;
	private Integer schoolid;
	
	public Integer getFeeid() {
		return feeid;
	}
	public void setFeeid(Integer feeid) {
		this.feeid = feeid;
	}
	public Integer getFeeamount() {
		return feeamount;
	}
	public void setFeeamount(Integer feeamount) {
		this.feeamount = feeamount;
	}
	public Integer getClassid() {
		return classid;
	}
	public void setClassid(Integer classid) {
		this.classid = classid;
	}
	public Integer getSchoolid() {
		return schoolid;
	}
	public void setSchoolid(Integer schoolid) {
		this.schoolid = schoolid;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
