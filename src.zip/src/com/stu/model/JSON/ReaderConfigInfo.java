package com.stu.model.JSON;

public class ReaderConfigInfo  {



	private int readerConfigID;

	private String readerName;

	private String readerSubName;
	 
	
	private String readerID;
	    
	
	private String readerTypeID;
	

	private String gpsEnabled;
	
	 
	private String readerStartTime;
	
	private String readerEndTime;

	public int getReaderConfigID() {
		return readerConfigID;
	}

	public void setReaderConfigID(int readerConfigID) {
		this.readerConfigID = readerConfigID;
	}

	public String getReaderName() {
		return readerName;
	}

	public void setReaderName(String readerName) {
		this.readerName = readerName;
	}

	public String getReaderSubName() {
		return readerSubName;
	}

	public void setReaderSubName(String readerSubName) {
		this.readerSubName = readerSubName;
	}

	public String getReaderID() {
		return readerID;
	}

	public void setReaderID(String readerID) {
		this.readerID = readerID;
	}

	public String getReaderTypeID() {
		return readerTypeID;
	}

	public void setReaderTypeID(String readerTypeID) {
		this.readerTypeID = readerTypeID;
	}

	public String getGpsEnabled() {
		return gpsEnabled;
	}

	public void setGpsEnabled(String gpsEnabled) {
		this.gpsEnabled = gpsEnabled;
	}

	public String getReaderStartTime() {
		return readerStartTime;
	}

	public void setReaderStartTime(String readerStartTime) {
		this.readerStartTime = readerStartTime;
	}

	public String getReaderEndTime() {
		return readerEndTime;
	}

	public void setReaderEndTime(String readerEndTime) {
		this.readerEndTime = readerEndTime;
	}

}
