package com.stu.model.JSON;

import java.io.Serializable;
import java.util.Date;

public class STUDInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7639326673869275255L;
	
	private Integer sid;
	private String sname;
	private String scontact;
	private String sbloodgroup;
	private Date sjoindate;
	private String sgender;
	private String sreligion;
	private Integer sschoolid;
	private Integer sclassid;
	
	public Integer getSid() {
		return sid;
	}
	public void setSid(Integer sid) {
		System.out.println("sid::"+sid);
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getScontact() {
		return scontact;
	}
	public void setScontact(String scontact) {
		this.scontact = scontact;
	}
	public String getSbloodgroup() {
		return sbloodgroup;
	}
	public void setSbloodgroup(String sbloodgroup) {
		this.sbloodgroup = sbloodgroup;
	}
	public Date getSjoindate() {
		return sjoindate;
	}
	public void setSjoindate(Date sjoindate) {
		this.sjoindate = sjoindate;
	}
	public String getSgender() {
		return sgender;
	}
	public void setSgender(String sgender) {
		this.sgender = sgender;
	}
	public String getSreligion() {
		return sreligion;
	}
	public void setSreligion(String sreligion) {
		this.sreligion = sreligion;
	}
	public Integer getSschoolid() {
		return sschoolid;
	}
	public void setSschoolid(Integer sschoolid) {
		this.sschoolid = sschoolid;
	}
	public Integer getSclassid() {
		return sclassid;
	}
	public void setSclassid(Integer sclassid) {
		this.sclassid = sclassid;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
