package com.stu.model.JSON;

import java.io.Serializable;
import java.util.List;

public class AreaRangeInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8911996115152994198L;
	
	private int buildingId;
	private String buildingName;
	private float lat;
	private float lng;
	private int pointId;
	private List<BuildingInfo> buildingpoints;

	public List<BuildingInfo> getBuildingpoints() {
		return buildingpoints;
	}

	public void setBuildingpoints(List<BuildingInfo> buildingpoints) {
		this.buildingpoints = buildingpoints;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public float getLat() {
		return lat;
	}

	public void setLat(float lat) {
		this.lat = lat;
	}

	public float getLng() {
		return lng;
	}

	public void setLng(float lng) {
		this.lng = lng;
	}

	public int getPointId() {
		return pointId;
	}

	public void setPointId(int pointId) {
		this.pointId = pointId;
	}
	
	

}
