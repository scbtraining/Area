package com.stu.model.JSON;

import java.io.Serializable;

public class StudentClass implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5200943808047867589L;
	
	private Integer classID;
	private String className;
	private String section;
	private Integer presentCount;
	private Integer absentCount;
	
	public Integer getPresentCount() {
		return presentCount;
	}
	public void setPresentCount(Integer presentCount) {
		this.presentCount = presentCount;
	}
	public Integer getAbsentCount() {
		return absentCount;
	}
	public void setAbsentCount(Integer absentCount) {
		this.absentCount = absentCount;
	}

	public Integer getClassID() {
		return classID;
	}

	public void setClassID(Integer classID) {
		this.classID = classID;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}
	

}
