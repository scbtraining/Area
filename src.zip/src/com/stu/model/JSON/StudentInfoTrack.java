package com.stu.model.JSON;

import java.util.List;

public class StudentInfoTrack {
	
	private Integer studentId;
	
	private Integer classId;
	
	private String studentName;
	
	private String className;
	
	private String section;
	
	private String schoolStartTime;
	
	private String schoolEndTime;
	
	private String studentEntryTime;	
	
	private String studentExitTime;	
	
	private List<TrackStudentInfo> trackStudentInfo;	
	
	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public Integer getClassId() {
		return classId;
	}

	public void setClassId(Integer classId) {
		this.classId = classId;
	} 
	
	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}
	
	public String getSchoolEndTime() {
		return schoolEndTime;
	}

	public void setSchoolEndTime(String schoolEndTime) {
		this.schoolEndTime = schoolEndTime;
	}

	public String getSchoolStartTime() {
		return schoolStartTime;
	}

	public void setSchoolStartTime(String schoolStartTime) {
		this.schoolStartTime = schoolStartTime;
	}
	
	public List<TrackStudentInfo> getTrackStudentInfo() {
		return trackStudentInfo;
	}

	public void setTrackStudentInfo(List<TrackStudentInfo> trackStudentInfo) {
		this.trackStudentInfo = trackStudentInfo;
	}

	public String getStudentEntryTime() {
		return studentEntryTime;
	}

	public void setStudentEntryTime(String studentEntryTime) {
		this.studentEntryTime = studentEntryTime;
	}

	public String getStudentExitTime() {
		return studentExitTime;
	}

	public void setStudentExitTime(String studentExitTime) {
		this.studentExitTime = studentExitTime;
	}
	
}
