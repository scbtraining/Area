package com.stu.model.JSON;

import java.io.Serializable;

public class App_Config_Master_Info implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8000829884658618818L;
	
	private Integer app_id;
	private String app_name,app_host,app_port;
	public Integer getApp_id() {
		return app_id;
	}
	public void setApp_id(Integer app_id) {
		this.app_id = app_id;
	}
	
	public String getApp_port() {
		return app_port;
	}
	public void setApp_port(String app_port) {
		this.app_port = app_port;
	}
	public String getApp_name() {
		return app_name;
	}
	public void setApp_name(String app_name) {
		this.app_name = app_name;
	}
	public String getApp_host() {
		return app_host;
	}
	public void setApp_host(String app_host) {
		this.app_host = app_host;
	}
	
	
}
