package com.stu.model.JSON;

import java.sql.Date;
import java.sql.Timestamp;

public class TrackStudentInfo {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7639326673869275255L;	
			
	private String period;
	
	private String readerName;
	
	private String readerEntryTime;	
	
	public String getReaderName() {
		return readerName;
	}

	public void setReaderName(String readerName) {
		this.readerName = readerName;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getReaderEntryTime() {
		return readerEntryTime;
	}

	public void setReaderEntryTime(String readerEntryTime) {
		this.readerEntryTime = readerEntryTime;
	}
	
	
}
