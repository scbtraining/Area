package com.stu.model.JSON;

public class RoleAccessPermissionInfo {


	private Integer roleAccessId;
	private Integer menuId;
	private Integer subMenuId;
	private Integer roleId;
	private Integer create;
	private Integer view;
	private Integer delete;
	private Integer edit;
	
	
	public Integer getRoleAccessId() {
		return roleAccessId;
	}
	public void setRoleAccessId(Integer roleAccessId) {
		this.roleAccessId = roleAccessId;
	}
	public Integer getMenuId() {
		return menuId;
	}
	public void setMenuId(Integer menuId) {
		this.menuId = menuId;
	}
	public Integer getSubMenuId() {
		return subMenuId;
	}
	public void setSubMenuId(Integer subMenuId) {
		this.subMenuId = subMenuId;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public Integer getCreate() {
		return create;
	}
	public void setCreate(Integer create) {
		this.create = create;
	}
	public Integer getView() {
		return view;
	}
	public void setView(Integer view) {
		this.view = view;
	}
	public Integer getDelete() {
		return delete;
	}
	public void setDelete(Integer delete) {
		this.delete = delete;
	}
	public Integer getEdit() {
		return edit;
	}
	public void setEdit(Integer edit) {
		this.edit = edit;
	}
	
	
	
	
}
