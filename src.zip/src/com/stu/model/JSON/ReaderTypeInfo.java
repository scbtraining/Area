package com.stu.model.JSON;

public class ReaderTypeInfo {
	
	private String readerTypeId;
	private String readerTypeName;
	private String readerTypeDesc;

	public String getReaderTypeId() {
		return readerTypeId;
	}

	public void setReaderTypeId(String readerTypeId) {
		this.readerTypeId = readerTypeId;
	}

	public String getReaderTypeName() {
		return readerTypeName;
	}

	public void setReaderTypeName(String readerTypeName) {
		this.readerTypeName = readerTypeName;
	}

	public String getReaderTypeDesc() {
		return readerTypeDesc;
	}

	public void setReaderTypeDesc(String readerTypeDesc) {
		this.readerTypeDesc = readerTypeDesc;
	}

}
