package com.stu.model.JSON;

import java.math.BigDecimal;
import java.util.Date;

public class AccessDetailsDto {
	

	private Integer id;
	private BigDecimal student_id;
	private String student_name;
	private String class_name;
	private BigDecimal card_id;
	private String access_date;
	private String readr_start_time;
	private String reader_end_time;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public BigDecimal getStudent_id() {
		return student_id;
	}
	public void setStudent_id(BigDecimal student_id) {
		this.student_id = student_id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	
	public BigDecimal getCard_id() {
		return card_id;
	}
	public void setCard_id(BigDecimal card_id) {
		this.card_id = card_id;
	}
	public String getClass_name() {
		return class_name;
	}
	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}
	
	public String getAccess_date() {
		return access_date;
	}
	public void setAccess_date(String access_date) {
		this.access_date = access_date;
	}
	public String getReadr_start_time() {
		return readr_start_time;
	}
	public void setReadr_start_time(String readr_start_time) {
		this.readr_start_time = readr_start_time;
	}
	public String getReader_end_time() {
		return reader_end_time;
	}
	public void setReader_end_time(String reader_end_time) {
		this.reader_end_time = reader_end_time;
	}
	
	
	
	

}
