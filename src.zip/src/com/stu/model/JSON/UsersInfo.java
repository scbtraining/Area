package com.stu.model.JSON;

import java.io.Serializable;

public class UsersInfo  implements Serializable{
	
	
	private String users_userid;
	
    private String users_emailid;
	
    private String users_password;
	
    private String users_user_name;
	
    private String users_phone_no;
	
    private String users_address;
    
    private String user_role;
    
    private String user_role_id;

	
    
    
	public String getUser_role_id() {
		return user_role_id;
	}

	public void setUser_role_id(String user_role_id) {
		this.user_role_id = user_role_id;
	}

	public String getUser_role() {
		return user_role;
	}

	public void setUser_role(String user_role) {
		this.user_role = user_role;
	}

	public String getUsers_userid() {
		return users_userid;
	}

	public void setUsers_userid(String users_userid) {
		this.users_userid = users_userid;
	}

	public String getUsers_emailid() {
		return users_emailid;
	}

	public void setUsers_emailid(String users_emailid) {
		this.users_emailid = users_emailid;
	}

	public String getUsers_password() {
		return users_password;
	}

	public void setUsers_password(String users_password) {
		this.users_password = users_password;
	}

	public String getUsers_user_name() {
		return users_user_name;
	}

	public void setUsers_user_name(String users_user_name) {
		this.users_user_name = users_user_name;
	}

	public String getUsers_phone_no() {
		return users_phone_no;
	}

	public void setUsers_phone_no(String users_phone_no) {
		this.users_phone_no = users_phone_no;
	}

	public String getUsers_address() {
		return users_address;
	}

	public void setUsers_address(String users_address) {
		this.users_address = users_address;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	private static final long serialVersionUID = -7639326673869275255L;

	

}
