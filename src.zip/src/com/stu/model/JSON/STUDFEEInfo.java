package com.stu.model.JSON;

import java.io.Serializable;
import java.util.Date;

public class STUDFEEInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7639326673869275255L;
	
	private Integer sid;
	private Integer feeid;
	private Integer paidamount;
	private Integer balanceamount;
	private Date dateofpaid;
	
	public Integer getSid() {
		return sid;
	}
	public void setSid(Integer sid) {
		this.sid = sid;
	}
	public Integer getFeeid() {
		return feeid;
	}
	public void setFeeid(Integer feeid) {
		this.feeid = feeid;
	}
	public Integer getPaidamount() {
		return paidamount;
	}
	public void setPaidamount(Integer paidamount) {
		this.paidamount = paidamount;
	}
	public Integer getBalanceamount() {
		return balanceamount;
	}
	public void setBalanceamount(Integer balanceamount) {
		this.balanceamount = balanceamount;
	}
	public Date getDateofpaid() {
		return dateofpaid;
	}
	public void setDateofpaid(Date dateofpaid) {
		this.dateofpaid = dateofpaid;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
