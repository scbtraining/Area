package com.stu.model.JSON;


import java.io.Serializable;

public class STUReaderTypeCount implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8911996115152994198L;
	
	private int readerTypeId;
	
	private int studentCount;
	
	private String readerTypName;
	
	private String readerName;
	
	private int readerID ;
		
	public int getReaderID() {
		return readerID;
	}

	public void setReaderID(int readerID) {
		this.readerID = readerID;
	}

	public String getReaderName() {
		return readerName;
	}

	public void setReaderName(String readerName) {
		this.readerName = readerName;
	}

	public int getReaderTypeId() {
		return readerTypeId;
	}

	public void setReaderTypeId(int readerTypeId) {
		this.readerTypeId = readerTypeId;
	}

	public int getStudentCount() {
		return studentCount;
	}

	public void setStudentCount(int studentCount) {
		this.studentCount = studentCount;
	}

	public String getReaderTypName() {
		return readerTypName;
	}

	public void setReaderTypName(String readerTypName) {
		this.readerTypName = readerTypName;
	}
	
	
}
