package com.stu.model.JSON;
import java.io.Serializable;

public class SchoolInfo implements Serializable {

	private static final long serialVersionUID = -7639326673869275255L;
	
	private int schoolId;
	private String schoolName;
	private String schoolAddress1;
	private String schoolAddress2;
	/*private String primarySchoolContact;
	private String secondarySchoolContact;*/
	private String schoolMailId;
	private int campusId;
	//private String city;
	private String state;
	//private int pinCode;
	private String studentContact;
	
	

	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public int getSchoolId() {
		return schoolId;
	}
	public void setSchoolId(int schoolId) {
		this.schoolId = schoolId;
	}
	public String getSchoolName() {
		return schoolName;
	}
	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}
	public String getSchoolAddress1() {
		return schoolAddress1;
	}
	public void setSchoolAddress1(String schoolAddress1) {
		this.schoolAddress1 = schoolAddress1;
	}
	public String getSchoolAddress2() {
		return schoolAddress2;
	}
	public void setSchoolAddress2(String schoolAddress2) {
		this.schoolAddress2 = schoolAddress2;
	}
	
	public String getSchoolMailId() {
		return schoolMailId;
	}
	public void setSchoolMailId(String schoolMailId) {
		this.schoolMailId = schoolMailId;
	}
	public int getCampusId() {
		return campusId;
	}
	public void setCampusId(int campusId) {
		this.campusId = campusId;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getStudentContact() {
		return studentContact;
	}
	public void setStudentContact(String studentContact) {
		this.studentContact = studentContact;
	}
	
	
}
