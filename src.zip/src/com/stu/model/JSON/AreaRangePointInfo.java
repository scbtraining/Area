package com.stu.model.JSON;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AreaRangePointInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8937802811846074195L;
	
	private List<Map<String,String>> listPoints=new ArrayList<Map<String,String>>();
	private String buildingName;
	private int buildingId;
	
	public List<Map<String, String>> getListPoints() {
		return listPoints;
	}
	public void setListPoints(List<Map<String, String>> listPoints) {
		this.listPoints = listPoints;
	}
	public String getBuildingName() {
		return buildingName;
	}
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}
	public int getBuildingId() {
		return buildingId;
	}
	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}
	
	

}
