package com.stu.model.JSON;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

public class ROLEInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7639326673869275255L;
	
	private Integer roleid;
	private String rolename;
	private String status;
	private String userId;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Integer getRoleid() {
		return roleid;
	}
	public void setRoleid(Integer roleid) {
		this.roleid = roleid;
	}
	public String getRolename() {
		return rolename;
	}
	public void setRolename(String rolename) {
		this.rolename = rolename;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
