package com.stu.model.JSON;

import java.io.Serializable;
import java.util.Date;

public class ATTInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7639326673869275255L;
	
	private Integer attid;
	private Integer courseid;
	private Integer studentid;
	private String studentattendance;
	private String comments;
	private Date dateofattendance;	
	private String className;
	//private String section;
	//private Integer classId;
	
	private StudentClass studentClass;	
	
	public StudentClass getStudentClass() {
		return studentClass;
	}
	public void setStudentClass(StudentClass studentClass) {
		this.studentClass = studentClass;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
			
	public Integer getAttid() {
		return attid;
	}
	public void setAttid(Integer attid) {
		this.attid = attid;
	}
	public Integer getCourseid() {
		return courseid;
	}
	public void setCourseid(Integer courseid) {
		this.courseid = courseid;
	}
	public Integer getStudentid() {
		return studentid;
	}
	public void setStudentid(Integer studentid) {
		this.studentid = studentid;
	}
	public String getStudentattendance() {
		return studentattendance;
	}
	public void setStudentattendance(String studentattendance) {
		this.studentattendance = studentattendance;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Date getDateofattendance() {
		return dateofattendance;
	}
	public void setDateofattendance(Date dateofattendance) {
		this.dateofattendance = dateofattendance;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
