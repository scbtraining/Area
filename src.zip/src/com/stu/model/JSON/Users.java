package com.stu.model.JSON;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity

@Table(name = "USERS")
public class Users implements Serializable{
	
	private static final long serialVersionUID = 8704535406621494434L;
	
	@Id
	@Column(name = "USERS_USER_ID")
	private String users_userid;
	
	@Column(name = "USERS_EMAIL_ID")
    private String users_emailid;
	
	@Column(name = "USERS_PASSWORD")
    private String users_password;
	
	@Column(name = "USERS_USER_NAME")
    private String users_user_name;
	
	@Column(name = "USERS_PHONE_NO")
    private String users_phone_no;
	
	@Column(name = "USERS_ADDRESS")
    private String users_address;

	public String getUsers_userid() {
		return users_userid;
	}

	public void setUsers_userid(String users_userid) {
		this.users_userid = users_userid;
	}

	public String getUsers_emailid() {
		return users_emailid;
	}

	public void setUsers_emailid(String users_emailid) {
		this.users_emailid = users_emailid;
	}

	public String getUsers_password() {
		return users_password;
	}

	public void setUsers_password(String users_password) {
		this.users_password = users_password;
	}

	public String getUsers_user_name() {
		return users_user_name;
	}

	public void setUsers_user_name(String users_user_name) {
		this.users_user_name = users_user_name;
	}

	public String getUsers_phone_no() {
		return users_phone_no;
	}

	public void setUsers_phone_no(String users_phone_no) {
		this.users_phone_no = users_phone_no;
	}

	public String getUsers_address() {
		return users_address;
	}

	public void setUsers_address(String users_address) {
		this.users_address = users_address;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	

}