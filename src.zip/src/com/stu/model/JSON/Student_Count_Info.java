package com.stu.model.JSON;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Student_Count_Info implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1576223361474301971L;
	
	private List<Map<String,String>> listPoints=new ArrayList<Map<String,String>>();
	private String reader_type_name;
	private String reader_type_id;
	
	
	
	
	public String getReader_type_id() {
		return reader_type_id;
	}
	public void setReader_type_id(String reader_type_id) {
		this.reader_type_id = reader_type_id;
	}
	public List<Map<String, String>> getListPoints() {
		return listPoints;
	}
	public void setListPoints(List<Map<String, String>> listPoints) {
		this.listPoints = listPoints;
	}
	public String getReader_type_name() {
		return reader_type_name;
	}
	public void setReader_type_name(String reader_type_name) {
		this.reader_type_name = reader_type_name;
	}
	
	

	
}
