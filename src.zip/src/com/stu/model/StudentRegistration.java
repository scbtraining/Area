package com.stu.model;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "studentdetails")

public class StudentRegistration {
	
	@Id
	@GeneratedValue
	@Column(name = "student_id")
    private Integer student_id;
	
	@Column(name = "address_id")
    private String address_id;
	
	@Column(name = "present_address1")
   private String present_address1;
	
	@Column(name = "present_address2")
    private String present_address2;
	
	
	@Column(name = "present_address3")
    private String present_address3;
	
	@Column(name = "permenent_address1")
   private String permenent_address1;

	@Column(name = "permenent_address2")
   private String permenent_address2;
   
	@Column(name = "permenent_address3")
   private String permenent_address3;
   
	@Column(name = "parent_name")
    private String parent_name;
	
	@Column(name = "parent_contact")
    private Integer parent_contact;

	
	


	public String getAddress_id() {
		return address_id;
	}

	public void setAddress_id(String address_id) {
		this.address_id = address_id;
	}

	public String getPresent_address1() {
		return present_address1;
	}

	public void setPresent_address1(String present_address1) {
		this.present_address1 = present_address1;
	}

	public String getPresent_address2() {
		return present_address2;
	}

	public void setPresent_address2(String present_address2) {
		this.present_address2 = present_address2;
	}

	public Integer getStudent_id() {
		return student_id;
	}

	public void setStudent_id(Integer student_id) {
		this.student_id = student_id;
	}

	public String getPresent_address3() {
		return present_address3;
	}

	public void setPresent_address3(String present_address3) {
		this.present_address3 = present_address3;
	}

	public String getPermenent_address1() {
		return permenent_address1;
	}

	public void setPermenent_address1(String permenent_address1) {
		this.permenent_address1 = permenent_address1;
	}

	public String getPermenent_address2() {
		return permenent_address2;
	}

	public void setPermenent_address2(String permenent_address2) {
		this.permenent_address2 = permenent_address2;
	}

	public String getPermenent_address3() {
		return permenent_address3;
	}

	public void setPermenent_address3(String permenent_address3) {
		this.permenent_address3 = permenent_address3;
	}

	public String getParent_name() {
		return parent_name;
	}

	public void setParent_name(String parent_name) {
		this.parent_name = parent_name;
	}

	public Integer getParent_contact() {
		return parent_contact;
	}

	public void setParent_contact(Integer parent_contact) {
		this.parent_contact = parent_contact;
	}

	




}
