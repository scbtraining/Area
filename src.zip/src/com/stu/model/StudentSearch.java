package com.stu.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class StudentSearch implements Serializable {
	private static final long serialVersionUID = 8704535406621494434L;
	
	@Id
	@Column(name = "student_id")
	private Integer sid;
	
	@Column(name = "student_name")
	private String sname;
	
	@Column(name = "reader_name")
	private String rname;

	public Integer getSid() {
		return sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getRname() {
		return rname;
	}

	public void setRname(String rname) {
		this.rname = rname;
	}
}
