package com.stu.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pdb_role")
public class UserReg {
	
	@Id
	@GeneratedValue
	@Column(name = "pdb_role_id")
	private int pdb_role_id; 
	@Column(name = "pdb_role_name")
	private String pdb_role_name;
	public int getPdb_role_id() {
		return pdb_role_id;
	}
	public void setPdb_role_id(int pdb_role_id) {
		this.pdb_role_id = pdb_role_id;
	}
	public String getPdb_role_name() {
		return pdb_role_name;
	}
	public void setPdb_role_name(String pdb_role_name) {
		this.pdb_role_name = pdb_role_name;
	}
		
	

}
