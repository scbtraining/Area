package com.stu.model;

import java.util.Date;

import org.hibernate.annotations.Type;


public class Student {
	
	private int clientID; 
	private int readerID;
	private int cardId;
	private int batVolt;
	private int stepTrav;	
	private int calories;  
	private int signalsrgth;
	private int sDay;
	private int sMon;
	private int sYr;
	private int sHR;
	private int smins;
	private int sSecs;	
	private float sLng;
	private float sLat;
	private float sAlt;
	private String sOthers;
	private String rollNo;
	private int studentInfoID;
	private String studentName;
	private String studentClass;
	private String studentSection;
	private String admissionNo;
	@Type(type="date")
	private Date doa;
	@Type(type="date")
	private Date dob;

	
	
	public int getStudentInfoID() {
		return studentInfoID;
	}
	public void setStudentInfoID(int studentInfoID) {
		this.studentInfoID = studentInfoID;
	}
	public String getRollNo() {
		return rollNo;
	}
	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}
	
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentClass() {
		return studentClass;
	}
	public void setStudentClass(String studentClass) {
		this.studentClass = studentClass;
	}
	public String getStudentSection() {
		return studentSection;
	}
	public void setStudentSection(String studentSection) {
		this.studentSection = studentSection;
	}
	public String getAdmissionNo() {
		return admissionNo;
	}
	public void setAdmissionNo(String admissionNo) {
		this.admissionNo = admissionNo;
	}
	public Date getDoa() {
		return doa;
	}
	public void setDoa(Date doa) {
		this.doa = doa;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public int getStepTrav() {
		return stepTrav;
	}
	public void setStepTrav(int stepTrav) {
		this.stepTrav = stepTrav;
	}
	public int getClientID() {
		return clientID;
	}
	public void setClientID(int clientID) {
		this.clientID = clientID;
	}
	
	public int getCardId() {
		return cardId;
	}
	public void setCardId(int cardId) {
		this.cardId = cardId;
	}
	public int getBatVolt() {
		return batVolt;
	}
	public void setBatVolt(int batVolt) {
		this.batVolt = batVolt;
	}
	public int getCalories() {
		return calories;
	}
	public void setCalories(int calories) {
		this.calories = calories;
	}
	
	public int getsDay() {
		return sDay;
	}
	public void setsDay(int sDay) {
		this.sDay = sDay;
	}
	public int getsMon() {
		return sMon;
	}
	public void setsMon(int sMon) {
		this.sMon = sMon;
	}
	
	public int getReaderID() {
		return readerID;
	}
	public void setReaderID(int readerID) {
		this.readerID = readerID;
	}
	public int getSignalsrgth() {
		return signalsrgth;
	}
	public void setSignalsrgth(int signalsrgth) {
		this.signalsrgth = signalsrgth;
	}
	public int getsYr() {
		return sYr;
	}
	public void setsYr(int sYr) {
		this.sYr = sYr;
	}
	public int getsHR() {
		return sHR;
	}
	public void setsHR(int sHR) {
		this.sHR = sHR;
	}
	public int getSmins() {
		return smins;
	}
	public void setSmins(int smins) {
		this.smins = smins;
	}
	public int getsSecs() {
		return sSecs;
	}
	public void setsSecs(int sSecs) {
		this.sSecs = sSecs;
	}
	public float getsLng() {
		return sLng;
	}
	public void setsLng(float sLng) {
		this.sLng = sLng;
	}
	public float getsLat() {
		return sLat;
	}
	public void setsLat(float sLat) {
		this.sLat = sLat;
	}
	public float getsAlt() {
		return sAlt;
	}
	public void setsAlt(float sAlt) {
		this.sAlt = sAlt;
	}
	public String getsOthers() {
		return sOthers;
	}
	public void setsOthers(String sOthers) {
		this.sOthers = sOthers;
	}
	
	
	
	
	
	

}
