package com.stu.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "student_area_range")
public class AreaRange {

	@Id
	@GeneratedValue
	@Column(name = "buildingid")
	private int buildingId;
	@Column(name = "buildingname")
	private String buildingName;
	@OneToMany(cascade={CascadeType.ALL},fetch=FetchType.LAZY)
	@JoinColumn(name="buildingid")
	private List<AreaRangePoint> bulindingList;

	public List<AreaRangePoint> getBulindingList() {
		return bulindingList;
	}

	public void setBulindingList(List<AreaRangePoint> bulindingList) {
		this.bulindingList = bulindingList;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	

}