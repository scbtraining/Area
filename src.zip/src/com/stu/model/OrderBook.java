package com.stu.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "sow_work_order")
public class OrderBook implements Serializable {

	private static final long serialVersionUID = 8704535406621494434L;

	@Id
	@Column(name = "sow_no")
	private String sowNo;

	@Column(name = "prj_desc")
	private Integer pId;

	@Column(name = "contract_type")
	private String contractNo;
	
	@Column(name = "sow_value_usd")
	private Integer sowValueUSD;
	    
	@Column(name = "prjectn_q1_1") 
	private Integer prjectnQ11;
	
	@Column(name = "prjectn_q1_2") 
	private Integer prjectnQ12;
	
	@Column(name = "prjectn_q1_3")  
	private Integer prjectnQ13;

	@Column(name = "prjectn_q1_sum") 
	private Integer prjectnQ1Sum;

	@Column(name = "actual_q1_1")
	private Integer actualQ11;

	@Column(name = "actual_q1_2") 
	private Integer actualQ12;

    @Column(name = "actual_q1_3") 
	private Integer actualQ13;

	@Column(name = "actual_q1_sum")  
	private Integer actualQ1Sum;

	@Column(name = "prjectn_q2_1") 
	private Integer prjectnQ21;
	
	@Column(name = "prjectn_q2_2")   
	private Integer prjectnQ22;
	
	@Column(name = "prjectn_q2_3")  
	private Integer prjectnQ23;
	
	@Column(name = "prjectn_q2_sum")
	private Integer prjectnQ2Sum;

	@Column(name = "actual_q2_1")
	private Integer actualQ21;

	@Column(name = "actual_q2_2")
	private Integer actualQ22;

	@Column(name = "actual_q2_3")
	private Integer actualQ23;

	@Column(name = "actual_q2_sum")
	private Integer actualQ2Sum;

	@Column(name = "prjectn_q3_1")
	private Integer prjectnQ31;

	@Column(name = "prjectn_q3_2")
	private Integer prjectnQ32;
	
	@Column(name = "prjectn_q3_3")
	private Integer prjectnQ33;
	
	@Column(name = "prjectn_q3_sum")  
	private Integer prjectnQ3Sum;

	@Column(name = "actual_q3_1")	
	private Integer actualQ31;

	@Column(name = "actual_q3_2")
	private Integer actualQ32;
	
	@Column(name = "actual_q3_3") 
	private Integer actualQ33;

	@Column(name = "actual_q3_sum") 
	private Integer actualQ3Sum;

	@Column(name = "prjectn_q4_1")
	private Integer prjectnQ41;

	@Column(name = "prjectn_q4_2")
	private Integer prjectnQ42;

	@Column(name = "prjectn_q4_3")   
	private Integer prjectnQ43;

	@Column(name = "prjectn_q4_sum") 
	private Integer prjectnQ4Sum;

	@Column(name = "actual_q4_1") 
	private Integer actualQ41;

	@Column(name = "actual_q4_2") 
	private Integer actualQ42;

	@Column(name = "actual_q4_3") 
	private Integer actualQ43;

	@Column(name = "actual_q4_sum")  
	private Integer actualQ4Sum;

	@Column(name = "remarks") 
	private String remarks;
	
	@Column(name = "created_date")
	@Type(type="date")
	private Date createdDate;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "updated_date")
	@Type(type="date")
	private Date updatedDate;

	@Column(name = "updated_by")
	private String updatedBy;    




}
