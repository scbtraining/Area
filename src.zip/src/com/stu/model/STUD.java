package com.stu.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity

@Table(name = "studentdetails")
public class STUD implements Serializable {

	private static final long serialVersionUID = 8704535406621494434L;

	@Id
	@Column(name = "student_id")
	private Integer sid;

	@Column(name = "student_name")
	private String sname;

	@Column(name = "student_contact")
	private String scontact;

	@Column(name = "student_blood_grup")
	private String sbloodgroup;

	@Column(name = "student_join_date")
	@Type(type="date")
	private Date sjoindate;

	@Column(name = "student_gender")
	private String sgender;

	@Column(name = "student_religion")
	private String sreligion;
	
	@Column(name = "school_id")
	private Integer sschoolid;
	
	@Column(name = "class_id")
	private Integer sclassid;

	public Integer getSid() {
		return sid;
	}

	public void setSid(Integer sid) {
		this.sid = sid;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getScontact() {
		return scontact;
	}

	public void setScontact(String scontact) {
		this.scontact = scontact;
	}

	public String getSbloodgroup() {
		return sbloodgroup;
	}

	public void setSbloodgroup(String sbloodgroup) {
		this.sbloodgroup = sbloodgroup;
	}

	public Date getSjoindate() {
		return sjoindate;
	}

	public void setSjoindate(Date sjoindate) {
		this.sjoindate = sjoindate;
	}

	public String getSgender() {
		return sgender;
	}

	public void setSgender(String sgender) {
		this.sgender = sgender;
	}

	public String getSreligion() {
		return sreligion;
	}

	public void setSreligion(String sreligion) {
		this.sreligion = sreligion;
	}

	public Integer getSschoolid() {
		return sschoolid;
	}

	public void setSschoolid(Integer sschoolid) {
		this.sschoolid = sschoolid;
	}

	public Integer getSclassid() {
		return sclassid;
	}

	public void setSclassid(Integer sclassid) {
		this.sclassid = sclassid;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
