package com.stu.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "student_class")
public class STUDENTCLASS implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4384140636291591186L;
	@Id
	@Column(name = "class_id")
	private Integer classID;

	@Column(name = "class_name")
	private String className;

	@Column(name = "section")
	private String section;

	public Integer getClassID() {
		return classID;
	}

	public void setClassID(Integer classID) {
		this.classID = classID;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}
}
