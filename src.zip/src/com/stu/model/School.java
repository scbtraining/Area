package com.stu.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "school_details")
public class School implements Serializable {
	
	private static final long serialVersionUID = -7639326673869275255L;
	
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	@Column(name = "school_id")
	private Integer schoolId;

	@Column(name = "school_name")
	private String schoolName;
	
	@Column(name = "school_addr1")
	private String schoolAddress1;
	
	@Column(name = "school_addr2")
	private String schoolAddress2;
	
	/*@Column(name = "PRIMARY_SCHOOL_CONTACT")
	private String primarySchoolContact;
	
	@Column(name = "SECONDARY_SCHOOL_CONTACT")
	private String secondarySchoolContact;
	*/
	
	@Column(name = "student_contact")
	private String studentContact;
	
	@Column(name = "school_mail_id")
	private String schoolMailId;
	
	@Column(name = "campusid")
	private Integer campusId;
	
	
	
	/*@Column(name = "STATE")
	private String state;*/
	
	

	

	/*public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}*/

	

	public Integer getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Integer schoolId) {
		this.schoolId = schoolId;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolAddress1() {
		return schoolAddress1;
	}

	public void setSchoolAddress1(String schoolAddress1) {
		this.schoolAddress1 = schoolAddress1;
	}

	public String getSchoolAddress2() {
		return schoolAddress2;
	}

	public void setSchoolAddress2(String schoolAddress2) {
		this.schoolAddress2 = schoolAddress2;
	}


	public String getSchoolMailId() {
		return schoolMailId;
	}

	public void setSchoolMailId(String schoolMailId) {
		this.schoolMailId = schoolMailId;
	}

	public Integer getCampusId() {
		return campusId;
	}

	public void setCampusId(Integer campusId) {
		this.campusId = campusId;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getStudentContact() {
		return studentContact;
	}

	public void setStudentContact(String studentContact) {
		this.studentContact = studentContact;
	}

	


}
