package com.stu.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stu.exception.FEEException;
import com.stu.model.JSON.FEEInfo;
import com.stu.service.FEEService;


@RestController
public class FEERestController {

	
	@Autowired     
	private FEEService feeServiceImpl;
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addFEE", method = RequestMethod.POST, headers = "Accept=application/json")	
	public ResponseEntity<String> addFEE(@RequestBody FEEInfo FEEinfo)
			throws FEEException {
		System.out
				.println("Add FEERestController - Add FEE method starts");
		String flag = "failed";
		if (null != FEEinfo) {
			flag = feeServiceImpl.addFEE(FEEinfo);
		}
		System.out
				.println("Add FEERestController - Add FEE method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchFEE", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<FEEInfo>> fetchFEE(@RequestParam(value = "data") int data)
			throws FEEException {
		System.out
				.println("Fetch Single StudentRestController - fetchFEE method starts");
		List<FEEInfo> feeList = new ArrayList<FEEInfo>();
		feeList = feeServiceImpl.showFEE(data);
		System.out
				.println("Fetch Single StudentRestController - fetchFEE method ends");
		return new ResponseEntity<List<FEEInfo>>(feeList, HttpStatus.OK);
	}
	
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllFEE", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<FEEInfo>> fetchAllFEE()
			throws FEEException {
		System.out
				.println("Fetch StudentRestController - fetchAllFEE method starts");
		List<FEEInfo> allfeeList = new ArrayList<FEEInfo>();
		allfeeList = feeServiceImpl.showAllFEE();
		System.out
				.println("Fetch StudentRestController - fetchAllFEE method ends");
		return new ResponseEntity<List<FEEInfo>>(allfeeList, HttpStatus.OK);
	}
	/*
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchSOW", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<SOWInfo>> fetchSOW(@RequestParam(value = "data") String data)
			throws SOWException {
		System.out
				.println("Fetch Single SOWController - fetchSOW method starts");
		List<SOWInfo> sowList = new ArrayList<SOWInfo>();
		sowList = sowServiceImpl.showSOW(data);
		System.out
				.println("Fetch Single SOWController - fetchSOW method ends");
		return new ResponseEntity<List<SOWInfo>>(sowList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/currCal", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<BigDecimal> currCal(@RequestParam(value = "curtype") String curtype, @RequestParam(value = "curvalue") BigDecimal curvalue)
			throws SOWException {
		System.out
				.println("Currency Calculation SOWController - currCal method starts");
		BigDecimal totalvalue = null;
		totalvalue = sowServiceImpl.currRateCal(curtype,curvalue);
		System.out
				.println("Currency Calculation SOWController - currCal method ends");
		return new ResponseEntity<BigDecimal>(totalvalue, HttpStatus.OK);
	}*/
	
}
