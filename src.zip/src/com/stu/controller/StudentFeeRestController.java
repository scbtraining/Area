package com.stu.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stu.exception.STUDENTException;
import com.stu.exception.STUDENTFEEException;
import com.stu.model.JSON.STUDFEEInfo;
import com.stu.model.JSON.STUDInfo;
import com.stu.service.STUFEEService;
import com.stu.service.STUService;


@RestController
public class StudentFeeRestController {

	
	@Autowired     
	private STUFEEService stufeeServiceImpl;
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addSTUDFEE", method = RequestMethod.POST, headers = "Accept=application/json")	
	public ResponseEntity<String> addSTUDFEE(@RequestBody STUDFEEInfo STUDFEEinfo)
			throws STUDENTFEEException {
		System.out
				.println("Add StudentFeeRestController - Add STUDENT FEE method starts");
		String flag = "failed";
		if (null != STUDFEEinfo) {
			flag = stufeeServiceImpl.addSTUDFEE(STUDFEEinfo);
		}
		System.out
				.println("Add StudentFeeRestController - Add STUDENT FEE method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllSTUDFEE", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<STUDFEEInfo>> fetchAllSTUDFEE()
			throws STUDENTFEEException {
		System.out
				.println("Fetch SOWController - fetchAllSOW method starts");
		List<STUDFEEInfo> allstudfeeList = new ArrayList<STUDFEEInfo>();
		allstudfeeList = stufeeServiceImpl.showAllSTUDFEE();
		System.out
				.println("Fetch SOWController - fetchAllSOW method ends");
		return new ResponseEntity<List<STUDFEEInfo>>(allstudfeeList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchSTUDFEE", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<STUDFEEInfo>> fetchSTUDFEE(@RequestParam(value = "data") int data)
			throws STUDENTFEEException {
		System.out
				.println("Fetch Single StudentFeeRestController - fetchSTUDFEE method starts");
		List<STUDFEEInfo> studfeeList = new ArrayList<STUDFEEInfo>();
		studfeeList = stufeeServiceImpl.showSTUFEE(data);
		System.out
				.println("Fetch Single StudentFeeRestController - fetchSTUDFEE method ends");
		return new ResponseEntity<List<STUDFEEInfo>>(studfeeList, HttpStatus.OK);
	}
	
}
