package com.stu.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stu.exception.SCHOOLException;
import com.stu.model.JSON.SchoolInfo;
import com.stu.service.SchoolService;


@RestController
public class SchoolRestController {
	
	@Autowired     
	private SchoolService schoolServiceImpl;
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addSchool", method = RequestMethod.POST, headers = "Accept=application/json")	
	public ResponseEntity<String> addSTUDFEE(@RequestBody SchoolInfo schoolInfo)
			throws SCHOOLException {
		System.out
				.println("Add StudentFeeRestController - Add STUDENT FEE method starts");
		String flag = "failed";
		if (null != schoolInfo) {
			flag = schoolServiceImpl.addSchool(schoolInfo);
		}
		System.out
				.println("Add StudentFeeRestController - Add STUDENT FEE method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllSchool", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<SchoolInfo>> fetchAllSTUD()
			throws SCHOOLException {
		System.out
				.println("Fetch SOWController - fetchAllStudent method starts");
		List<SchoolInfo> allschoolList = new ArrayList<SchoolInfo>();
		allschoolList = schoolServiceImpl.showAllSchool();
		System.out
				.println("Fetch SOWController - fetchAllStudent method ends");
		return new ResponseEntity<List<SchoolInfo>>(allschoolList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchSchool", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<SchoolInfo>> fetchSchool(@RequestParam(value = "data") int data)
			throws SCHOOLException {
		System.out
				.println("Fetch Single StudentFeeRestController - fetchSchool method starts");
		List<SchoolInfo> SchoolInfo = new ArrayList<SchoolInfo>();
		SchoolInfo = schoolServiceImpl.showSchool(data);
		System.out
				.println("Fetch Single StudentFeeRestController - fetchSchool method ends");
		return new ResponseEntity<List<SchoolInfo>>(SchoolInfo, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/deleteSchool", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<String> deleteSchool(@RequestParam(value = "data") int data)
			throws SCHOOLException {
		System.out
				.println("Fetch Single StudentFeeRestController - deleteSchool method starts");
		schoolServiceImpl.deleteSchool(data);
		System.out
				.println("Fetch Single StudentFeeRestController - deleteSchool method ends");
		return new ResponseEntity<String>("deleted", HttpStatus.OK);
	}

}
