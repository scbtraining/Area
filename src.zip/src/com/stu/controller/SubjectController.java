package com.stu.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stu.exception.SubjectException;
import com.stu.model.JSON.SubjectInfo;
import com.stu.service.SubjectService;


@RestController
public class SubjectController {

	
	@Autowired     
	private SubjectService subjectServiceImpl;
	
	final static Logger logger = LoggerFactory.getLogger(SubjectController.class);
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addSubject", method = RequestMethod.POST, headers = "Accept=application/json")	
	public ResponseEntity<String> addSubject(@RequestBody SubjectInfo subjectInfo)
			throws SubjectException {
		logger.info("SubjectController :: addSubject method starts");
		String flag = "failed";
		if (null != subjectInfo) {
			flag = subjectServiceImpl.addSubject(subjectInfo);
		}
		logger.info("SubjectController :: addSubject method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllSubjects", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<SubjectInfo>> fetchAllSubjects()
			throws SubjectException {
		logger.info("SubjectController :: fetchAllSubjects method starts");
		List<SubjectInfo> allSubjectList = new ArrayList<SubjectInfo>();
		allSubjectList = subjectServiceImpl.showAllSubject();
		logger.info("SubjectController :: fetchAllSubjects method ends");
		return new ResponseEntity<List<SubjectInfo>>(allSubjectList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchSubjectById", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<SubjectInfo>> fetchSubjectById(@RequestParam(value = "data") int data)
			throws SubjectException {
		logger.info("SubjectController :: fetchSubjectById method starts");
		List<SubjectInfo> subjectList = new ArrayList<SubjectInfo>();
		subjectList = subjectServiceImpl.showSubject(data);
		logger.info("SubjectController :: fetchSubjectById method ends");
		return new ResponseEntity<List<SubjectInfo>>(subjectList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/deleteSubjectById", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<String> deleteSubjectById(@RequestParam(value = "data") int data)
			throws SubjectException {
		logger.info("SubjectController :: Delete Subject method starts");
		String flag = "failed";
		flag = subjectServiceImpl.deleteSubject(data);
		logger.info("SubjectController :: Delete Subject method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	
}
