package com.stu.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stu.exception.ATTException;
import com.stu.exception.STUDENTException;
import com.stu.exception.STUDENTFEEException;
import com.stu.model.LateComingList;
import com.stu.model.JSON.ATTInfo;
import com.stu.model.JSON.STUDFEEInfo;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.STUReaderTypeCount;
import com.stu.model.JSON.StudentInfoTrack;
import com.stu.model.JSON.TrackStudentInfo;
import com.stu.service.ATTService;
import com.stu.service.STUService;

@RestController
public class AttendanceRestController {

	@Autowired     
	private ATTService attServiceImpl;
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addATTD", method = RequestMethod.POST, headers = "Accept=application/json")	
	public ResponseEntity<String> addATTD(@RequestBody ATTInfo ATTinfo)
			throws ATTException {
		System.out
				.println("Add AttendanceRestController - Add STUDENT method starts");
		String flag = "failed";
		if (null != ATTinfo) {
			flag = attServiceImpl.addATT(ATTinfo);
		}
		System.out
				.println("Add AttendanceRestController - Add STUDENT method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllATT", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<ATTInfo>> fetchAllATT()
			throws ATTException {
		System.out
				.println("Fetch AttendanceRestController - fetchAllATT method starts");
		List<ATTInfo> allattList = new ArrayList<ATTInfo>();
		allattList = attServiceImpl.showAllATT();
		System.out
				.println("Fetch AttendanceRestController - fetchAllATT method ends");
		return new ResponseEntity<List<ATTInfo>>(allattList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchATT", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<ATTInfo>> fetchATT(@RequestParam(value = "data") int data)
			throws ATTException {
		System.out
				.println("Fetch Single AttendanceRestController - fetchSTUD method starts");
		List<ATTInfo> attList = new ArrayList<ATTInfo>();
		attList = attServiceImpl.showATT(data);
		System.out
				.println("Fetch Single AttendanceRestController - fetchSTUD method ends");
		return new ResponseEntity<List<ATTInfo>>(attList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchPRTStuCount", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<ATTInfo>> fetchPRTStuCount()
			throws ATTException {
		System.out
				.println("Fetch Single AttendanceRestController - fetchPRTStuCount method starts");
		List<ATTInfo> attList = new ArrayList<ATTInfo>();
		attList = attServiceImpl.fetchPreCount();
		System.out
				.println("Fetch Single AttendanceRestController - fetchPRTStuCount method ends");
		return new ResponseEntity<List<ATTInfo>>(attList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAbsStuCount", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<ATTInfo>> fetchAbsStuCount()
			throws ATTException {
		System.out
				.println("Fetch Single AttendanceRestController - fetchAbsStuCount method starts");
		List<ATTInfo> attList = new ArrayList<ATTInfo>();
		attList = attServiceImpl.fetchAbsCount();
		System.out
				.println("Fetch Single AttendanceRestController - fetchAbsStuCount method ends");
		return new ResponseEntity<List<ATTInfo>>(attList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchStuAreaDetails", params = {"readerTypeID"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<STUReaderTypeCount>> fetchAreaStudentDetails(@RequestParam(value = "readerTypeID") int readerID)
			throws ATTException {
		System.out
				.println("Fetch Single AttendanceRestController - fetchAreaStudentDetails method starts");
		List<STUReaderTypeCount> stuAreaList = new ArrayList<STUReaderTypeCount>();
		stuAreaList = attServiceImpl.fetchAreaSTUDetails(readerID);
		System.out
				.println("Fetch Single AttendanceRestController - fetchAreaStudentDetails method ends");
		return new ResponseEntity<List<STUReaderTypeCount>>(stuAreaList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAreaStudentList", params = {"readerID"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<STUDInfo>> fetchAreaStudentList(@RequestParam(value = "readerID") int readerID)
			throws ATTException {
		System.out
				.println("Fetch Single AttendanceRestController - fetchAreaStudentList method starts");
		List<STUDInfo> stuAreaList = new ArrayList<STUDInfo>();
		stuAreaList = attServiceImpl.fetchSTUAreaList(readerID);
		System.out
				.println("Fetch Single AttendanceRestController - fetchAreaStudentList method ends");
		return new ResponseEntity<List<STUDInfo>>(stuAreaList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/trackStudent", params = {"studentID", "classID"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<StudentInfoTrack> trackStudent(@RequestParam(value = "studentID") int studentID, @RequestParam(value = "classID") int classID)
			throws ATTException {
		System.out
				.println("Fetch Single AttendanceRestController - trackStudent method starts");
		StudentInfoTrack trackStudentInfo = new StudentInfoTrack();
		trackStudentInfo = attServiceImpl.trackStudentInfo(studentID,classID );
		System.out
				.println("Fetch Single AttendanceRestController - trackStudent method ends");
		return new ResponseEntity<StudentInfoTrack>(trackStudentInfo, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/monthlyLateComingDtls", params = {"month", "year"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<LateComingList>> getMonthlyLateComingDtls(@RequestParam(value = "month") int month, @RequestParam(value = "year") int year)
			throws ATTException {
		System.out
				.println("AttendanceController - getLateComingDtls method starts");
		List<LateComingList> lateComingList = new ArrayList<LateComingList>();
		lateComingList = attServiceImpl.showMonthlyLateComing(month, year);
		System.out
				.println("AttendanceController - getLateComingDtls method ends");
		return new ResponseEntity<List<LateComingList>>(lateComingList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/weeklyLateComingDtls", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<LateComingList>> getWeeklyLateComingDtls(@RequestParam(value = "count") int count)
			throws ATTException {
		System.out
				.println("AttendanceController - getLateComingDtls method starts");
		List<LateComingList> lateComingList = new ArrayList<LateComingList>();
		lateComingList = attServiceImpl.showWeeklyLateComing(count);
		System.out
				.println("AttendanceController - getLateComingDtls method ends");
		return new ResponseEntity<List<LateComingList>>(lateComingList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/yearlylateComingDtls", params = {"year"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<LateComingList>> getYearlyLateComingDtls(@RequestParam(value = "year") int year)
			throws ATTException {
		System.out
				.println("AttendanceController - getLateComingDtls method starts");
		List<LateComingList> lateComingList = new ArrayList<LateComingList>();
		lateComingList = attServiceImpl.showYearlyLateComing(year);
		System.out
				.println("AttendanceController - getLateComingDtls method ends");
		return new ResponseEntity<List<LateComingList>>(lateComingList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/dailyLateComingDtls", params = {"date"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<LateComingList>> getDailyLateComingDtls(@RequestParam(value = "date") String date)
			throws ATTException {
		System.out
				.println("AttendanceController - getLateComingDtls method starts");
		List<LateComingList> lateComingList = new ArrayList<LateComingList>();
		lateComingList = attServiceImpl.showDailyLateComing(date);
		System.out
				.println("AttendanceController - getLateComingDtls method ends");
		return new ResponseEntity<List<LateComingList>>(lateComingList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/lateComingDtls", params = {"date", "month", "year"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<LateComingList>> getMonthlyLateComingDtls(@RequestParam(value = "date") String date, @RequestParam(value = "month") int month, @RequestParam(value = "year") int year)
			throws ATTException {
		System.out
				.println("AttendanceController - getLateComingDtls method starts");
		List<LateComingList> lateComingList = new ArrayList<LateComingList>();
		lateComingList = attServiceImpl.showLateComing(date, month, year);
		System.out
				.println("AttendanceController - getLateComingDtls method ends");
		return new ResponseEntity<List<LateComingList>>(lateComingList, HttpStatus.OK);
	}
}
