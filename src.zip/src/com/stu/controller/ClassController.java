package com.stu.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stu.exception.ClassException;
import com.stu.model.JSON.StudentClass;
import com.stu.service.Impl.ClassServiceImpl;

@RestController
public class ClassController {

	@Autowired
	private ClassServiceImpl classServiceImpl;

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/saveClass", method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<String> saveClass(@RequestBody StudentClass studentClass) throws ClassException {
		System.out.println("Add ClassController - Add Class method starts");
		String flag = "failed";
		if (null != studentClass) {
			flag = classServiceImpl.addClass(studentClass);
		}
		System.out.println("Add ClassController - Add Class method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchClass", params = {
			"data" }, method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<List<StudentClass>> fetchClass(@RequestParam(value = "data") int data) throws ClassException {
		System.out.println("Fetch Single ClassController - fetchClass method starts");
		List<StudentClass> classList = new ArrayList<StudentClass>();
		classList = classServiceImpl.showClass(data);
		System.out.println("Fetch Single ClassController - fetchClass method ends");
		return new ResponseEntity<List<StudentClass>>(classList, HttpStatus.OK);
	}

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllClass", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<List<StudentClass>> fetchAllClass() throws ClassException {
		System.out.println("Fetch StudentRestController - fetchAllClass method starts");
		List<StudentClass> allClassList = new ArrayList<StudentClass>();
		allClassList = classServiceImpl.showAllClass();
		System.out.println("Fetch StudentRestController - fetchAllClass method ends");
		return new ResponseEntity<List<StudentClass>>(allClassList, HttpStatus.OK);
	}

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/deleteClass", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public ResponseEntity<String> deleteClass(@RequestBody StudentClass studentClass) throws ClassException {
		System.out.println("Delete ClassController - deleteClass method starts");
		String flag = "failed";
		if (null != studentClass) {
			flag = classServiceImpl.deleteClass(studentClass);
		}
		System.out.println("Delete ClassController - deleteClass method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}

}
