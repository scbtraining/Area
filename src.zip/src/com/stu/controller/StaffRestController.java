package com.stu.controller;


import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.stu.exception.StaffException;
import com.stu.model.JSON.StaffInfo;
import com.stu.service.StaffService;




@RestController
public class StaffRestController {

	
	
	
	@Autowired   
    private StaffService staffServiceImpl;
    
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addStaff", method = RequestMethod.POST, headers = "Accept=application/json")	
	public ResponseEntity<String> addStaff(@RequestBody StaffInfo staffInfo)
			throws StaffException {
		System.out
				.println("Add StudentRestController - Add STUDENT method starts");
		String flag = "failed";
		if (null != staffInfo) {
			flag = staffServiceImpl.addStaff(staffInfo);
		}
		System.out
				.println("Add StudentRestController - Add STUDENT method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllStaff", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<StaffInfo>> fetchAllStaff()
			throws StaffException {
		System.out
				.println("Fetch StudentRestController - fetchAllATT method starts");
		List<StaffInfo> allattList = new ArrayList<StaffInfo>();
		allattList = staffServiceImpl.showAllStaff();
		System.out
				.println("Fetch StudentRestController - fetchAllATT method ends");
		return new ResponseEntity<List<StaffInfo>>(allattList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/fetchStaffById", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<StaffInfo> > fetchStaffByID(@RequestParam(value = "data") int data)
			throws StaffException {
		System.out
				.println("Fetch StudentRestController - fetchAllATT method starts");
		List<StaffInfo>  allattList = new ArrayList<StaffInfo> ();
		allattList = staffServiceImpl.showStaff(data);
		System.out
				.println("Fetch StudentRestController - fetchAllATT method ends");
		return new ResponseEntity<List<StaffInfo> >(allattList, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/deleteStaffById", params = {"data"}, method = RequestMethod.DELETE, headers = "Accept=application/json")	
	public ResponseEntity<String> deleteStaffByID(@RequestParam(value = "data") int data)
			throws StaffException {
		System.out
				.println("Fetch StudentRestController - fetchAllATT method starts");
		String flag = "failed";
		
		flag = staffServiceImpl.deleteStaff(data);
		System.out
				.println("Fetch StudentRestController - fetchAllATT method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	
	

	
	
}
