package com.stu.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.stu.exception.ROLEException;
import com.stu.model.JSON.RoleAccessPermissionInfo;
import com.stu.service.Impl.RoleAccessServiceImpl;

@RestController
public class RoleAccessController {

	@Autowired
	private RoleAccessServiceImpl roleAccessServiceImpl;

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addRoleAccPer", method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<String> addRoleAccPer(
			@RequestBody RoleAccessPermissionInfo roleAccPerInfo)
			throws ROLEException {
		System.out
				.println("Add RoleAccessController - addRoleAccPer method starts");
		String flag = "failed";

		if (roleAccPerInfo != null) {
			flag = roleAccessServiceImpl.addRolePermission(roleAccPerInfo);
		}
		System.out
				.println("Add RoleAccessController - addRoleAccPer method end");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchRoleAccPer", params = { "data" }, method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<List<RoleAccessPermissionInfo>> fetchRoleAccPer(
			@RequestParam(value = "data") Integer data) throws ROLEException {
		System.out
				.println("Add RoleAccessController - fetchRoleAccPer method starts");
		List<RoleAccessPermissionInfo> roleAccPerList = new ArrayList<>();
		roleAccPerList = roleAccessServiceImpl.showRolePermission(data);

		System.out
				.println("Add RoleAccessController - fetchRoleAccPer method end");
		return new ResponseEntity<List<RoleAccessPermissionInfo>>(
				roleAccPerList, HttpStatus.OK);
	}

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllRoleAccPer", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<List<RoleAccessPermissionInfo>> fetchAllRoleAccPer()
			throws ROLEException {
		System.out
				.println("Add RoleAccessController - fetchAllRoleAccPer method starts");
		List<RoleAccessPermissionInfo> roleAccPerList = new ArrayList<>();
		roleAccPerList = roleAccessServiceImpl.showAllRolePermission();
		System.out
				.println("Add RoleAccessController - fetchAllRoleAccPer method end");
		return new ResponseEntity<List<RoleAccessPermissionInfo>>(
				roleAccPerList, HttpStatus.OK);
	}

}
