package com.stu.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.stu.exception.USERException;
import com.stu.model.JSON.USERInfo;
import com.stu.service.USERService;


@RestController
public class UserRestController {

	
	@Autowired     
	private USERService userServiceImpl;
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addUSER", method = RequestMethod.POST, headers = "Accept=application/json")	
	public ResponseEntity<String> addUSER(@RequestBody USERInfo USERinfo)
			throws USERException {
		System.out
				.println("Add UserRestController - Add USER method starts");
		String flag = "failed";
		if (null != USERinfo) {
			flag = userServiceImpl.addUSER(USERinfo);
		}
		System.out
				.println("Add UserRestController - Add USER method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchUSER", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<USERInfo>> fetchUSER(@RequestParam(value = "data") Integer data)
			throws USERException {
		System.out
		.println("Fetch UserRestController - fetchUSER method starts");
		List<USERInfo> aUserList = new ArrayList<USERInfo>();
		aUserList = userServiceImpl.showUSER(data);
		System.out
		.println("Fetch UserRestController - fetchUSER method ends");
		return new ResponseEntity<List<USERInfo>>(aUserList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllUSER", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<USERInfo>> fetchAllUSER()
			throws USERException {
		System.out
		.println("Fetch UserRestController - fetchAllUSER method starts");
		List<USERInfo> allUserList = new ArrayList<USERInfo>();
		allUserList = userServiceImpl.showAllUSER();
		System.out
		.println("Fetch UserRestController - fetchAllUSER method ends");
		return new ResponseEntity<List<USERInfo>>(allUserList, HttpStatus.OK);
	}
}
