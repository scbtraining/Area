package com.stu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stu.exception.LOGINException;
import com.stu.model.JSON.UsersInfo;
import com.stu.service.LOGINService;


@RestController
public class LoginRestController {

	@Autowired     
	private LOGINService loginServiceImpl;
	
	

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/Login", method = RequestMethod.POST, headers = "Accept=application/json")	
	public ResponseEntity<UsersInfo> Login(@RequestParam(value = "username") String username, @RequestParam(value = "password") String password)
			throws LOGINException {
		System.out
				.println("LoginRestController - Login method starts");
	
		UsersInfo info=null;
        if (null != username && null != password) {
			info = loginServiceImpl.check(username,password);
		}
		
		return new ResponseEntity<UsersInfo>(info, HttpStatus.OK);
	}
	

	
	
}
