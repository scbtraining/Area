package com.stu.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stu.exception.STUDENTException;
import com.stu.model.StudentSearch;
import com.stu.model.JSON.STUDInfo;
import com.stu.service.STUService;


@RestController
public class StudentRestController {

	
	@Autowired     
	private STUService stuServiceImpl;
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addSTUD", method = RequestMethod.POST, headers = "Accept=application/json")	
	public ResponseEntity<String> addSTUD(@RequestBody STUDInfo STUDinfo)
			throws STUDENTException {
		System.out
				.println("Add StudentRestController - Add STUDENT method starts");
		String flag = "failed";
		if (null != STUDinfo) {
			flag = stuServiceImpl.addSTUD(STUDinfo);
		}
		System.out
				.println("Add StudentRestController - Add STUDENT method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchSTUD", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<STUDInfo>> fetchSTUD(@RequestParam(value = "data") int data)
			throws STUDENTException {
		System.out
				.println("Fetch Single StudentRestController - fetchSTUD method starts");
		List<STUDInfo> studList = new ArrayList<STUDInfo>();
		studList = stuServiceImpl.showSTU(data);
		System.out
				.println("Fetch Single StudentRestController - fetchSTUD method ends");
		return new ResponseEntity<List<STUDInfo>>(studList, HttpStatus.OK);
	}
	
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllSTUD", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<STUDInfo>> fetchAllSTUD()
			throws STUDENTException {
		System.out
				.println("Fetch StudentRestController - fetchAllSTUD method starts");
		List<STUDInfo> allstudList = new ArrayList<STUDInfo>();
		allstudList = stuServiceImpl.showAllSTU();
		System.out
				.println("Fetch StudentRestController - fetchAllSTUD method ends");
		return new ResponseEntity<List<STUDInfo>>(allstudList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchSTUDidBySTUDname", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<STUDInfo>> fetchAllSTUDbySTUDname(@RequestParam(value = "data") String data)
			throws STUDENTException {
		System.out
				.println("Fetch StudentRestController - fetchSTUDidBySTUDname method starts");
		List<STUDInfo> allstudList = new ArrayList<STUDInfo>();
		allstudList = stuServiceImpl.showSTUDidBySTUDname(data);
		System.out
				.println("Fetch StudentRestController - fetchSTUDidBySTUDname method ends");
		return new ResponseEntity<List<STUDInfo>>(allstudList, HttpStatus.OK);
	}
	
	/*
	 * service accepts student id and returns student details
	 */
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/searchSTUD", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<StudentSearch> searchSTUD(@RequestParam(value = "data") String data)
			throws STUDENTException {
		System.out
				.println("Fetch Single StudentRestController - searchSTUD method starts");
		StudentSearch studList = new StudentSearch();
		studList = stuServiceImpl.showStudentReader(data);
		System.out
				.println("Fetch Single StudentRestController - searchSTUD method ends");
		return new ResponseEntity<StudentSearch>(studList, HttpStatus.OK);
	}
	
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchSTUDetails", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<STUDInfo>> fetchSTUDetails()
			throws STUDENTException {
		
	
		List<STUDInfo> lStd=new ArrayList<STUDInfo>();
		lStd = stuServiceImpl.fetchSTUDetails();
		System.out
				.println("Fetch Single StudentRestController - searchSTUD method ends");
		return new ResponseEntity<List<STUDInfo>>(lStd, HttpStatus.OK);
	}
	
	
	
	
	
	/*
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchSOW", params = {"data"}, method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<List<SOWInfo>> fetchSOW(@RequestParam(value = "data") String data)
			throws SOWException {
		System.out
				.println("Fetch Single SOWController - fetchSOW method starts");
		List<SOWInfo> sowList = new ArrayList<SOWInfo>();
		sowList = sowServiceImpl.showSOW(data);
		System.out
				.println("Fetch Single SOWController - fetchSOW method ends");
		return new ResponseEntity<List<SOWInfo>>(sowList, HttpStatus.OK);
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/currCal", method = RequestMethod.GET, headers = "Accept=application/json")	
	public ResponseEntity<BigDecimal> currCal(@RequestParam(value = "curtype") String curtype, @RequestParam(value = "curvalue") BigDecimal curvalue)
			throws SOWException {
		System.out
				.println("Currency Calculation SOWController - currCal method starts");
		BigDecimal totalvalue = null;
		totalvalue = sowServiceImpl.currRateCal(curtype,curvalue);
		System.out
				.println("Currency Calculation SOWController - currCal method ends");
		return new ResponseEntity<BigDecimal>(totalvalue, HttpStatus.OK);
	}*/
	
}
