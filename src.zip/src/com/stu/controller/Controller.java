package com.stu.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.stu.model.App_Config_Master;
import com.stu.model.Building;
import com.stu.model.AreaRange;
import com.stu.model.AreaRangePoint;
import com.stu.model.ReaderConfig;
import com.stu.model.ReaderType;
import com.stu.model.Student;
import com.stu.model.StudentInformation;
import com.stu.model.StudentMarks;
import com.stu.model.StudentRegistration;
import com.stu.model.UserReg;
import com.stu.model.JSON.AccessDetailsDto;
import com.stu.model.JSON.App_Config_Master_Info;
import com.stu.model.JSON.AreaRangeInfo;
import com.stu.model.JSON.AreaRangePointInfo;
import com.stu.model.JSON.ReaderConfigInfo;
import com.stu.model.JSON.ReaderTypeInfo;
import com.stu.model.JSON.Student_Count_Info;
import com.stu.service.ReaderService;
import com.stu.service.UserRegService;


@RestController
public class Controller {
	
	@Autowired
	ReaderService readerService;
	
	@Autowired
	UserRegService userregService;
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchStudentDetails" , method = RequestMethod.POST) 
	  public List<Student> fetchProductDetails(@RequestBody Student student) throws Exception{
		return readerService.fetchStudentDetails(student);		
		
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchStudentList" , method = RequestMethod.GET) 
    public List<Student> fetchStudentList() throws Exception{
		return readerService.getStudentList();
    }
	/*@RequestMapping(value = "/getStudentRange" , method = RequestMethod.POST) 
    public List<Building> getStudentRange(@RequestBody Building building) throws Exception{
		return readerService.getStudentRange(building);
    }*/
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/getStudentRange" , method = RequestMethod.POST) 
    public List<AreaRangePoint> getStudentRange(@RequestBody AreaRangePoint building) throws Exception{
		return readerService.getStudentRange(building);
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAreaRange" , method = RequestMethod.GET) 
    public List<AreaRange> fetchAreaRange() throws Exception{
		return readerService.fetchAreaRange();
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/saveAreaRangeDetails", method = RequestMethod.POST)
	public String saveAreaRangeDetails(@RequestBody AreaRangeInfo areaRangeInfo) throws Exception {
		return readerService.saveAreaRangeDetails(areaRangeInfo);

	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/deleteAreaRange", method = RequestMethod.GET)
	public String deleteAreaRange(@RequestParam("buildingId") Integer buildingId) throws Exception {
		String returnMsg="";
		try{
		readerService.deleteAreaRange(buildingId);
		returnMsg="success";
		}catch(Exception e){
			returnMsg="failure";
			System.out.println(e);
		}
		return returnMsg;
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAreaRangeDetails" , method = RequestMethod.GET) 
    public List<AreaRangePointInfo> fetchAreaRangeDetails() throws Exception{
		return readerService.fetchAreaRangeDetails();
    }
	
	@RequestMapping(value = "/saverole" , method = RequestMethod.POST) 
    public String saveUserRegDetails(@RequestBody UserReg userreg) throws Exception {
		userregService.saveUserReg(userreg);
		return "success";
		
    }
	
	@RequestMapping(value = "/saveStudent" , method = RequestMethod.POST) 
    public String saveUserRegDetails(@RequestBody StudentRegistration stu) throws Exception {
		//System.out.println("calling this service");
		userregService.saveUserReg(stu);
		return "success";
		
    }
	
	@RequestMapping(value = "/saveStudentMarks" , method = RequestMethod.POST) 
    public String saveStudentMarksDetails(@RequestBody StudentMarks studentmarks) throws Exception {
		//System.out.println("calling this service");
		userregService.saveStudentMarks(studentmarks);
		return "success";
		
    }
	
	@RequestMapping(value = "/fetchUserRegList" , method = RequestMethod.GET) 
    public List<StudentRegistration> fetchUserRegList() throws Exception {
		return userregService.getUserRegList();
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/saveReaderDetails" , method = RequestMethod.POST) 
    public String saveReaderDetails(@RequestBody ReaderConfig reader) {
		readerService.saveReaderDetails(reader);
		return null;
		
    }
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/saveReaderTypeDetails" , method = RequestMethod.POST) 
    public ResponseEntity<String> saveReaderTypeDetails(@RequestBody ReaderTypeInfo readerType) {
		String status = readerService.saveReaderTypeDetails(readerType);
		return new ResponseEntity<String>(status, HttpStatus.OK);
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/getAllReaderType", method = RequestMethod.GET)
	public List<ReaderTypeInfo> getAllReaderType() {
		return readerService.getAllReaderType();
	}
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchReaderTypeByTypeID" , method = RequestMethod.GET)  
    public ReaderTypeInfo fetchReaderTypeByTypeID(@RequestParam("id") Integer readerTypeID) throws Exception {
		System.out.println("Controller - fetchReaderTypeByTypeID method starts");
		ReaderTypeInfo readerTypeInfo = new ReaderTypeInfo();
		readerTypeInfo = readerService.fetchReaderTypeByTypeID(readerTypeID);
		System.out.println("Controller - fetchReaderTypeByTypeID method end");
		return readerTypeInfo;
			
    }

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/deleteReaderTypeDetail" , method = RequestMethod.GET) 
    public ResponseEntity<String> deleteReaderTypeDetail(@RequestParam("id") Integer readerTypeID) throws Exception {
		System.out.println("Controller - deleteReaderTypeDetail method starts");
		String status = null;
		try{
			status = readerService.deleteReaderTypeDetail(readerTypeID);
		}catch(Exception e){
			System.out.println(e);
			status = "ReaderTypeId:" + readerTypeID + " - record can not delete properly.";
		}
		System.out.println("Controller - deleteReaderTypeDetail method end"); 
		return new ResponseEntity<String>(status, HttpStatus.OK); 
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/getAllReaderDetails", method = RequestMethod.GET)
	public List<ReaderConfigInfo> getAllReaderDetails() {
//		System.out.println("2::::"+readerService.getAllReaderList().size());
		return readerService.getAllReaderList();
	}
	
	
	//prasanth d added
	
	
	
	/*@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/saveAppConfig", method = RequestMethod.POST)
	public String saveAppConfig(@RequestBody App_Config_Master_Info app_Config_Master_Info) throws Exception {
		return readerService.saveAppConfig(app_Config_Master_Info);

	}*/
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAppConfig" , method = RequestMethod.GET) 
    public List<App_Config_Master> fetchAppConfig() throws Exception{
		return readerService.fetchAppConfig();
    }
    
    @CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAppConfigDtl" , method = RequestMethod.GET) 
    public List<App_Config_Master> fetchAppConfigDtl(@RequestParam("appId") String appId) throws Exception{
		return readerService.fetchAppConfigDtl(appId);
    }
	
	
	
	
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchStudentCountDetails" , method = RequestMethod.GET) 
    public List<Student_Count_Info> fetchStudentCountDetails() throws Exception{
		return readerService.fetchStudentCountDetails();
    }
	
	
	
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchStudReport" , method = RequestMethod.GET) 
    public List<Map<String,String>> fetchStudReport() throws Exception{
		return readerService.fetchStudReport();
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchStudDtlReport" , method = RequestMethod.GET) 
    public List<Map<String,String>> fetchStudDtlReport(@RequestParam("locationId") String  locationId) throws Exception{
		return readerService.fetchStudDtlReport(locationId);
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchStudLatitudeReport" , method = RequestMethod.GET) 
    public List<Map<String,String>> fetchStudLatitudeReport(@RequestParam("studentId") String  studentId) throws Exception{
		return readerService.fetchStudLatitudeReport(studentId);
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAreaStudentDetails" , method = RequestMethod.GET) 
    public List<Map<String,String>> fetchAreaStudentDetails(@RequestParam("readerId") String  readerId,@RequestParam("readerName") String readerName ) throws Exception{
		return readerService.fetchAreaStudentDetails(readerId,readerName);
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAccessdetails" , method = RequestMethod.GET) 
    public List<AccessDetailsDto> getAccessDetails(@RequestParam("data") String data) {
		System.out.println(data);
		return readerService.fetchAccessDetails();
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/getStudentTraceDetails" , method = RequestMethod.GET) 
    public List<StudentInformation> getStudentTraceDetails() {
		return readerService.getStudentTraceDetails();
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/deleteReaderDetail" , method = RequestMethod.GET) 
    public String deleteReaderDetail(@RequestParam("readerConfID") Integer readerConfID) throws Exception {
		System.out.println("Controller - deleteReaderDetail method starts");
		try{
			readerService.deleteReaderDetail(readerConfID);
			System.out.println("Controller - deleteReaderDetail method end");
			return "Deleted sucessfully.";
		}catch(Exception e){
			System.out.println(e);
			System.out.println("Controller - deleteReaderDetail method end");
			return "Deleting was failed.";
		}
//		return null;
    }
	

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/updateReaderDetail" , method = RequestMethod.POST) 
    public String updateReaderDetail(@RequestBody ReaderConfigInfo readerConfigInfo) throws Exception {
		System.out.println("Controller - updateReaderDetail method starts");
		readerService.updateReaderDetail(readerConfigInfo);
		System.out.println("Controller - updateReaderDetail method end");
		return null;
			
    }
	
	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchReaderDetailByConfigID" , method = RequestMethod.GET) 
    public ReaderConfigInfo fetchReaderDetailByConfigID(@RequestParam("readerConfID") Integer readerConfID) throws Exception {
		System.out.println("Controller - fetchReaderDetailByConfigID method starts");
		ReaderConfigInfo readerConfigInfo = new ReaderConfigInfo();
		readerConfigInfo = readerService.fetchReaderDetailByConfigID(readerConfID);
		System.out.println("Controller - fetchReaderDetailByConfigID method end");
		return readerConfigInfo;
			
    }
	
}
