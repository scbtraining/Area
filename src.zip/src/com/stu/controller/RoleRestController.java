package com.stu.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stu.exception.FEEException;
import com.stu.exception.ROLEException;
import com.stu.exception.STUDENTException;
import com.stu.model.JSON.FEEInfo;
import com.stu.model.JSON.ROLEInfo;
import com.stu.model.JSON.STUDInfo;
import com.stu.service.ROLEService;
import com.stu.service.STUService;

@RestController
public class RoleRestController {

	@Autowired
	private ROLEService roleServiceImpl;

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/addROLE", method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<String> addROLE(@RequestBody ROLEInfo ROLEinfo)
			throws ROLEException {
		System.out.println("Add RoleRestController - Add ROLE method starts");
		String flag = "failed";
		if (null != ROLEinfo) {
			flag = roleServiceImpl.addROLE(ROLEinfo);
		}
		System.out.println("Add RoleRestController - Add ROLE method ends");
		return new ResponseEntity<String>(flag, HttpStatus.OK);
	}

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchROLE", params = { "data" }, method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<List<ROLEInfo>> fetchROLE(
			@RequestParam(value = "data") int data) throws ROLEException {
		System.out
				.println("Fetch Single RoleRestController - fetchROLE method starts");
		List<ROLEInfo> roleList = new ArrayList<ROLEInfo>();
		roleList = roleServiceImpl.showROLE(data);
		System.out
				.println("Fetch Single RoleRestController - fetchROLE method ends");
		return new ResponseEntity<List<ROLEInfo>>(roleList, HttpStatus.OK);
	}

	@CrossOrigin(origins = "*", maxAge = 3600)
	@RequestMapping(value = "/fetchAllROLE", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<List<ROLEInfo>> fetchAllROLE() throws ROLEException {
		System.out
				.println("Fetch RoleRestController - fetchAllROLE method starts");
		List<ROLEInfo> allRoleList = new ArrayList<ROLEInfo>();
		allRoleList = roleServiceImpl.showAllROLE();
		System.out
				.println("Fetch RoleRestController - fetchAllROLE method ends");
		return new ResponseEntity<List<ROLEInfo>>(allRoleList, HttpStatus.OK);
	}

}
