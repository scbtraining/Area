package com.stu.service;

import java.util.List;

import com.stu.exception.FEEException;
import com.stu.model.JSON.FEEInfo;

public interface FEEService {

	String addFEE(FEEInfo FEEinfo)throws FEEException;
	
	List<FEEInfo> showAllFEE()throws FEEException;
	
	List<FEEInfo> showFEE(int FEEid)throws FEEException;
	
	//BigDecimal currRateCal(String curtype, BigDecimal curvalue)throws SOWException;
}
