package com.stu.service;

import java.util.List;
import com.stu.exception.ROLEException;
import com.stu.model.JSON.ROLEInfo;

public interface ROLEService {

	String addROLE(ROLEInfo ROLEinfo)throws ROLEException;
	
	List<ROLEInfo> showROLE(int ROLEid)throws ROLEException;
	
	List<ROLEInfo> showAllROLE()throws ROLEException;
	
}
