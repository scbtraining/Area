package com.stu.service;

import java.util.List;

import com.stu.exception.ROLEException;
import com.stu.model.JSON.RoleAccessPermissionInfo;

public interface RoleAccessService {
	
	String addRolePermission(RoleAccessPermissionInfo roleAccessPer)throws ROLEException;
	
	List<RoleAccessPermissionInfo> showRolePermission(Integer roleAccessId)throws ROLEException;
	
	List<RoleAccessPermissionInfo> showAllRolePermission()throws ROLEException;

}
