package com.stu.service;

import java.util.List;

import com.stu.exception.SubjectException;
import com.stu.model.JSON.SubjectInfo;

public interface SubjectService {

	String addSubject(SubjectInfo subjectInfo)throws SubjectException;
	
	List<SubjectInfo> showAllSubject()throws SubjectException;
	
	List<SubjectInfo> showSubject(int SubjectId)throws SubjectException;
	
	String deleteSubject(int SubjectId)throws SubjectException;
	
	//BigDecimal currRateCal(String curtype, BigDecimal curvalue)throws SOWException;
}
