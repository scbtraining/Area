package com.stu.service;

import java.math.BigDecimal;
import java.util.List;

import com.stu.exception.STUDENTException;
import com.stu.model.StudentSearch;
import com.stu.model.JSON.STUDInfo;

public interface STUService {

	String addSTUD(STUDInfo STUDinfo)throws STUDENTException;
	
	List<STUDInfo> showAllSTU()throws STUDENTException;
	
	List<STUDInfo> showSTU(int STUDid)throws STUDENTException;
	
	List<STUDInfo> showSTUDidBySTUDname(String STUDname)throws STUDENTException;
	
	StudentSearch showStudentReader(String sid)throws STUDENTException;
	
	public List<STUDInfo> fetchSTUDetails()throws STUDENTException;
	
	//BigDecimal currRateCal(String curtype, BigDecimal curvalue)throws SOWException;
}
