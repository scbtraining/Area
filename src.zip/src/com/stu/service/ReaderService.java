package com.stu.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.stu.dao.ReaderDao;
import com.stu.model.App_Config_Master;
import com.stu.model.AreaRange;
import com.stu.model.AreaRangePoint;
import com.stu.model.ReaderConfig;
import com.stu.model.ReaderType;
import com.stu.model.Student;
import com.stu.model.StudentInformation;
import com.stu.model.JSON.AccessDetailsDto;
import com.stu.model.JSON.App_Config_Master_Info;
import com.stu.model.JSON.AreaRangeInfo;
import com.stu.model.JSON.AreaRangePointInfo;
import com.stu.model.JSON.ReaderConfigInfo;
import com.stu.model.JSON.ReaderTypeInfo;
import com.stu.model.JSON.Student_Count_Info;

@Service
public class ReaderService {
    
	@Autowired
	ReaderDao readerDao; 
	
	public List<Student> fetchStudentDetails(Student stu) throws Exception {
		return readerDao.fetchStudentDetails(stu);
		
	}
	
	
	public List<Student> getStudentList() throws Exception{
		return readerDao.getStudentDetails();
	}


	/*public List<Building> getStudentRange(Building building) throws Exception{
		// TODO Auto-generated method stub
		return readerDao.getStudentRange(building);
	}*/
	
	public List<AreaRangePoint> getStudentRange(AreaRangePoint building) throws Exception{
		// TODO Auto-generated method stub
		return readerDao.getStudentRange(building);
	}
	
	public void saveProduct(AreaRange areaRange) {
		readerDao.saveProduct(areaRange);
		
	}
	public List<AreaRange> fetchAreaRange() throws Exception {
		return readerDao.fetchAreaRange();
	}
	
	public String saveAreaRangeDetails(AreaRangeInfo areaRangeInfo) throws Exception{
		return readerDao.saveAreaRangeDetails(areaRangeInfo);
	}
	public void deleteAreaRange(Integer buildingId) throws Exception {
		readerDao.deleteAreaRange(buildingId);
		
	}
	public List<AreaRangePointInfo> fetchAreaRangeDetails() throws Exception {
		return readerDao.fetchAreaRangeDetails();
	}
	
	public void saveReaderDetails(ReaderConfig reader) {
		readerDao.saveReader(reader);
		
	}

	public String saveReaderTypeDetails(ReaderTypeInfo readerType) {
		String status = readerDao.saveReaderType(readerType);
		return status;
	}
	
	public List<ReaderTypeInfo> getAllReaderType() {
		// TODO Auto-generated method stub
		return readerDao.getAllReaderType();
	}
	

	public ReaderTypeInfo fetchReaderTypeByTypeID(Integer readerTypeID) throws Exception {
		return readerDao.fetchReaderTypeByTypeID(readerTypeID);
		
	}
	
	public String deleteReaderTypeDetail(Integer readerTypeID) throws Exception {
		String status = readerDao.deleteReaderTypeDetail(readerTypeID);
		return status;
	}
	
	public List<ReaderConfigInfo> getAllReaderList() {
		// TODO Auto-generated method stub
//		System.out.println("1::::"+readerDao.getAllReaderList().size());
		return readerDao.getAllReaderList();
	}
	
	public String saveAppConfig(App_Config_Master_Info app_Config_Master_Info) throws Exception{
		return readerDao.saveAppConfig(app_Config_Master_Info);
	}
	
	public List<App_Config_Master> fetchAppConfig() throws Exception {
		return readerDao.fetchAppConfig();
	}
	
	public List<App_Config_Master> fetchAppConfigDtl(String appId) throws Exception {
		return readerDao.fetchAppConfigDtl(appId);
	}
	
	
	
	public List<Student_Count_Info> fetchStudentCountDetails() throws Exception {
		return readerDao.fetchStudentCountDetails();
	}
	
	public List<Map<String,String>> fetchAttendaceDetails(String calenderDate) throws Exception{
		return readerDao.fetchAttendaceDetails(calenderDate);
	}
	
	public List<Map<String,String>> fetchStudReport() throws Exception{
		return readerDao.fetchStudReport();
	}
	
	public List<Map<String,String>> fetchStudDtlReport(String locationId) throws Exception{
		return readerDao.fetchStudDtlReport(locationId);
	}
	
	public List<Map<String,String>> fetchStudLatitudeReport(String studentId) throws Exception{
		return readerDao.fetchStudLatitudeReport(studentId);
	}
	
	public List<Map<String,String>> fetchAreaStudentDetails(String readerId,String readerName ) throws Exception{
		return readerDao.fetchAreaStudentDetails(readerId,readerName);
	}
	
	public List<AccessDetailsDto> fetchAccessDetails() {
		return readerDao.fetchAccessDetails();
	}
	
	public List<StudentInformation> getStudentTraceDetails() {
		return readerDao.getStudentTraceDetails();
	}
	
	public void deleteReaderDetail(Integer readerConfID) throws Exception {
		readerDao.deleteReaderDetail(readerConfID);
		
	}
	
	public void updateReaderDetail(ReaderConfigInfo readerConfigInfo) throws Exception {
		readerDao.updateReaderDetail(readerConfigInfo);
		
	}
	
	public ReaderConfigInfo fetchReaderDetailByConfigID(Integer readerConfID) throws Exception {
		return readerDao.fetchReaderDetailByConfigID(readerConfID);
		
	}
}
