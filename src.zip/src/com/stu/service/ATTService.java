package com.stu.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.stu.exception.ATTException;
import com.stu.exception.STUDENTException;
import com.stu.model.LateComingList;
import com.stu.model.JSON.ATTInfo;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.STUReaderTypeCount;
import com.stu.model.JSON.StudentInfoTrack;
import com.stu.model.JSON.TrackStudentInfo;

public interface ATTService {

	String addATT(ATTInfo ATTinfo)throws ATTException;
	
	List<ATTInfo> showAllATT()throws ATTException;
	
	List<ATTInfo> showATT(int ATTid)throws ATTException;
	
	List<ATTInfo> fetchPreCount()throws ATTException;
	
	List<ATTInfo> fetchAbsCount()throws ATTException;
	
	List<STUReaderTypeCount> fetchAreaSTUDetails(int readerID)throws ATTException;
	
	List<STUDInfo> fetchSTUAreaList(int readerID)throws ATTException;
	
	StudentInfoTrack trackStudentInfo(int studentId, int classId)throws ATTException;
	
	List<LateComingList> showLateComing(String date, int month, int year);

	List<LateComingList> showWeeklyLateComing(int count);

	List<LateComingList> showMonthlyLateComing(int month, int year);

	List<LateComingList> showYearlyLateComing(int year);

	List<LateComingList> showDailyLateComing(String date);
	
	//BigDecimal currRateCal(String curtype, BigDecimal curvalue)throws SOWException;
}
