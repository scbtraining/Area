package com.stu.service;

import java.util.List;

import com.stu.exception.ClassException;
import com.stu.model.JSON.StudentClass;

public interface ClassService {
	String addClass(StudentClass studentClass) throws ClassException;

	List<StudentClass> showAllClass() throws ClassException;

	List<StudentClass> showClass(int classID) throws ClassException;

	public String deleteClass(StudentClass studentClass) throws ClassException;
}
