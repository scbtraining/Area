package com.stu.service.Impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.stu.dao.Impl.RoleAccessPermissionDaoImpl;
import com.stu.exception.ROLEException;
import com.stu.model.RoleAccessPermission;
import com.stu.model.JSON.RoleAccessPermissionInfo;
import com.stu.service.RoleAccessService;


@Service("roleAccessServiceImpl")
public class RoleAccessServiceImpl implements RoleAccessService {

	@Autowired
	RoleAccessPermissionDaoImpl roleAccPerDAOImpl;

	@Override
	public String addRolePermission(RoleAccessPermissionInfo roleAccessPer)
			throws ROLEException {
		System.out
				.println("RoleAccessServiceImpl - addRolePermission method starts");
		return roleAccPerDAOImpl
				.addRolePermission(processRolePermission(roleAccessPer));
	}

	private RoleAccessPermission processRolePermission(
			RoleAccessPermissionInfo roleAccessPer) {
		System.out
				.println("RoleAccessServiceImpl - processRolePermission method starts");
		RoleAccessPermission addRolePermission = new RoleAccessPermission();

		if (null != addRolePermission) {
			addRolePermission.setRoleAccessId(roleAccessPer.getRoleAccessId());
			addRolePermission.setMenuId(roleAccessPer.getMenuId());
			addRolePermission.setRoleId(roleAccessPer.getRoleId());
			addRolePermission.setSubMenuId(roleAccessPer.getSubMenuId());
			addRolePermission.setCreate(roleAccessPer.getCreate());
			addRolePermission.setDelete(roleAccessPer.getDelete());
			addRolePermission.setView(roleAccessPer.getView());
			addRolePermission.setEdit(roleAccessPer.getEdit());
		}
		System.out
				.println("RoleAccessServiceImpl - processRolePermission method ends");
		return addRolePermission;
	}

	@Override
	public List<RoleAccessPermissionInfo> showRolePermission(
			Integer roleAccessId) throws ROLEException {
		System.out
				.println("RoleAccessServiceImpl - showRolePermission method starts");
		return roleAccPerDAOImpl.fetchRolePermission(roleAccessId);
	}

	@Override
	public List<RoleAccessPermissionInfo> showAllRolePermission()
			throws ROLEException {
		System.out
				.println("RoleAccessServiceImpl - showAllRolePermission method starts");
		return roleAccPerDAOImpl.fetchAllRolePermission();
	}

}
