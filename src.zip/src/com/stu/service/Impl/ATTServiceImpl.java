package com.stu.service.Impl;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.ATTDAO;
import com.stu.dao.Impl.ATTDAOImpl;
import com.stu.dao.Impl.STUDAOImpl;
import com.stu.exception.ATTException;
import com.stu.exception.STUDENTException;
import com.stu.model.ATT;
import com.stu.model.LateComingList;
import com.stu.model.STUD;
import com.stu.model.JSON.ATTInfo;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.STUReaderTypeCount;
import com.stu.model.JSON.StudentInfoTrack;
import com.stu.model.JSON.TrackStudentInfo;
import com.stu.service.ATTService;
import com.stu.service.STUService;


@Service("attServiceImpl")
public class ATTServiceImpl implements ATTService {
	
	@Autowired
	private ATTDAO attDAO;
	
	@Autowired
	private ATTDAOImpl attDAOImpl;;
	
	public String addATT(ATTInfo ATTinfo) throws ATTException {
		System.out.println("StuServiceImpl - addSTUD method starts");
		System.out.println("StuServiceImpl - addSTUD method ends");
		return attDAOImpl.saveAddATT(processATTInfo(ATTinfo));
		
	}
	
	private ATT processATTInfo(ATTInfo addATTInfo) {
		System.out.println("ATTServiceImpl - processATTInfo method starts");
		ATT addATT=new ATT();
	
		if (null != addATTInfo) {
			addATT.setAttid(addATTInfo.getAttid());
			addATT.setCourseid(addATTInfo.getCourseid());
			addATT.setStudentid(addATTInfo.getStudentid());
			addATT.setStudentattendance(addATTInfo.getStudentattendance());
			addATT.setComments(addATTInfo.getComments());
			addATT.setDateofattendance(addATTInfo.getDateofattendance());
		}
		System.out.println("ATTServiceImpl - processATTInfo method ends");
		return addATT;
	}
	
	public List<ATTInfo> showATT(int ATTid)throws ATTException {
		System.out.println("ATTServiceImpl - showATT method starts");
		return attDAOImpl.fetchAATTData(ATTid);
		
	}

	public List<ATTInfo> showAllATT()throws ATTException {
		System.out.println("ATTServiceImpl - showAllATT method starts");
		return attDAOImpl.fetchAllATTData();
		
	}
	/*
	public BigDecimal currRateCal(String curtype, BigDecimal curvalue) throws SOWException {
		System.out.println("SowServiceImpl - currRateCal method starts");
		return sowDAOImpl.currCalculation(curtype, curvalue);
		
	}*/

	@Override
	public List<ATTInfo> fetchPreCount() throws ATTException {
		System.out.println("ATTServiceImpl - fetchPreCount method starts");
		return attDAOImpl.fetchPreData();
	}

	@Override
	public List<ATTInfo> fetchAbsCount() throws ATTException {
		System.out.println("ATTServiceImpl - fetchAbsCount method starts");
		return attDAOImpl.fetchAbsData();
	}

	@Override
	public List<STUReaderTypeCount> fetchAreaSTUDetails(int readerID)
			throws ATTException {
		System.out.println("ATTServiceImpl - fetchAreaSTUDetails method starts");
		return attDAOImpl.fetchAreaSTUDetails(readerID);	
	}

	@Override
	public List<STUDInfo> fetchSTUAreaList(int readerID) throws ATTException {
		System.out.println("ATTServiceImpl - fetchSTUAreaList method starts");
		return attDAOImpl.fetchSTUAreaList(readerID);	
	}

	@Override
	public StudentInfoTrack trackStudentInfo(int studentId, int classId)
			throws ATTException {
		System.out.println("ATTServiceImpl - trackStudentInfo method starts");
		return attDAOImpl.trackStudentInfo(studentId, classId);	
	}
	
	@Override
	public List<LateComingList> showLateComing(String date, int month, int year) {
		System.out.println("ATTServiceImpl - showLateComing method starts");
		System.out.println("ATTServiceImpl - showLateComing method Ends");
		return attDAO.fetchLateComingQueryList(date, month, year);
	}

	@Override
	public List<LateComingList> showDailyLateComing(String date) {
		System.out.println("ATTServiceImpl - showLateComing method starts");
		System.out.println("ATTServiceImpl - showLateComing method Ends");
		return attDAO.fetchDailyLateComingList(date);
	}
	
	@Override
	public List<LateComingList> showMonthlyLateComing(int month, int year) {
		System.out.println("ATTServiceImpl - showLateComing method starts");
		System.out.println("ATTServiceImpl - showLateComing method Ends");
		return attDAO.fetchMonthlyLateComingList(month, year);
	}
	
	@Override
	public List<LateComingList> showYearlyLateComing(int year) {
		System.out.println("ATTServiceImpl - showLateComing method starts");
		System.out.println("ATTServiceImpl - showLateComing method Ends");
		return attDAO.fetchYearlyLateComingList(year);
	}
	
	@Override
	public List<LateComingList> showWeeklyLateComing(int count) {
		System.out.println("ATTServiceImpl - showLateComing method starts");
		java.util.Date date= new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int month = cal.get(Calendar.MONTH);
		int year = cal.get(Calendar.YEAR);
		if(count == 0){
			count = count+1;
		}
		System.out.println("ATTServiceImpl - showLateComing method Ends");
		return attDAO.fetchWeeklyLateComingQueryList(count);
	}
}
