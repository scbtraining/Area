package com.stu.service.Impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.Impl.STUDAOImpl;
import com.stu.exception.STUDENTException;
import com.stu.model.STUD;
import com.stu.model.StudentSearch;
import com.stu.model.JSON.STUDInfo;
import com.stu.service.STUService;


@Service("stuServiceImpl")
public class STUServiceImpl implements STUService {

	
	@Autowired
	private STUDAOImpl stuDAOImpl;;
	
	public String addSTUD(STUDInfo STUDinfo) throws STUDENTException {
		System.out.println("StuServiceImpl - addSTUD method starts");
		System.out.println("StuServiceImpl - addSTUD method ends");
		return stuDAOImpl.saveAddSTUD(processSTUInfo(STUDinfo));
		
	}
	
	private STUD processSTUInfo(STUDInfo addSTUInfo) {
		System.out.println("StuServiceImpl - processSTUInfo method starts");
		STUD addSTU=new STUD();
	
		if (null != addSTUInfo) {
			addSTU.setSid(addSTUInfo.getSid());
			addSTU.setSname(addSTUInfo.getSname());
			addSTU.setScontact(addSTUInfo.getScontact());
			addSTU.setSbloodgroup(addSTUInfo.getSbloodgroup());
			addSTU.setSjoindate(addSTUInfo.getSjoindate());
			addSTU.setSgender(addSTUInfo.getSgender());
			addSTU.setSreligion(addSTUInfo.getSreligion());
			addSTU.setSschoolid(addSTUInfo.getSschoolid());
			addSTU.setSclassid(addSTUInfo.getSclassid());
		}
		System.out.println("StuServiceImpl - processSTUInfo method ends");
		return addSTU;
	}
	
	public List<STUDInfo> showSTU(int STUDid)throws STUDENTException {
		System.out.println("StuServiceImpl - showSTU method starts");
		return stuDAOImpl.fetchASTUDData(STUDid);
		
	}
	
	
	public List<STUDInfo> showAllSTU()throws STUDENTException {
		System.out.println("StuServiceImpl - showAllSTU method starts");
		return stuDAOImpl.fetchAllSTUDData();
		
	}
	
	public List<STUDInfo> showSTUDidBySTUDname(String STUDname)throws STUDENTException {
		System.out.println("StuServiceImpl - showSTUDidBySTUDname method starts");
		return stuDAOImpl.fetchSTUDidBySTUDname(STUDname);
		
	}
	
	public StudentSearch showStudentReader(String sid)throws STUDENTException{
		System.out.println("StuServiceImpl - showSTU method starts");
		return stuDAOImpl.searchStudentData(sid);
	}
	
	
	public List<STUDInfo> fetchSTUDetails()throws STUDENTException{
		System.out.println("StuServiceImpl - showSTU method starts");
		return stuDAOImpl.fetchSTUDetails();
	}
	/*
	public BigDecimal currRateCal(String curtype, BigDecimal curvalue) throws SOWException {
		System.out.println("SowServiceImpl - currRateCal method starts");
		return sowDAOImpl.currCalculation(curtype, curvalue);
		
	}*/
}
