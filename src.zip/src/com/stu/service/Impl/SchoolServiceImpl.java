package com.stu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.Impl.SchoolDaoImpl;
import com.stu.exception.SCHOOLException;
import com.stu.model.School;
import com.stu.model.JSON.SchoolInfo;
import com.stu.service.SchoolService;

@Service("schoolServiceImpl")
public class SchoolServiceImpl implements SchoolService{
	
	@Autowired
	private SchoolDaoImpl schoolDAOImpl;

	@Override
	public String addSchool(SchoolInfo schoolInfo) throws SCHOOLException {
		return schoolDAOImpl.addSchool(processSchoolInfo(schoolInfo));
	}
	
	
	private School processSchoolInfo(SchoolInfo schoolInfo) {
		System.out.println("SchoolServiceImpl - processSchoolInfo method starts");
		School school=new School();
	
		if (null != schoolInfo) {
			if (schoolInfo.getSchoolId() != 0) {
				school.setSchoolId(schoolInfo.getSchoolId());
			}
			school.setSchoolName(schoolInfo.getSchoolName());
			school.setSchoolAddress1(schoolInfo.getSchoolAddress1());
			school.setSchoolAddress2(schoolInfo.getSchoolAddress2());
			school.setSchoolMailId(schoolInfo.getSchoolMailId());
			/*school.setPrimarySchoolContact(schoolInfo.getPrimarySchoolContact());
			school.setSecondarySchoolContact(schoolInfo.getSecondarySchoolContact());*/
			school.setStudentContact(schoolInfo.getStudentContact());
			school.setCampusId(schoolInfo.getCampusId());
			//school.setCity(schoolInfo.getCity());
			//school.setState(schoolInfo.getState());
			//school.setPinCode(schoolInfo.getPinCode());
			
		}
		System.out.println("SchoolServiceImpl - processSchoolInfo method ends");
		return school;
	}

	@Override
	public List<SchoolInfo> showSchool(int schoolId) throws SCHOOLException {
		return schoolDAOImpl.showSchool(schoolId);
	}

	@Override
	public List<SchoolInfo> showAllSchool() throws SCHOOLException {
		System.out.println("SchoolServiceImpl - showAllSTUFEE method starts");
		return schoolDAOImpl.fetchSchoolData();
	}

	@Override
	public void deleteSchool(int data) throws SCHOOLException {
		schoolDAOImpl.deleteSchool(data);
	}
	
}
