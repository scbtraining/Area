package com.stu.service.Impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.Impl.SubjectDaoImpl;
import com.stu.exception.SubjectException;
import com.stu.model.Subject;
import com.stu.model.SubjectClass;
import com.stu.model.JSON.SubjectInfo;
import com.stu.service.SubjectService;


@Service("subjectServiceImpl")
public class SubjectServiceImpl implements SubjectService {

	
	@Autowired
	private SubjectDaoImpl subjectDaoImpl;
	
	final static Logger logger = LoggerFactory.getLogger(SubjectServiceImpl.class);
	
	public String addSubject(SubjectInfo subjectInfo) throws SubjectException {
		logger.info("Inside SubjectServiceImpl addSubject method::");
		
		return subjectDaoImpl.saveSubject(subjectInfo);
		
	}
	
	private Subject processSubjectInfo(SubjectInfo addSubjectInfo) {
		logger.info("SubjectServiceImpl processSubjectInfo method starts");
		Subject addSubject=new Subject();
		SubjectClass addSubjectClass=new SubjectClass();	
		if (null != addSubjectInfo) {
			addSubject.setSubjectId(addSubjectInfo.getSubjectId());
			addSubject.setSubjectName(addSubjectInfo.getSubjectName());
			addSubjectClass.setSubjectId(addSubjectInfo.getSubjectId());
			addSubjectClass.setClassId(addSubjectInfo.getClassId());
			addSubjectClass.setSchoolId(addSubjectInfo.getSchoolId());
			addSubject.getSubClass().add(addSubjectClass);
		}
		logger.info("SubjectServiceImpl processSubjectInfo method ends");
		return addSubject;
	}
	
	private SubjectClass processSubjectClassInfo(SubjectInfo addSubjectInfo) {
		logger.info("SubjectServiceImpl processSubjectClassInfo method starts");
		SubjectClass addSubjectClass=new SubjectClass();
	
		if (null != addSubjectInfo) {
			addSubjectClass.setSubjectId(addSubjectInfo.getSubjectId());
			addSubjectClass.setClassId(addSubjectInfo.getClassId());
			addSubjectClass.setSchoolId(addSubjectInfo.getSchoolId());
		}
		logger.info("SubjectServiceImpl processSubjectClassInfo method ends");
		return addSubjectClass;
	}
	
	public List<SubjectInfo> showSubject(int subjectId) throws SubjectException {
		logger.info("Inside SubjectServiceImpl showSubject method::");
		return subjectDaoImpl.fetchSubjectData(subjectId);
		
	}
	
	
	public List<SubjectInfo> showAllSubject() throws SubjectException {
		logger.info("Inside SubjectServiceImpl showAllSubject method ::");
		return subjectDaoImpl.fetchSubjectData();
		
	}
	
	public String deleteSubject(int subjectId) throws SubjectException {
		logger.info("Inside SubjectServiceImpl deleteSubject method::");
		
		return subjectDaoImpl.deleteSubject(subjectId);
		
	}
	
	
}
