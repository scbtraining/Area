package com.stu.service.Impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.Impl.FEEDAOImpl;
import com.stu.dao.Impl.STUDAOImpl;
import com.stu.exception.FEEException;
import com.stu.exception.STUDENTException;
import com.stu.model.FEE;
import com.stu.model.STUD;
import com.stu.model.JSON.FEEInfo;
import com.stu.model.JSON.STUDInfo;
import com.stu.service.FEEService;
import com.stu.service.STUService;


@Service("feeServiceImpl")
public class FEEServiceImpl implements FEEService {

	
	@Autowired
	private FEEDAOImpl feeDAOImpl;;
	
	public String addFEE(FEEInfo FEEinfo) throws FEEException {
		System.out.println("FEEServiceImpl - addFEE method starts");
		System.out.println("FEEServiceImpl - addFEE method ends");
		return feeDAOImpl.saveAddFEE(processFEEInfo(FEEinfo));
		
	}
	
	private FEE processFEEInfo(FEEInfo addFEEInfo) {
		System.out.println("FEEServiceImpl - processFEEInfo method starts");
		FEE addFEE=new FEE();
	
		if (null != addFEEInfo) {
			addFEE.setFeeid(addFEEInfo.getFeeid());
			addFEE.setFeeamount(addFEEInfo.getFeeamount());
			addFEE.setClassid(addFEEInfo.getClassid());
			addFEE.setSchoolid(addFEEInfo.getSchoolid());
		}
		System.out.println("FEEServiceImpl - processFEEInfo method ends");
		return addFEE;
	}
	
	public List<FEEInfo> showFEE(int FEEid)throws FEEException {
		System.out.println("FEEServiceImpl - showFEE method starts");
		return feeDAOImpl.fetchAFEEData(FEEid);
		
	}
	
	
	public List<FEEInfo> showAllFEE()throws FEEException {
		System.out.println("FEEServiceImpl - showAllFEE method starts");
		return feeDAOImpl.fetchFEEData();
		
	}
	/*
	public BigDecimal currRateCal(String curtype, BigDecimal curvalue) throws SOWException {
		System.out.println("SowServiceImpl - currRateCal method starts");
		return sowDAOImpl.currCalculation(curtype, curvalue);
		
	}*/
}
