package com.stu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.Impl.ClassDaoImpl;
import com.stu.exception.ClassException;
import com.stu.model.STUDENTCLASS;
import com.stu.model.JSON.StudentClass;
import com.stu.service.ClassService;

@Service("classServiceImpl")
public class ClassServiceImpl implements ClassService {

	@Autowired
	private ClassDaoImpl classDAOImpl;;

	public String addClass(StudentClass classInfo) throws ClassException {
		System.out.println("ClassServiceImpl - addClass method starts");
		System.out.println("ClassServiceImpl - addClass method ends");
		return classDAOImpl.addClass(processClassInfo(classInfo));

	}

	private STUDENTCLASS processClassInfo(StudentClass addClassInfo) {
		System.out.println("classDAOImpl - processClassInfo method starts");
		STUDENTCLASS addClass = new STUDENTCLASS();

		if (null != addClass) {
			//addClass.setClassID(addClassInfo.getClassID());
			addClass.setClassName(addClassInfo.getClassName());
			addClass.setSection(addClassInfo.getSection());

		}
		System.out.println("classDAOImpl - processClassInfo method ends");
		return addClass;
	}

	public List<StudentClass> showClass(int classID) throws ClassException {
		System.out.println("classDAOImpl - showlass method starts");
		return classDAOImpl.showClass(classID);

	}

	public List<StudentClass> showAllClass() throws ClassException {
		System.out.println("classDAOImpl - showAllClass method starts");
		return classDAOImpl.showAllClass();

	}

	public String deleteClass(StudentClass deleteClassInfo) throws ClassException {
		System.out.println("classDAOImpl - deleteClass method starts");

		System.out.println("classDAOImpl - deleteClass method ends");
		return classDAOImpl.deleteClass(processDeleteClass(deleteClassInfo).getClassID());
	}

	private STUDENTCLASS processDeleteClass(StudentClass deleteClassInfo) {
		System.out.println("classDAOImpl - processDeleteClass method starts");
		STUDENTCLASS deleteClass = new STUDENTCLASS();

		if (null != deleteClass) {
			deleteClass.setClassID(deleteClassInfo.getClassID());
			deleteClass.setClassName(deleteClassInfo.getClassName());
			deleteClass.setSection(deleteClassInfo.getSection());

		}
		System.out.println("classDAOImpl - processDeleteClass method ends");
		return deleteClass;
	}

}
