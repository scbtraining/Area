package com.stu.service.Impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.Impl.LOGINDAOImpl;
import com.stu.dao.Impl.STUDAOImpl;
import com.stu.dao.Impl.USERDAOImpl;
import com.stu.exception.LOGINException;
import com.stu.exception.STUDENTException;
import com.stu.exception.USERException;
import com.stu.model.STUD;
import com.stu.model.USER;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.USERInfo;
import com.stu.model.JSON.UsersInfo;
import com.stu.service.LOGINService;
import com.stu.service.STUService;
import com.stu.service.USERService;


@Service("loginServiceImpl")
public class LOGINServiceImpl implements LOGINService {

	
	@Autowired
	private LOGINDAOImpl loginDAOImpl;
	
	public UsersInfo check(String username, String password)throws LOGINException {
		System.out.println("USERServiceImpl - showAllSTU method starts");
		return loginDAOImpl.checkData(username,password);
		
	}


}
