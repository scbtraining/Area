package com.stu.service.Impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.Impl.STUDAOImpl;
import com.stu.dao.Impl.USERDAOImpl;
import com.stu.exception.STUDENTException;
import com.stu.exception.USERException;
import com.stu.model.STUD;
import com.stu.model.USER;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.USERInfo;
import com.stu.service.STUService;
import com.stu.service.USERService;
import com.stu.util.PasswordHashing;


@Service("userServiceImpl1")
public class USERServiceImpl1 implements USERService {

	
	@Autowired
	private USERDAOImpl userDAOImpl;
	
	public String addUSER(USERInfo USERinfo) throws USERException {
		System.out.println("USERServiceImpl - addUSER method starts");
		System.out.println("USERServiceImpl - addUSER method ends");
		return userDAOImpl.saveAddUSER(processUSERInfo(USERinfo));
		
	}
	
	private USER processUSERInfo(USERInfo USERinfo) {
		System.out.println("USERServiceImpl - processUSERInfo method starts");
		USER addUSER=new USER();
		String hashPassword="";
	
		if (null != USERinfo) {
			addUSER.setUserId(USERinfo.getUserId());
			addUSER.setUserName(USERinfo.getUserName());
			//changing the password to hashingpassword
			hashPassword=PasswordHashing.md5(USERinfo.getPassword());
			USERinfo.setPassword(hashPassword);
			//addUSER.setPassword(USERinfo.getPassword());
			addUSER.setPassword(USERinfo.getPassword());
			addUSER.setEmailId(USERinfo.getEmailId());
			//addUSER.setUserAddress(USERinfo.getAddress());
			addUSER.setAddress(USERinfo.getAddress());
			//addUSER.setUserPhoneNo(USERinfo.getPhoneNo());
			addUSER.setPhoneNumber(USERinfo.getPhoneNo());
		}
		System.out.println("USERServiceImpl - processUSERInfo method ends");
		return addUSER;
	}
	
	public List<USERInfo> showUSER(Integer userId)throws USERException {
		System.out.println("USERServiceImpl - showSTU method starts");
		return userDAOImpl.fetchAUserData(userId);
		
	}
	
	public List<USERInfo> showAllUSER()throws USERException {
		System.out.println("USERServiceImpl - showAllSTU method starts");
		return userDAOImpl.fetchAllUserData();
		
	}
	

}
