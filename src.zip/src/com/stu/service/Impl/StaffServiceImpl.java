package com.stu.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.stu.dao.StaffDAO;
import com.stu.dao.Impl.StaffDAOImpl;
import com.stu.exception.StaffException;
import com.stu.model.StaffDetail;
import com.stu.model.JSON.StaffInfo;
import com.stu.service.StaffService;

@Service(value="staffServiceImpl")
public class StaffServiceImpl implements StaffService {

	@Autowired
	StaffDAO staffDaoImpl;// =new StaffDAOImpl();
	
	
	@Override
	public String addStaff(StaffInfo staffInfo) throws StaffException {
		System.out.println("StaffServiceImpl - addStaff method starts");
		System.out.println("StaffServiceImpl - addStaff method ends");
		return staffDaoImpl.saveAddStaff(processStaffInfo(staffInfo));
		
	}

	@Override
	public List<StaffInfo> showAllStaff() throws StaffException {
		System.out.println("StaffServiceImpl - showAllStaff method starts");
		return staffDaoImpl.fetchAllStaffData();
		
	}

	@Override
	public List<StaffInfo>  showStaff(int id) throws StaffException {
		System.out.println("StaffServiceImpl - showAllStaff method starts");
		List<StaffInfo> staffList=staffDaoImpl.fetchAllStaffData(id);
		return staffList;
	}

	@Override
	public String deleteStaff(int id) throws StaffException {
		// TODO Auto-generated method stub
		StaffDetail staff=new StaffDetail();
		staff.setId(id);
		return staffDaoImpl.deteleStaffData(staff);
	}
	
	
	private StaffDetail processStaffInfo(StaffInfo staffInfo) {
		System.out.println("StaffServiceImpl - processStaff Info method starts");
		StaffDetail staff=new StaffDetail();
	
		if (null != staff) {
			staff.setId(staffInfo.getId());
			staff.setfName(staffInfo.getfName());
			staff.setlName(staffInfo.getlName());
            staff.setSalary(staffInfo.getSalary());
		}
		System.out.println("StaffServiceImpl - processStaff Info method ends");
		return staff;
	}
	
}
