package com.stu.service.Impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.Impl.STUDAOImpl;
import com.stu.dao.Impl.STUFEEDAOImpl;
import com.stu.exception.STUDENTException;
import com.stu.exception.STUDENTFEEException;
import com.stu.model.STUD;
import com.stu.model.STUDFEE;
import com.stu.model.JSON.STUDFEEInfo;
import com.stu.model.JSON.STUDInfo;
import com.stu.service.STUFEEService;
import com.stu.service.STUService;


@Service("stufeeServiceImpl")
public class STUFEEServiceImpl implements STUFEEService {

	
	@Autowired
	private STUFEEDAOImpl stufeeDAOImpl;
	
	public String addSTUDFEE(STUDFEEInfo STUDFEEinfo) throws STUDENTFEEException {
		System.out.println("STUFEEServiceImpl - addSTUD method starts");
		System.out.println("STUFEEServiceImpl - addSTUD method ends");
		return stufeeDAOImpl.saveAddSTUDFEE(processSTUFEEInfo(STUDFEEinfo));
		
	}
	
	private STUDFEE processSTUFEEInfo(STUDFEEInfo addSTUFEEInfo) {
		System.out.println("STUFEEServiceImpl - processSTUInfo method starts");
		STUDFEE addSTUFEE=new STUDFEE();
	
		if (null != addSTUFEEInfo) {
			addSTUFEE.setSid(addSTUFEEInfo.getSid());
			addSTUFEE.setFeeid(addSTUFEEInfo.getFeeid());
			addSTUFEE.setPaidamount(addSTUFEEInfo.getPaidamount());
			addSTUFEE.setBalanceamount(addSTUFEEInfo.getBalanceamount());
			addSTUFEE.setDateofpaid(addSTUFEEInfo.getDateofpaid());
		}
		System.out.println("STUFEEServiceImpl - processSTUInfo method ends");
		return addSTUFEE;
	}
	
	public List<STUDFEEInfo> showSTUFEE(int STUDFEEid)throws STUDENTFEEException {
		System.out.println("STUFEEServiceImpl - showSTU method starts");
		return stufeeDAOImpl.fetchASTUDFEEData(STUDFEEid);
		
	}
	
	
	public List<STUDFEEInfo> showAllSTUDFEE()throws STUDENTFEEException {
		System.out.println("STUFEEServiceImpl - showAllSTUFEE method starts");
		return stufeeDAOImpl.fetchSTUFEEData();
		
	}
	
	/*
	public BigDecimal currRateCal(String curtype, BigDecimal curvalue) throws SOWException {
		System.out.println("SowServiceImpl - currRateCal method starts");
		return sowDAOImpl.currCalculation(curtype, curvalue);
		
	}*/
}
