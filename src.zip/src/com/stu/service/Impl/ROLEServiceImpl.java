package com.stu.service.Impl;

import java.util.List;

import javax.management.relation.RoleInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.Impl.ROLEDAOImpl;
import com.stu.exception.ROLEException;
import com.stu.model.ROLE;
import com.stu.model.JSON.ROLEInfo;
import com.stu.service.ROLEService;


@Service("roleServiceImpl")
public class ROLEServiceImpl implements ROLEService {

	
	@Autowired
	private ROLEDAOImpl roleDAOImpl;;
	
	public String addROLE(ROLEInfo ROLEinfo) throws ROLEException {
		System.out.println("ROLEServiceImpl - addROLE method starts");
		System.out.println("ROLEServiceImpl - addROLE method ends");
		return roleDAOImpl.saveAddROLE(processROLEInfo(ROLEinfo));
		
	}
	
	private ROLE processROLEInfo(ROLEInfo roleInfo) {
		System.out.println("ROLEServiceImpl - processROLEInfo method starts");
		ROLE addROLE=new ROLE();
	
		if (null != roleInfo) {
			addROLE.setRoleid(roleInfo.getRoleid());
			addROLE.setRolename(roleInfo.getRolename());
			addROLE.setStatus(roleInfo.getStatus());
		}
		System.out.println("ROLEServiceImpl - processROLEInfo method ends");
		return addROLE;
	}
	
	public List<ROLEInfo> showROLE(int ROLEid)throws ROLEException {
		System.out.println("ROLEServiceImpl - showROLE method starts");
		return roleDAOImpl.fetchAROLEData(ROLEid);
		
	}
	
	
	public List<ROLEInfo> showAllROLE()throws ROLEException {
		System.out.println("ROLEServiceImpl - showAllROLE method starts");
		return roleDAOImpl.fetchAllROLEData();
		
	}
	/*
	public BigDecimal currRateCal(String curtype, BigDecimal curvalue) throws SOWException {
		System.out.println("SowServiceImpl - currRateCal method starts");
		return sowDAOImpl.currCalculation(curtype, curvalue);
		
	}*/



	
}
