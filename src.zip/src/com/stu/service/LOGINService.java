package com.stu.service;

import com.stu.exception.LOGINException;
import com.stu.model.JSON.UsersInfo;

public interface LOGINService {

	UsersInfo check(String username, String password)throws LOGINException;
	
}
