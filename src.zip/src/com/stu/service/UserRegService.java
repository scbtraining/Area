package com.stu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stu.dao.UserRegDao;
import com.stu.exception.UserRegException;
import com.stu.model.StudentMarks;
import com.stu.model.StudentRegistration;
import com.stu.model.UserReg;

@Service
public class UserRegService {
    
	@Autowired
	UserRegDao userregDao; 
	public void saveUserReg(UserReg userreg) throws UserRegException {
		userregDao.saveUserReg(userreg);
		
	}
	public void saveUserReg(StudentRegistration studentreg) throws UserRegException {
		userregDao.saveUserReg(studentreg);
		
	}
	
	public void saveStudentMarks(StudentMarks studentmarks) throws UserRegException {
		userregDao.saveStudentMarks(studentmarks);
		
	}
	public List<StudentRegistration> getUserRegList() throws UserRegException {
		return userregDao.getUserRegList();
	}

}
