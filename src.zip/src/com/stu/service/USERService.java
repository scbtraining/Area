package com.stu.service;

import java.math.BigDecimal;
import java.util.List;

import com.stu.exception.STUDENTException;
import com.stu.exception.USERException;
import com.stu.model.JSON.STUDInfo;
import com.stu.model.JSON.USERInfo;

public interface USERService {

	String addUSER(USERInfo USERinfo)throws USERException;
	
	List<USERInfo> showUSER(Integer userId)throws USERException;
	
	List<USERInfo> showAllUSER()throws USERException;
	
}
