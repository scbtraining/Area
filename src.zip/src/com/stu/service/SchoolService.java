package com.stu.service;

import java.util.List;

import com.stu.exception.SCHOOLException;
import com.stu.model.JSON.SchoolInfo;

public interface SchoolService {
	
	List<SchoolInfo> showSchool(int ROLEid)throws SCHOOLException;
	
	List<SchoolInfo> showAllSchool()throws SCHOOLException;

	String addSchool(SchoolInfo schoolInfo) throws SCHOOLException;

	void deleteSchool(int data) throws SCHOOLException;

}
