package com.stu.service;

import java.math.BigDecimal;
import java.util.List;

import com.stu.exception.STUDENTException;
import com.stu.exception.STUDENTFEEException;
import com.stu.model.JSON.STUDFEEInfo;
import com.stu.model.JSON.STUDInfo;

public interface STUFEEService {

	String addSTUDFEE(STUDFEEInfo STUDFEEinfo)throws STUDENTFEEException;
	
	List<STUDFEEInfo> showAllSTUDFEE()throws STUDENTFEEException;
	
	List<STUDFEEInfo> showSTUFEE(int STUDFEEid)throws STUDENTFEEException;
	
	//BigDecimal currRateCal(String curtype, BigDecimal curvalue)throws SOWException;
}
