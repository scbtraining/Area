package com.stu.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.stu.exception.StaffException;
import com.stu.model.JSON.StaffInfo;


public interface StaffService {
	
	String addStaff(StaffInfo staffInfo)throws StaffException;
List<StaffInfo> showAllStaff()throws StaffException;
	
List<StaffInfo>  showStaff(int id)throws StaffException;
	
	public String deleteStaff(int id) throws StaffException;
	
}
