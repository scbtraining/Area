package com.sms.application;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;


@Service
public class AlertReaderService {
    
	@Autowired
	AlertReaderDao readerDao; 

	public void sendSms(String recMobNo, String msg) throws Exception {
		List<Sms> getDbValue = readerDao.sendRecMsg();
		String sHost= "";
		String sPort = "";
		String uName ="";
		String sPwd="";
		String sSender="";	
		String sMsg=msg;	
		String sRec=recMobNo;	
			for(Sms recordmsg :getDbValue ) {
			  		sHost= recordmsg.getHost();
			  		sPort =recordmsg.getPort();
			  		uName =recordmsg.getUserName();
			  		sPwd =recordmsg.getPassword();
			  		sSender =recordmsg.getSender();
			      }
		 SmsSender objsender = new SmsSender();
		 objsender.sendSms(sHost, sPort, uName, sPwd, sSender, sMsg, sRec);
	}
	
	/*public void sendEmail(String emailId,String subj, String msg)  {
		
		 List<String> msgList = new ArrayList<String>();	
		 String msgto = "<table width=50% border=1>";
		 msgto+=  "<caption><b>Students Mark Sheet</b></caption>";
		 msgto+=  "<th>"+"Student ID"+"</th>"+ "<th>"+"Mark ID"+"</th>"+ "<th>"+"Class ID"+"</th>"+ "<th>"+"Subject ID"+"</th>"+ "<th>"+"Marks"+"</th>"+ "<th>"+"Date Of Exam"+"</th>"+ "<th>"+"Result"+"</th>";
		 List<Email> msgBody = readerDao.sendEmailMsg();
		 System.out.println("msgBody"+msgBody);
	    	  	for(Email recordmsg :msgBody ) {
	    	  		msgto +="<tr><td>"+ recordmsg.getStudId()+" </td> <td> "+recordmsg.getMarkId()+" </td> <td> "+recordmsg.getClassId()+"</td> <td>  "+recordmsg.getStudId()+" </td> <td> "+recordmsg.getMarks()+" </td> <td> "+recordmsg.getDoe()+"</td> <td>  "+recordmsg.getResult()+"</td></tr>";
	    	  		msgList.add(msgto);
	    	  	}
	    	  	sendMail(msgto,emailId);
	}*/
	
	
	public static void sendMail(String emailId,String subj, String msg) {
				
				final String username = "PA00495488@techMahindra.com";
				final String password = "PreTec@2516";
				Properties props = new Properties();
				props.put("mail.smtp.auth", "true");
				props.put("mail.smtp.starttls.enable", "true");
				props.put("mail.smtp.host", "chnowa.techmahindra.com");
				props.put("mail.smtp.port", "587");

				Session session = Session.getInstance(props,
				  new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(username, password);
					}
				  });

				try {

					Message message = new MimeMessage(session);
					message.setFrom(new InternetAddress(username));
					message.setRecipients(Message.RecipientType.TO,
						InternetAddress.parse(emailId));
					message.setSubject(subj);
					message.setContent(msg, "text/html");
					//message.setText(messBody);

					Transport.send(message);

				} catch (MessagingException e) {
					throw new RuntimeException(e);
				}
			}
	public void sendMsg(String alrStudId) throws Exception {

		 List<Sms> getDbValue = readerDao.sendRecMsgId(alrStudId);
		 String sHost= "";
			String sPort = "";
			String uName ="";
			String sPwd="";
			String sSender="";	
			String sMsg="";	
			String sRec="";	
				for(Sms recordmsg :getDbValue ) {
				  		sHost= recordmsg.getHost();
				  		sPort =recordmsg.getPort();
				  		uName =recordmsg.getUserName();
				  		sPwd =recordmsg.getPassword();
				  		sSender =recordmsg.getSender();
				  		sMsg =recordmsg.getMsg();
				  		sRec =recordmsg.getRecipient();
				      }
					
			 SmsSender objsender = new SmsSender();
			 objsender.sendSms(sHost, sPort, uName, sPwd, sSender, sMsg, sRec);
	 }
	 public void sendBulkSms(ArrayList recMobNo, String msg) throws Exception {
		 List<String> bulkNo = recMobNo;
		 for (String recNo : bulkNo) {
			
			 List<Sms> getDbValue = readerDao.sendRecMsg();
			 String sHost= "";
			 String sPort = "";
			 String uName ="";
			 String sPwd="";
			 String sSender="";	
			 String sMsg=msg;	
			 String sRec=recNo;	
				for(Sms recordmsg :getDbValue ) {
				  		sHost= recordmsg.getHost();
				  		sPort =recordmsg.getPort();
				  		uName =recordmsg.getUserName();
				  		sPwd =recordmsg.getPassword();
				  		sSender =recordmsg.getSender();
				      }
			 SmsSender objsender = new SmsSender();
			 objsender.sendSms(sHost, sPort, uName, sPwd, sSender, sMsg, sRec);
		 }
		
	 }

	 public List<Alert> listAlert() throws Exception{
		 List<Alert> alertVal = readerDao.alertDetails();
		 return alertVal;
	 }
	 public List<Alert> listAlertDetails() throws Exception{
		 List<Alert> alertVal = readerDao.alertList();
		 return alertVal;
	 }
	 public List<Alert> listStudId(String alrId) throws Exception{
		 List<Alert> alertVal = readerDao.studList(alrId);
		 return alertVal;
	 }
	 public int updStatus(ArrayList alrId) throws Exception{
		 System.out.println("vvvvvv"+alrId);
		 int alertVal =0;
		 List<String> updAldId = alrId;
		 for (String alrVal : updAldId) {
		 alertVal = readerDao.updStatus(alrVal);
		 }
		 return alertVal;
		 
	 }
}
