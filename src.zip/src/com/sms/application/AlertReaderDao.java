package com.sms.application;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.stu.exception.ATTException;




@Component
public class AlertReaderDao {
	
	//private static SessionFactory factory=new AnnotationConfiguration().configure().buildSessionFactory();;
	
	@Autowired
	private SessionFactory sessionFactory1;
	
	@SuppressWarnings("deprecation")
	
	public List<Sms> sendRecMsgId(String alrStudId) throws Exception {
		//Session session = factory.openSession();
		Session session = getSession();
		Transaction tx = null;
		List<Sms> msgList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select a.HOST,a.PORT,a.username,a.password,a.sender,a.msg,b.parent_contact from SMS_DETAILS a, studentdetails b where b.STUDENT_ID ='"+alrStudId+"'";
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			msgList = new ArrayList<Sms>();
			for (Object[] row : results) {
				Sms msgval = new Sms();
				String host="";
				if (row[0] != null && row[0] != "") {
					host =row[0].toString();				
					msgval.setHost(host);	
				}
				String port="";
				if (row[1] != null && row[1] != "") {
					port =row[1].toString();				
					msgval.setPort(port);	
				}
				String uName="";
				if (row[2] != null && row[2] != "") {
					uName =row[2].toString();				
					msgval.setUserName(uName);	
				}
				String pwd="";
				if (row[3] != null && row[3] != "") {
					pwd =row[3].toString();				
					msgval.setPassword(pwd);	
				}
				String sender="";
				if (row[4] != null && row[4] != "") {
					sender =row[4].toString();				
					msgval.setSender(sender);	
				}
				String msg="";
                if (row[5] != null && row[5] != "") {
                       msg =row[5].toString();                        
                       msgval.setMsg(msg);

                }
                String recipient="";
                if (row[6] != null && row[6] != "") {
                       recipient =row[6].toString();                          
                       msgval.setRecipient(recipient);   
                }
               
                
				msgList.add(msgval);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}
		return msgList;
	}
	
	
	public List<Sms> sendRecMsg() throws Exception {
		//Session session = factory.openSession();
		Session session = getSession();
		Transaction tx = null;
		List<Sms> msgList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select * from SMS_DETAILS";
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			msgList = new ArrayList<Sms>();
			for (Object[] row : results) {
				Sms msgval = new Sms();
				String host="";
				if (row[0] != null && row[0] != "") {
					host =row[0].toString();				
					msgval.setHost(host);	
				}
				String port="";
				if (row[1] != null && row[1] != "") {
					port =row[1].toString();				
					msgval.setPort(port);	
				}
				String uName="";
				if (row[2] != null && row[2] != "") {
					uName =row[2].toString();				
					msgval.setUserName(uName);	
				}
				String pwd="";
				if (row[3] != null && row[3] != "") {
					pwd =row[3].toString();				
					msgval.setPassword(pwd);	
				}
				String sender="";
				if (row[4] != null && row[4] != "") {
					sender =row[4].toString();				
					msgval.setSender(sender);	
				}
				String message="";
				if (row[5] != null && row[5] != "") {
					message =row[5].toString();				
					msgval.setMessage(message);	
				}
				String recipient="";
				if (row[6] != null && row[6] != "") {
					recipient =row[6].toString();				
					msgval.setRecipient(recipient);	
				}
				String cron="";
				if (row[7] != null && row[7] != "") {
					cron =row[7].toString();				
					msgval.setCron(cron);	
				}
				String recName="";
				if (row[8] != null && row[8] != "") {
					recName =row[8].toString();				
					msgval.setRecName(recName);	
				}
				String attper="";
				if (row[9] != null && row[9] != "") {
					attper =row[9].toString();				
					msgval.setAttper(attper);
				}
				String msg="";
				if (row[11] != null && row[11] != "") {
					msg =row[11].toString();				
					msgval.setMsg(msg);
				}
                
				msgList.add(msgval);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}
		return msgList;
	}
	
	protected Session getSession() throws Exception {
		Session session = sessionFactory1.getCurrentSession();
		if (null == session) {
			session = sessionFactory1.openSession();
		}
		return session;
	}
	
	public List<Email> sendEmailMsg() throws Exception{
		//Session session = factory.openSession();
		Session session = getSession();
		Transaction tx = null;
		List<Email> msgList = null;
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select * from STUDENT_MARKS";
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			msgList = new ArrayList<Email>();
			for (Object[] row : results) {
				Email msgval = new Email();
				
				
				String studId="";
				if (row[0] != null && row[0] != "") {
					studId =row[0].toString();				
					msgval.setStudId(studId);	
				}
				String markId="";
				if (row[1] != null && row[1] != "") {
					markId =row[1].toString();				
					msgval.setMarkId(markId);	
				}
				String classID="";
				if (row[2] != null && row[2] != "") {
					classID =row[2].toString();				
					msgval.setClassId(classID);	
				}
				String subjId="";
				if (row[3] != null && row[3] != "") {
					subjId =row[3].toString();				
					msgval.setSubjId(subjId);	
				}
				String marks="";
				if (row[4] != null && row[4] != "") {
					marks =row[4].toString();				
					msgval.setMarks(marks);	
				}
				String dob = "";
				if (row[5] != null && row[5] != "") {
					dob = row[5].toString();
					Date dobDate = null;
					try {
						dobDate = df.parse(dob);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					msgval.setDoe(dobDate);
				}
				String res="";
				if (row[6] != null && row[6] != "") {
					res =row[6].toString();				
					msgval.setResult(res);	
				}
				msgList.add(msgval);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}
		return msgList;
		
	}
	
	public List<Alert> alertDetails() throws Exception{
		//Session session = factory.openSession();
		Session session = getSession();
		Transaction tx = null;
		List<Alert> msgList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select distinct b.ALERT_ID,b.ALERT_DESC, c.STUDENT_ID, c.STUDENT_NAME, d.TIME from READER a,ALERT_DETAILS b,STUDENTDETAILS c,ALERT_TRANS d,student_card sc where a.cardid = sc.cardid and sc.studentid = c.STUDENT_ID and c.STUDENT_ID=d.STUDENT_ID and b.ALERT_ID=d.ALERT_ID  order by d.time desc";
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			msgList = new ArrayList<Alert>();
			for (Object[] row : results) {
				Alert msgval = new Alert();
				
				
				String alertId="";
				if (row[0] != null && row[0] != "") {
					alertId =row[0].toString();				
					msgval.setAlertId(alertId);	
				}
				String alertDesc="";
				if (row[1] != null && row[1] != "") {
					alertDesc =row[1].toString();				
					msgval.setAlertDesc(alertDesc);	
				}
				String studId="";
				if (row[2] != null && row[2] != "") {
					studId =row[2].toString();				
					msgval.setStudId(studId);	
				}
				String studName="";
				if (row[3] != null && row[3] != "") {
					studName =row[3].toString();				
					msgval.setStudName(studName);
				}
				String alrTime="";
				if (row[4] != null && row[4] != "") {
					alrTime =row[4].toString();				
					msgval.setAlrTime(alrTime);	
				}
				msgList.add(msgval);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}
		return msgList;
	}
	public List<Alert> alertList() throws Exception{
		//Session session = factory.openSession();
		Session session = getSession();
		Transaction tx = null;
		List<Alert> msgList = null;
		
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select DISTINCT b.alert_ID, b.ALERT_DESC, SUBSTR(a.entry_time, 15, 2) as mins from READER a, ALERT_DETAILS b, STUDENTDETAILS c,"
						+"ALERT_TRANS d, student_card sc where a.cardid = sc.cardid and sc.studentid = c.STUDENT_ID and c.STUDENT_ID = d.STUDENT_ID and b.ALERT_ID = d.ALERT_ID and SUBSTR(d.time, 1, 10) = curdate() AND d.STATUS = 'ACTIVE'";
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			msgList = new ArrayList<Alert>();
			for (Object[] row : results) {
				Alert msgval = new Alert();
				String alertId="";
				if (row[0] != null && row[0] != "") {
					alertId =row[0].toString();				
					msgval.setAlertId(alertId);	
				}
				String alertDesc="";
				if (row[1] != null && row[1] != "") {
					alertDesc =row[1].toString();				
					msgval.setAlertDesc(alertDesc);	
				}
		
				String alrmins="";
				if (row[2] != null && row[2] != "") {
					alrmins =row[2].toString();				
					msgval.setAlrmins(alrmins);
				}
				msgList.add(msgval);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}
		return msgList;
	}
	public List<Alert> studList(String alrId) throws Exception{
		//Session session = factory.openSession();
		Session session = getSession();
		Transaction tx = null;
		List<Alert> msgList = null;
		System.out.println("aler"+alrId);
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "select DISTINCT d.alert_id, d.STUDENT_ID, c.STUDENT_NAME from STUDENTDETAILS c,ALERT_TRANS d where d.ALERT_ID ='"+alrId+"'and d.STUDENT_ID=c.STUDENT_ID and SUBSTR(d.time,1,10)=curdate() and d.status='ACTIVE'";
			SQLQuery query = session.createSQLQuery(sql);
			List<Object[]> results = query.list();
			msgList = new ArrayList<Alert>();
			for (Object[] row : results) {
				Alert msgval = new Alert();
				String alertId="";
				if (row[0] != null && row[0] != "") {
					alertId =row[0].toString();				
					msgval.setAlertId(alertId);	
				}
				String studId="";
				if (row[1] != null && row[1] != "") {
					studId =row[1].toString();				
					msgval.setStudId(studId);	
				}
		
				String studName="";
				if (row[2] != null && row[2] != "") {
					studName =row[2].toString();				
					msgval.setStudName(studName);
				}
				msgList.add(msgval);
			}		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}
		return msgList;
	}
	public int updStatus(String alrId) throws Exception{
		//Session session = factory.openSession();
		Session session = getSession();
		Transaction tx = null;
		int results = 0;
		System.out.println("aler"+alrId);
		try {
			tx = session.beginTransaction();
			//studentList = session.createCriteria(Student.class).list();
			
			String sql = "UPDATE ALERT_TRANS SET STATUS='INACTIVE',UPDATED_TIME = CURRENT_TIMESTAMP WHERE ALERT_ID='"+alrId+"'";
			System.out.println("up"+sql);
			SQLQuery query = session.createSQLQuery(sql);
			results = query.executeUpdate();		
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
			tx.rollback();
			e.printStackTrace();
			throw new HibernateException(e);
		} finally {
			//session.close();
		}
		return results;
	}
	
}
