package com.sms.application;

import java.util.Date;

public class Alert {
   private String alertId;
   private String alertDesc;
   private String studId;
   private String studName;
   private String alrTime;
   private String alrmins;
public String getAlrmins() {
	return alrmins;
}
public void setAlrmins(String alrmins) {
	this.alrmins = alrmins;
}
public String getAlertId() {
	return alertId;
}
public void setAlertId(String alertId) {
	this.alertId = alertId;
}
public String getAlertDesc() {
	return alertDesc;
}
public void setAlertDesc(String alertDesc) {
	this.alertDesc = alertDesc;
}
public String getStudId() {
	return studId;
}
public void setStudId(String studId) {
	this.studId = studId;
}
public String getStudName() {
	return studName;
}
public void setStudName(String studName) {
	this.studName = studName;
}
public String getAlrTime() {
	return alrTime;
}
public void setAlrTime(String alrTime) {
	this.alrTime = alrTime;
}
}