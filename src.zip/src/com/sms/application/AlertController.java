package com.sms.application;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/student")
public class AlertController {
	
	@Autowired
	AlertReaderService readerService;
	
	@RequestMapping(value="/sms/{recMobNo}/{msg}", method = RequestMethod.GET)
	public void sendSmsToMsg(@PathVariable("recMobNo") String recMobNo ,@PathVariable("msg") String msg) {
		try{
		readerService.sendSms(recMobNo,msg);
		System.out.println("SMS sent successfully");
		}
		catch(Exception e){
			System.out.println("Exception caught"+e);
		}
	}
	
	@RequestMapping(value="/email/{emailId}/{subj}/{msg}", method = RequestMethod.GET)
	public void sendEmailTo(@PathVariable("emailId") String emailId,@PathVariable("subj") String subj,@PathVariable("msg") String msg) {
		try{
		//String emailIdval = emailId.concat(".com");	
		readerService.sendMail(emailId,subj,msg);
		System.out.println("Email sent successfully");
		}
		catch(Exception e){
			System.out.println("Exception caught"+e);
		}
	}
	@CrossOrigin(origins="*", maxAge = 3600)
	@RequestMapping(value="/sms/{alrStudId}", method = RequestMethod.GET)
	public void sendSms(@PathVariable("alrStudId") String alrStudId)  {
		 try{
			 readerService.sendMsg(alrStudId);
		 System.out.println("SMS sent successfully");
			}
			catch(Exception e){
				System.out.println("Exception caught"+e);
			}
	}
	@CrossOrigin(origins="*", maxAge = 3600)
	 @RequestMapping(value="/bulkSms/{recMobNo}/{msg}", method = RequestMethod.GET)
	 public void sendSmsToMsg(@PathVariable("recMobNo") ArrayList recMobNo,@PathVariable("msg") String msg) {
		 try{
			 readerService.sendBulkSms(recMobNo,msg);
		 System.out.println("SMS sent successfully");
			}
			catch(Exception e){
				System.out.println("Exception caught"+e);
			}
	 }
	@CrossOrigin(origins="*", maxAge = 3600)
	 @RequestMapping(value = "/fetchAlert", method = RequestMethod.GET, headers = "Accept=application/json")
	 public ResponseEntity<List<Alert>> alert() throws Exception {
		 System.out.println("in fetc");
		 HttpHeaders headers = new HttpHeaders();
		 List<Alert> alertVal = readerService.listAlert();
		 	if (alertVal == null) {
		 		return new ResponseEntity<List<Alert>>(HttpStatus.NOT_FOUND);
		 		}
		 	//headers.add("Number Of Records Found", String.valueOf(alertVal.size()));
		 	return new ResponseEntity<List<Alert>>(alertVal, headers, HttpStatus.OK);
	 }
	 @CrossOrigin(origins="*", maxAge = 3600)
	 @RequestMapping(value = "/listAlert", method = RequestMethod.GET, headers = "Accept=application/json")
	 public ResponseEntity<List<Alert>> listAlert() throws Exception {
		 HttpHeaders headers = new HttpHeaders();
		 List<Alert> alertVal = readerService.listAlertDetails();
		 	if (alertVal == null) {
		 		return new ResponseEntity<List<Alert>>(HttpStatus.NOT_FOUND);
		 		}
		 	//headers.add("Number Of Records Found", String.valueOf(alertVal.size()));
		 	return new ResponseEntity<List<Alert>>(alertVal, headers, HttpStatus.OK);
	 }
	 @CrossOrigin(origins="*", maxAge = 3600)
	 @RequestMapping(value = "/listAlertId/{alrId}", method = RequestMethod.GET)
	 public ResponseEntity<List<Alert>> listStudId(@PathVariable("alrId") String alrId) throws Exception {
		 HttpHeaders headers = new HttpHeaders();
		 List<Alert> alertVal = readerService.listStudId(alrId);
		 	if (alertVal == null) {
		 		return new ResponseEntity<List<Alert>>(HttpStatus.NOT_FOUND);
		 		}
		 	//headers.add("Number Of Records Found", String.valueOf(alertVal.size()));
		 	return new ResponseEntity<List<Alert>>(alertVal, headers, HttpStatus.OK);
	 }
	@CrossOrigin(origins="*", maxAge = 3600)
	 @RequestMapping(value = "/updStatus/{alrId}", method = RequestMethod.PUT)
	 public ResponseEntity<String> updStatus(@PathVariable("alrId") ArrayList alrId) {
	  HttpHeaders headers = new HttpHeaders();
	  try {
	  int alertVal = readerService.updStatus(alrId);
	  System.out.println("alert"+alertVal);
	  }
	  catch(Exception e){
			System.out.println("Exception caught"+e);
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
			}
	  return new ResponseEntity<String>("success", headers, HttpStatus.OK);
	}
}
