package com.sms.application;

import java.util.Date;

public class Sms {
   private String host;
   private String port;
   private String userName;
   private String password;
   private String sender;
   private String message;
   private String recipient;
   private String cron;
   private String recName;
   private String attper;
   private Date vDate;
   private String msg;
   
   
   
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
public String getRecName() {
	return recName;
}
public void setRecName(String recName) {
	this.recName = recName;
}
public String getAttper() {
	return attper;
}
public void setAttper(String attper) {
	this.attper = attper;
}
public Date getvDate() {
	return vDate;
}
public void setvDate(Date vDate) {
	this.vDate = vDate;
}
public String getCron() {
	return cron;
}
public void setCron(String cron) {
	this.cron = cron;
}
public String getHost() {
	return host;
}
public void setHost(String host) {
	this.host = host;
}
public String getPort() {
	return port;
}
public void setPort(String port) {
	this.port = port;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
public String getRecipient() {
	return recipient;
}
public String getSender() {
	return sender;
}
public void setSender(String sender) {
	this.sender = sender;
}
public void setRecipient(String recipient) {
	this.recipient = recipient;
}
   
   
   
   
}