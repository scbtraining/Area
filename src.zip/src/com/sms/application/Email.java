package com.sms.application;

import java.util.Date;

public class Email {
   private String studId;
   private String markId;
   private String classId;
   private String subjId;
   private String marks;
   private Date doe;
   private String result;
  // private String emailId;
   

public String getStudId() {
	return studId;
}
public void setStudId(String studId) {
	this.studId = studId;
}
public String getMarkId() {
	return markId;
}
public void setMarkId(String markId) {
	this.markId = markId;
}
public String getClassId() {
	return classId;
}
public void setClassId(String classId) {
	this.classId = classId;
}
public String getSubjId() {
	return subjId;
}
public void setSubjId(String subjId) {
	this.subjId = subjId;
}
public String getMarks() {
	return marks;
}
public void setMarks(String marks) {
	this.marks = marks;
}
public Date getDoe() {
	return doe;
}
public void setDoe(Date doe) {
	this.doe = doe;
}
public String getResult() {
	return result;
}
public void setResult(String result) {
	this.result = result;
}
  

   
}